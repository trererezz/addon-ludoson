-- LUDOS-on 0.4.0 - gildia: rangi (do rozpoznania odbiorcow), zmiany gildii postaci, komunikaty systemowe,
-- online/offline i zrzut listy gildii.
--   wszyscy:       GILDIA (moja gildia/ranga), dolaczyl / odszedl (komunikaty systemowe)
--   tylko odbiorcy: awans / degradacja / wyrzucony, ONLINE / OFFLINE, STAN_GILDII (zrzut)
-- Zrzut listy gildii: przy wejsciu do gry, przy wylogowaniu, przy reloadzie jesli minela >= 1 h, recznie /ludos zrzut.

local ADDON, ns = ...
local Log = ns.Log

local SNAP_MIN_GAP = 3600     -- reload: zrzut tylko, gdy od ostatniego minela godzina
local MANUAL_LOCK = 60
local rosterNames = {}        -- [krotkie imie] = true
local rosterRank = {}         -- [krotkie imie] = numer rangi (0 = mistrz gildii)
local rosterLoaded = false
local wantSnapshot
local lastManual = 0
local lastGuild

function ns.GuildRank(name)
  if not name then return nil end
  return rosterRank[ns.Short(name)]
end
function ns.RosterLoaded() return rosterLoaded end

local function requestRoster()
  if C_GuildInfo and C_GuildInfo.GuildRoster then pcall(C_GuildInfo.GuildRoster)
  elseif GuildRoster then pcall(GuildRoster) end
end
ns.RequestRoster = requestRoster

local function readRoster()
  wipe(rosterNames); wipe(rosterRank)
  for i = 1, (GetNumGuildMembers() or 0) do
    local name, _, rankIndex = GetGuildRosterInfo(i)
    if name and not ns.Hidden(name) then
      local short = ns.Short(name)
      rosterNames[short] = true
      if type(rankIndex) == "number" and not ns.Hidden(rankIndex) then rosterRank[short] = rankIndex end
    end
  end
  rosterLoaded = true
end

local function snapshot(powod)
  local total = GetNumGuildMembers() or 0
  local list, online = {}, 0
  for i = 1, total do
    local r = { GetGuildRosterInfo(i) }
    local name, rankName, rankIndex, level, _, zone, _, _, isOnline, _, classFile = r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], r[11]
    local guid = r[17]
    if name and not ns.Hidden(name) then
      local y, mo, d, h = GetGuildRosterLastOnline(i)
      if isOnline then online = online + 1 end
      list[#list + 1] = string.format("%s|%s|%s|%s|%s|%d|%s,%s,%s,%s|%s|%s", name, tostring(ns.Safe(level)), tostring(classFile),
        tostring(ns.Safe(rankName)), tostring(ns.Safe(zone) or ""), isOnline and 1 or 0,
        tostring(y or 0), tostring(mo or 0), tostring(d or 0), tostring(h or 0), tostring(ns.Safe(rankIndex)), tostring(ns.Safe(guid) or ""))
    end
  end
  Log("STAN_GILDII", { liczba = total, online = online, czlonkowie = list, powod = powod })
  if ns.CH then ns.CH.ostatni_zrzut = ns.now() end
  return total, online
end

ns.On("GUILD_ROSTER_UPDATE", function()
  if not IsInGuild() then return end
  readRoster()
  if wantSnapshot and ns.AmReceiving() then
    local powod = wantSnapshot
    wantSnapshot = nil
    local n, on = snapshot(powod)
    if powod == "reczny" then ns.msg(string.format("Zrzut gildii zapisany: %d czlonkow, %d online.", n, on)) end
  end
end)

local function scheduleSnapshot(powod)
  if not IsInGuild() then return end
  wantSnapshot = powod
  requestRoster()
end

function ns.ManualSnapshot()
  if not IsInGuild() then ns.msg("Nie jestes w gildii.") return end
  if not ns.AmReceiving() then ns.msg("Zrzut gildii robi tylko oficer z wlaczonym odbiorem danych.") return end
  if GetTime() - lastManual < MANUAL_LOCK then ns.msg("Zrzut gildii mozna zrobic raz na minute.") return end
  lastManual = GetTime()
  scheduleSnapshot("reczny")
end

ns.On("PLAYER_GUILD_UPDATE", function(unit)
  if unit and unit ~= "player" then return end
  local g, rank = GetGuildInfo("player")
  local key = tostring(g) .. "|" .. tostring(rank)
  if lastGuild == nil then lastGuild = key return end
  if key == lastGuild then return end
  local wasIn = lastGuild ~= "nil|nil"
  lastGuild = key
  if ns.CH then ns.CH.gildia = g end
  Log("GILDIA", { gildia = g, ranga = rank })
  if g and not wasIn then
    -- dolaczenie do gildii: lista gildii (rangi odbiorcow), potem ogloszenie zebranych danych
    requestRoster()
    C_Timer.After(30, function() if ns.Announce then ns.Announce(false) end end)
  end
end)

-- komunikaty systemowe: wzorce z tekstow gry (dzialaja w kazdym jezyku klienta)
local pats
local function buildPats()
  pats = {}
  local function add(key, typ, order, all)
    local p = ns.FmtToPattern(_G[key])
    if p then table.insert(pats, { p = p, typ = typ, order = order, all = all }) end
  end
  add("ERR_GUILD_JOIN_S", "dolaczyl", { "kto" }, true)
  add("ERR_GUILD_LEAVE_S", "odszedl", { "kto" }, true)
  add("ERR_GUILD_REMOVE_SS", "wyrzucony", { "kto", "przez" })
  add("ERR_GUILD_PROMOTE_SSS", "awans", { "przez", "kto", "ranga" })
  add("ERR_GUILD_DEMOTE_SSS", "degradacja", { "przez", "kto", "ranga" })
  add("ERR_FRIEND_ONLINE_SS", "online", { "kto", "wyswietlane" })
  add("ERR_FRIEND_OFFLINE_S", "offline", { "kto" })
end

ns.On("CHAT_MSG_SYSTEM", function(msg)
  if type(msg) ~= "string" or ns.Hidden(msg) then return end -- w blokadzie czatu tekst jest ukryty
  if not pats then buildPats() end
  for _, p in ipairs(pats) do
    local caps = { msg:match(p.p) }
    if #caps > 0 then
      local d = {}
      for i, field in ipairs(p.order) do d[field] = caps[i] end
      d.kto = ns.Short(d.kto)
      if p.typ == "online" or p.typ == "offline" then
        if ns.AmReceiving() and d.kto and rosterNames[d.kto] then
          Log(p.typ == "online" and "ONLINE" or "OFFLINE", { kto = d.kto })
        end
      elseif p.all or ns.AmReceiving() then
        d.typ = p.typ
        Log("GILDIA_KOMUNIKAT", d)
        if p.typ ~= "online" then requestRoster() end -- rangi mogly sie zmienic
      end
      return
    end
  end
end)

ns.AddHook("start", function()
  local g, rank = GetGuildInfo("player")
  lastGuild = tostring(g) .. "|" .. tostring(rank)
  requestRoster()
  C_Timer.After(60, function() if ns.AmReceiving() then scheduleSnapshot("logowanie") end end)
end)
ns.AddHook("resume", function()
  local g, rank = GetGuildInfo("player")
  lastGuild = tostring(g) .. "|" .. tostring(rank)
  requestRoster()
  local last = ns.CH and ns.CH.ostatni_zrzut or 0
  if ns.now() - last >= SNAP_MIN_GAP then
    C_Timer.After(60, function() if ns.AmReceiving() then scheduleSnapshot("reload") end end)
  end
end)
-- wylogowanie: zrzut z danych, ktore klient juz ma (bez czekania na serwer)
ns.AddHook("logout_real", function()
  if IsInGuild() and ns.AmReceiving() and (GetNumGuildMembers() or 0) > 0 then pcall(snapshot, "wylogowanie") end
end)
