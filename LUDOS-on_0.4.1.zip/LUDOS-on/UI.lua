-- LUDOS-on 0.4.1 - okno /ludos: Informacje, Ustawienia, Widgety, Magazyn: zdarzenia,
-- Magazyn: stan wyslania, Odbior, Pomoc.

local ADDON, ns = ...
local W
local panes, tabs, lists = {}, {}, {}
local current = "zdarzenia"
local sessionView -- numer sesji pokazywanej w zakladce zdarzen (nil = biezaca)

local GOLD = { 1, 0.82, 0 }

local function fmtT(t) return t and date("%d.%m %H:%M:%S", t) or "-" end
local function fmtShort(t) return t and date("%d.%m %H:%M", t) or "-" end

-------------------------------------------------------------------------------
-- Lista z przewijaniem (rysuje tylko widoczne wiersze)
-------------------------------------------------------------------------------
local ROWS, ROW_H = 17, 15

local function newList(parent, cols, y0)
  local L = { offset = 0, cols = cols, rows = {} }
  local x = 0
  for i, c in ipairs(cols) do
    local h = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    h:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y0)
    h:SetWidth(c.w)
    h:SetJustifyH("LEFT")
    h:SetText(c.title)
    x = x + c.w + 6
  end
  for r = 1, ROWS do
    local row = {}
    local cx = 0
    for i, c in ipairs(cols) do
      local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
      fs:SetPoint("TOPLEFT", parent, "TOPLEFT", cx, y0 - 4 - r * ROW_H)
      fs:SetWidth(c.w)
      fs:SetHeight(ROW_H)
      fs:SetJustifyH("LEFT")
      if fs.SetWordWrap then fs:SetWordWrap(false) end
      row[i] = fs
      cx = cx + c.w + 6
    end
    L.rows[r] = row
  end
  local info = parent:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  info:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, y0 - 10 - (ROWS + 1) * ROW_H)
  L.info = info

  local up = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  up:SetSize(70, 20)
  up:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -78, y0 - 6 - (ROWS + 1) * ROW_H)
  up:SetText("Nowsze")
  up:SetScript("OnClick", function() L.offset = math.max(0, L.offset - ROWS); L:Refresh() end)
  local down = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
  down:SetSize(70, 20)
  down:SetPoint("LEFT", up, "RIGHT", 6, 0)
  down:SetText("Starsze")
  down:SetScript("OnClick", function() L.offset = L.offset + ROWS; L:Refresh() end)

  parent:EnableMouseWheel(true)
  parent:SetScript("OnMouseWheel", function(_, delta)
    L.offset = math.max(0, L.offset - delta * 3)
    L:Refresh()
  end)

  function L:Refresh()
    local n = self.count and self.count() or 0
    if self.offset > math.max(0, n - ROWS) then self.offset = math.max(0, n - ROWS) end
    for r = 1, ROWS do
      local i = self.offset + r
      local vals = (i <= n) and self.cell(i) or nil
      for c = 1, #self.cols do
        local fs = self.rows[r][c]
        local v = vals and vals[c]
        if type(v) == "table" then
          fs:SetText(v[1]); fs:SetTextColor(v[2], v[3], v[4])
        else
          fs:SetText(v or ""); fs:SetTextColor(1, 1, 1)
        end
      end
    end
    if n == 0 then
      self.info:SetText(self.empty or "Brak danych.")
    else
      self.info:SetText(string.format("Wiersze %d-%d z %d (kolko myszy przewija)", self.offset + 1, math.min(n, self.offset + ROWS), n))
    end
  end
  return L
end

-------------------------------------------------------------------------------
-- Zawartosc zakladek
-------------------------------------------------------------------------------
local function savedPath()
  local folder = "_classic_era_"
  if WOW_PROJECT_ID and WOW_PROJECT_BURNING_CRUSADE_CLASSIC and WOW_PROJECT_ID == WOW_PROJECT_BURNING_CRUSADE_CLASSIC then
    folder = "_anniversary_"
  end
  return "World of Warcraft\\" .. folder .. "\\WTF\\Account\\<KONTO>\\SavedVariables\\LUDOS-on.lua"
end
ns.SavedPath = savedPath

local function sessionByNr(nr)
  for _, s in ipairs(ns.Sessions()) do if s.nr == nr then return s end end
end

local function viewedSession()
  if sessionView then return sessionByNr(sessionView) or ns.S end
  return ns.S
end

local function infoText()
  local S, CH, u = ns.S, ns.CH, ns.U()
  if not S or not CH then return "Czekam na wejscie do gry..." end
  local L = {}
  local function add(k, v) L[#L + 1] = "|cffffd100" .. k .. ":|r " .. tostring(v) end
  add("Wersja", string.format("LUDOS-on %s, gra: %s (interface %s)", ns.VERSION, tostring(ns.GRA), tostring(ns.IFACE)))
  add("Postac", string.format("%s, %s, lvl %d (%s)", CH.imie or "?", CH.klasa or "?", UnitLevel("player") or 0, CH.realm or "?"))
  add("Gildia", CH.gildia or "brak")
  add("ID postaci / konta", tostring(CH.guid or "-") .. "  /  " .. tostring(ns.DB.meta.konto_id or "-"))
  local rank = ns.GuildRank and ns.GuildRank(ns.Me())
  local rola
  if ns.IsReceiver() then
    rola = ns.AmReceiving() and "oficer - odbiera dane od graczy" or "oficer - |cffff7366odbior wylaczony|r (Ustawienia)"
  else
    rola = "gracz (wysyla dane do oficerow)"
  end
  add("Rola w wymianie", string.format("%s  (ranga w gildii: %s; odbiorcy = rangi 0-%d)", rola, rank and tostring(rank) or "?", ns.CONFIG.RANGA_MAX or 1))
  local act = ns.ActiveReceivers and ns.ActiveReceivers() or {}
  add("Aktywni odbiorcy", (#act > 0) and table.concat(act, ", ") or "brak (jeszcze nikt nie odpowiedzial)")
  if ns.CommsInfo then
    local c = ns.CommsInfo()
    add("Wymiana", string.format("kolejka %d wiad.%s, wyslano %d, ostatnie ogloszenie %s", c.kolejka,
      c.pauza and " (pauza - walka)" or "", c.wyslane, c.ostatnie_ogloszenie > 0 and (math.floor((GetTime() - c.ostatnie_ogloszenie) / 60) .. " min temu") or "-"))
  end
  add("Biezaca sesja", string.format("sesja_%d od %s, reloadow: %d", S.nr, fmtShort(S.start), S.reloady or 0))
  add("Zdarzenia w sesji", string.format("%d (czeka na zapis: %d)", #S.dziennik, ns.Unsaved()))
  add("Ostatni zapis pliku", ns.state.loadTime and fmtT(ns.state.loadTime) or "-")
  local lvl, n, mins = ns.SaveState()
  local sz, lim = ns.DataSize()
  add("Dane add-onu", string.format("~%.1f MB z %d MB%s", sz / 1048576, lim / 1048576,
    sz > lim and " |cffffd100(ponad limit: dane jeszcze niewyslane do oficerow)|r" or " (starsze sesje odebrane przez oficerow znikaja ponad limit)"))
  if ns.IsReceiver() and type(LUDOSon_Odbior_DB) == "table" and LUDOSon_Odbior_DB.meta then
    local om = LUDOSon_Odbior_DB.meta
    add("Odbior (dane od graczy)", string.format("~%.1f MB z 50 MB", (om.rozmiar or 0) / 1048576))
  end
  add("Stan zapisu", ({ [0] = "|cff80d980aktualny|r", [1] = "|cffffd100dobry moment na /reload|r", [2] = "|cffff7366duzo do stracenia - /reload|r" })[lvl]
    .. string.format(" (w pamieci %d, od zapisu %d min)", n, mins))
  L[#L + 1] = " "
  L[#L + 1] = "|cffffd100Plik z danymi:|r (zapisuje sie przy /reload i wylogowaniu)"
  return table.concat(L, "\n")
end

local function helpText()
  return table.concat({
    "|cffffd100LUDOS-on|r - gildyjny add-on do sledzenia postepow graczy.",
    "Zapisuje zdarzenia z gry w dzienniku na Twoim komputerze i w tle wysyla je odbiorcom",
    "(oficerom i masterowi) przez ukryty czat add-onow gildii. Nic nie musisz klikac.",
    " ",
    "|cffffd100Komendy|r",
    "/ludos - to okno",
    "/ludos status - podsumowanie sesji na czacie",
    "/ludos zapisz - zapis danych (/reload)",
    "/ludos przypomnij - pokaz przypominajke teraz (do testu)",
    "/ludos kt - pokaz / ukryj Killtracker (widget testowy, ustawienia w zakladce Widgety)",
    "/ludos zw - pokaz / ukryj widget stanu zapisu",
    "/ludos wymiana - stan wymiany danych z odbiorcami",
    "/ludos wyslij - oglos odbiorcom stan danych teraz",
    "/ludos odbiorca lista - lista odbiorcow (dodaj / usun - tylko master)",
    "/ludos zrzut - reczny zrzut listy gildii (tylko oficer z wlaczonym odbiorem)",
    "/ludos debug - na czacie, co zapisuje add-on (dla dewelopera)",
    "/ludos sonda - na czacie, co podaje gra (do testu; nic nie zapisuje)",
    "/ludos pomoc - lista komend na czacie",
    " ",
    "|cffffd100Wazne|r",
    "Gra zapisuje plik tylko przy /reload i wylogowaniu. Crash gry kasuje wszystko od ostatniego",
    "zapisu. Widget z boku pokazuje, ile czeka; w dobrym momencie (lot, zmiana kontynentu) add-on",
    "podpowie /reload. Wysylka czeka, gdy jestes w walce, i dziala tylko, gdy oficer jest w grze.",
    "Bez gildii dane zbieraja sie u Ciebie i pojda po dolaczeniu do gildii.",
  }, "\n")
end

local function makeCheck(parent, y, label, key, onChange)
  local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
  cb:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, y)
  cb:SetSize(24, 24)
  local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  fs:SetPoint("LEFT", cb, "RIGHT", 4, 0)
  fs:SetText(label)
  cb:SetScript("OnClick", function(self)
    ns.U()[key] = self:GetChecked() and true or false
    if onChange then onChange() end
  end)
  cb.key = key
  return cb
end

-------------------------------------------------------------------------------
-- Budowa okna
-------------------------------------------------------------------------------
local TABS = {
  { id = "info", name = "Informacje" },
  { id = "ustawienia", name = "Ustawienia" },
  { id = "widgety", name = "Widgety" },
  { id = "zdarzenia", name = "Magazyn: zdarzenia" },
  { id = "wyslanie", name = "Magazyn: stan wyslania" },
  { id = "odbior", name = "Odbior" },
  { id = "pomoc", name = "Pomoc" },
}

local function selectTab(id)
  current = id
  for _, t in ipairs(TABS) do
    panes[t.id]:SetShown(t.id == id)
    if t.id == id then tabs[t.id]:LockHighlight() else tabs[t.id]:UnlockHighlight() end
  end
  ns.RefreshWindow()
end

local function create()
  local f = CreateFrame("Frame", "LUDOSonMainFrame", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
  f:SetSize(760, 470)
  f:SetPoint("CENTER")
  f:SetFrameStrata("DIALOG")
  f:SetClampedToScreen(true)
  f:SetMovable(true)
  f:EnableMouse(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  if f.SetBackdrop then
    f:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
      edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32,
      insets = { left = 11, right = 12, top = 12, bottom = 11 } })
  end
  tinsert(UISpecialFrames, "LUDOSonMainFrame")

  local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
  close:SetPoint("TOPRIGHT", -6, -6)
  local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
  title:SetPoint("TOPLEFT", 22, -18)
  title:SetText("LUDOS-on " .. ns.VERSION)
  local sub = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  sub:SetPoint("LEFT", title, "RIGHT", 10, 0)
  sub:SetText("gildyjny add-on do sledzenia postepow graczy - faza testow")

  -- przyciski zakladek
  local prev
  for _, t in ipairs(TABS) do
    local b = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    b:SetHeight(22)
    b:SetWidth(t.id == "zdarzenia" and 130 or t.id == "wyslanie" and 150 or (t.id == "pomoc" or t.id == "odbior" or t.id == "widgety") and 72 or 88)
    if prev then b:SetPoint("LEFT", prev, "RIGHT", 4, 0) else b:SetPoint("TOPLEFT", 20, -44) end
    b:SetText(t.name)
    b:SetScript("OnClick", function() selectTab(t.id) end)
    tabs[t.id] = b
    prev = b
    local p = CreateFrame("Frame", nil, f)
    p:SetPoint("TOPLEFT", 24, -76)
    p:SetPoint("BOTTOMRIGHT", -24, 48)
    p:Hide()
    panes[t.id] = p
  end

  -- Informacje
  local info = panes.info
  info.text = info:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  info.text:SetPoint("TOPLEFT", 0, 0)
  info.text:SetWidth(640)
  info.text:SetJustifyH("LEFT")
  info.text:SetSpacing(4)
  local eb = CreateFrame("EditBox", nil, info, "InputBoxTemplate")
  eb:SetSize(620, 20)
  eb:SetPoint("TOPLEFT", 6, -236)
  eb:SetAutoFocus(false)
  eb:SetFontObject("GameFontHighlightSmall")
  eb:SetText(savedPath())
  eb:SetCursorPosition(0)
  eb:SetScript("OnEditFocusGained", function(s) s:HighlightText() end)
  eb:SetScript("OnTextChanged", function(s, user) if user then s:SetText(savedPath()); s:HighlightText() end end)
  eb:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
  local ebNote = info:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  ebNote:SetPoint("TOPLEFT", 0, -262)
  ebNote:SetText("Kliknij pole i Ctrl+C, zeby skopiowac. <KONTO> to folder Twojego konta w WTF\\Account.")

  -- Ustawienia (zbieranie danych jest zawsze wlaczone)
  local st = panes.ustawienia
  st.checks = {
    makeCheck(st, 0, "Okienko z przypomnieniem o zapisie (z boku ekranu; najwyzej co 30 min, nigdy w walce)", "przyp_okno"),
    makeCheck(st, -30, "Przypomnienie o zapisie na czacie (w locie / przy zmianie kontynentu; najwyzej co 10 min)", "przyp_czat"),
    makeCheck(st, -60, "Wskazowka o /ludos na czacie co 60 minut", "wskazowka"),
    makeCheck(st, -90, "Wyswietlaj na czacie, co zapisuje add-on (dla dewelopera)", "debug"),
  }
  st.odbior = makeCheck(st, -130, "Odbieram dane od graczy (tylko oficer / master)", "odbior", function()
    if ns.Announce then ns.Announce(true) end
  end)
  st.odbiorNote = st:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  st.odbiorNote:SetPoint("TOPLEFT", 30, -156)
  st.odbiorNote:SetWidth(680)
  st.odbiorNote:SetJustifyH("LEFT")
  local off1 = st:CreateFontString(nil, "OVERLAY", "GameFontDisable")
  off1:SetPoint("TOPLEFT", 4, -200)
  off1:SetWidth(700)
  off1:SetJustifyH("LEFT")
  off1:SetText("Zbieranie danych jest zawsze wlaczone. Wysylka do oficerow jest automatyczna (w tle, poza walka). Stan: /ludos wymiana\nZapis pliku: /reload (albo przycisk na dole). Gra nie pozwala add-onowi zapisac pliku samemu.")

  -- Widgety
  local wg = panes.widgety
  local wgT = wg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  wgT:SetPoint("TOPLEFT", 0, 0)
  wgT:SetText("Killtracker (testowy, domyslnie wylaczony)")
  local wgD = wg:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  wgD:SetPoint("TOPLEFT", 0, -18)
  wgD:SetWidth(700)
  wgD:SetJustifyH("LEFT")
  wgD:SetText("Ostatnie zabojstwa ostatnio zabitego moba: czas do zabicia (od pierwszego ataku), zloto i wartosc przedmiotow u kupca.\n* = zabity w grupie. Srednia i porownanie ze starszymi zabojstwami na dole. Okienko przesuwasz mysza.")
  wg.checks = {
    makeCheck(wg, -50, "Pokaz Killtracker", "kt_pokaz", function() ns.KT_Apply() end),
    makeCheck(wg, -80, "Zablokuj (nie da sie przesunac, klikniecia przechodza przez okienko)", "kt_lock", function() ns.KT_Apply() end),
  }
  local aL = wg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  aL:SetPoint("TOPLEFT", 30, -118)
  aL:SetText("Przezroczystosc:")
  local aM = CreateFrame("Button", nil, wg, "UIPanelButtonTemplate")
  aM:SetSize(26, 20); aM:SetPoint("TOPLEFT", 130, -114); aM:SetText("-")
  aM:SetScript("OnClick", function() ns.KT_Alpha(-0.1); ns.RefreshWindow() end)
  wg.alpha = wg:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  wg.alpha:SetPoint("LEFT", aM, "RIGHT", 8, 0)
  wg.alpha:SetWidth(44)
  local aP = CreateFrame("Button", nil, wg, "UIPanelButtonTemplate")
  aP:SetSize(26, 20); aP:SetPoint("LEFT", wg.alpha, "RIGHT", 4, 0); aP:SetText("+")
  aP:SetScript("OnClick", function() ns.KT_Alpha(0.1); ns.RefreshWindow() end)
  local nL = wg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  nL:SetPoint("TOPLEFT", 30, -150)
  nL:SetText("Ile zabojstw:")
  wg.counts = {}
  local cx = 130
  for _, n in ipairs({ 5, 8, 10, 20 }) do
    local b = CreateFrame("Button", nil, wg, "UIPanelButtonTemplate")
    b:SetSize(40, 20)
    b:SetPoint("TOPLEFT", cx, -146)
    b:SetText(tostring(n))
    b:SetScript("OnClick", function() ns.U().kt_ile = n; ns.KT_Apply(); ns.RefreshWindow() end)
    b.n = n
    wg.counts[#wg.counts + 1] = b
    cx = cx + 46
  end
  local rp = CreateFrame("Button", nil, wg, "UIPanelButtonTemplate")
  rp:SetSize(160, 22)
  rp:SetPoint("TOPLEFT", 28, -184)
  rp:SetText("Przywroc pozycje")
  rp:SetScript("OnClick", function() ns.KT_ResetPos() end)
  local wgN = wg:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  wgN:SetPoint("TOPLEFT", 0, -224)
  wgN:SetText("Szybko: /ludos kt - pokaz / ukryj.")
  local zwT = wg:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  zwT:SetPoint("TOPLEFT", 0, -250)
  zwT:SetText("Stan zapisu")
  local zwD = wg:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  zwD:SetPoint("TOPLEFT", 0, -268)
  zwD:SetWidth(700)
  zwD:SetJustifyH("LEFT")
  zwD:SetText("Male okienko z boku: ile zdarzen czeka w pamieci gry na zapis do pliku i ile minut minelo od zapisu. Kolor: zielony / zolty / czerwony.")
  wg.checks[#wg.checks + 1] = makeCheck(wg, -288, "Pokaz widget stanu zapisu", "zw_pokaz", function() ns.ZW_Apply() end)
  local zr = CreateFrame("Button", nil, wg, "UIPanelButtonTemplate")
  zr:SetSize(160, 22)
  zr:SetPoint("TOPLEFT", 300, -288)
  zr:SetText("Przywroc pozycje")
  zr:SetScript("OnClick", function() ns.U().zw_pos = nil; ns.ZW_Apply() end)

  -- Magazyn: zdarzenia
  local ev = panes.zdarzenia
  local prevS = CreateFrame("Button", nil, ev, "UIPanelButtonTemplate")
  prevS:SetSize(30, 20); prevS:SetPoint("TOPLEFT", 0, 0); prevS:SetText("<")
  local nextS = CreateFrame("Button", nil, ev, "UIPanelButtonTemplate")
  nextS:SetSize(30, 20); nextS:SetPoint("LEFT", prevS, "RIGHT", 120, 0); nextS:SetText(">")
  ev.label = ev:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  ev.label:SetPoint("LEFT", prevS, "RIGHT", 10, 0)
  ev.hint = ev:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  ev.hint:SetPoint("LEFT", nextS, "RIGHT", 12, 0)
  ev.hint:SetText("\"nie\" w kolumnie W pliku = trafi do pliku przy /reload lub wylogowaniu")
  local function shiftSession(d)
    local list = ns.Sessions()
    if #list == 0 then return end
    local cur = viewedSession()
    local idx = #list
    for i, s in ipairs(list) do if s == cur then idx = i end end
    idx = math.max(1, math.min(#list, idx + d))
    sessionView = (list[idx] == ns.S) and nil or list[idx].nr
    lists.zdarzenia.offset = 0
    ns.RefreshWindow()
  end
  prevS:SetScript("OnClick", function() shiftSession(-1) end)
  nextS:SetScript("OnClick", function() shiftSession(1) end)
  lists.zdarzenia = newList(ev, {
    { title = "Zdarzenie", w = 140 }, { title = "Czas serwera", w = 100 }, { title = "Sesja", w = 60 },
    { title = "W pliku", w = 50 }, { title = "Opis", w = 270 },
  }, -30)
  lists.zdarzenia.count = function()
    local s = viewedSession()
    return s and #s.dziennik or 0
  end
  lists.zdarzenia.cell = function(i)
    local s = viewedSession()
    local row = s.dziennik[#s.dziennik - i + 1] -- najnowsze na gorze
    local saved = (s ~= ns.S) or (row.n <= (s.zapisane_do or 0))
    return { ns.NAZWY[row.e] or row.e, fmtT(row.t), "sesja_" .. s.nr,
      saved and { "tak", 0.5, 0.85, 0.5 } or { "nie", 1, 0.82, 0 }, ns.Opis(row) }
  end
  lists.zdarzenia.empty = "Brak zdarzen w tej sesji."

  -- Magazyn: stan wyslania
  local sd = panes.wyslanie
  local sdNote = sd:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  sdNote:SetPoint("TOPLEFT", 0, 0)
  sdNote:SetText("Jedna linia = jedna sesja. Odebrali: ile wierszy sesji potwierdzil kazdy odbiorca (zielone = wszystko).")
  lists.wyslanie = newList(sd, {
    { title = "Sesja", w = 70 }, { title = "Start", w = 100 }, { title = "Koniec", w = 120 },
    { title = "Zdarzen", w = 60 }, { title = "Odebrali", w = 330 },
  }, -24)
  lists.wyslanie.count = function() return #ns.Sessions() end
  lists.wyslanie.cell = function(i)
    local list = ns.Sessions()
    local s = list[#list - i + 1]
    local koniec
    if s.stan == "trwa" then koniec = { "trwa", 1, 0.82, 0 }
    elseif s.stan == "przerwana" then koniec = { fmtShort(s.koniec) .. " (przerw.)", 1, 0.5, 0.4 }
    else koniec = fmtShort(s.koniec) end
    local n = #s.dziennik
    local parts = {}
    local me = UnitName("player")
    for _, r in ipairs(ns.ShownReceivers()) do
      if r ~= me then
        local o = s.odebrali and s.odebrali[r]
        local d = o and o["do"] or 0
        local col = (d >= n) and "|cff80d980" or (d > 0 and "|cffffd100" or "|cffff7366")
        parts[#parts + 1] = string.format("%s%s %d/%d|r", col, r, d, n)
      end
    end
    if #parts == 0 then parts[1] = "|cff888888(jeszcze zaden oficer nie odebral)|r" end
    return { "sesja_" .. s.nr, fmtShort(s.start), koniec, tostring(n), table.concat(parts, "  ") }
  end
  lists.wyslanie.empty = "Brak sesji."

  -- Odbior
  local od = panes.odbior
  od.note = od:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  od.note:SetPoint("TOPLEFT", 0, 0)
  od.note:SetWidth(700)
  od.note:SetJustifyH("LEFT")
  od.rows = {}
  lists.odbior = newList(od, {
    { title = "Nadawca", w = 200 }, { title = "Sesja", w = 70 }, { title = "Wierszy", w = 70 },
    { title = "Paczek", w = 60 }, { title = "Stan", w = 90 }, { title = "Ostatni odbior", w = 120 },
  }, -24)
  lists.odbior.count = function() return #od.rows end
  lists.odbior.cell = function(i)
    local r = od.rows[i]
    local stan = r.rec.stan == "trwa" and { "trwa", 1, 0.82, 0 } or (r.rec.stan == "przerwana" and { "przerwana", 1, 0.5, 0.4 } or tostring(r.rec.stan or "-"))
    local lastT = r.rec.paczki[#r.rec.paczki] and r.rec.paczki[#r.rec.paczki].t
    return { r.key, "sesja_" .. tostring(r.rec.nr or "?"), tostring(r.rec.do_n or 0), tostring(#r.rec.paczki), stan, fmtShort(lastT) }
  end
  lists.odbior.empty = "Nic jeszcze nie odebrano. Dane przychodza, gdy gracze z add-onem sa w grze."

  -- Pomoc
  local hp = panes.pomoc
  hp.text = hp:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
  hp.text:SetPoint("TOPLEFT", 0, 0)
  hp.text:SetWidth(640)
  hp.text:SetJustifyH("LEFT")
  hp.text:SetSpacing(3)
  hp.text:SetText(helpText())

  -- dolne przyciski
  local save = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
  save:SetSize(180, 24)
  save:SetPoint("BOTTOMLEFT", 22, 18)
  save:SetText("Zapisz teraz (/reload)")
  save:SetScript("OnClick", function() ReloadUI() end)
  f.saveInfo = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  f.saveInfo:SetPoint("LEFT", save, "RIGHT", 10, 0)
  local cls = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
  cls:SetSize(90, 24)
  cls:SetPoint("BOTTOMRIGHT", -22, 18)
  cls:SetText("Zamknij")
  cls:SetScript("OnClick", function() f:Hide() end)

  f:SetScript("OnShow", function() ns.RefreshWindow() end)
  f:SetScript("OnUpdate", function(s, elapsed)
    s.acc = (s.acc or 0) + elapsed
    if s.acc >= 1 then s.acc = 0; ns.RefreshWindow() end
  end)
  f:Hide()
  W = f
  selectTab(current)
end

function ns.RefreshWindow()
  if not W or not W:IsShown() then return end
  if not ns.DB then return end
  W.saveInfo:SetText(string.format("Czeka na zapis: %d zdarzen", ns.Unsaved()))
  if current == "info" then
    panes.info.text:SetText(infoText())
  elseif current == "ustawienia" then
    local st = panes.ustawienia
    for _, cb in ipairs(st.checks) do cb:SetChecked(ns.U()[cb.key] and true or false) end
    st.odbior:SetChecked(ns.U().odbior ~= false)
    if ns.IsReceiver() then
      st.odbior:Enable()
      st.odbiorNote:SetText("Wylacz, jesli nie chcesz odbierac danych na tym komputerze (np. slaby internet). Gracze wysla je innym oficerom.")
    else
      st.odbior:Disable()
      st.odbiorNote:SetText("Dotyczy tylko oficerow (ranga 0-" .. tostring(ns.CONFIG.RANGA_MAX or 1) .. " w gildii).")
    end
  elseif current == "zdarzenia" then
    local s = viewedSession()
    panes.zdarzenia.label:SetText(s and ("sesja_" .. s.nr .. (s == ns.S and " (biezaca)" or "")) or "-")
    lists.zdarzenia:Refresh()
  elseif current == "widgety" then
    for _, cb in ipairs(panes.widgety.checks) do cb:SetChecked(ns.U()[cb.key] and true or false) end
    panes.widgety.alpha:SetText(math.floor((ns.U().kt_alpha or 0.85) * 100 + 0.5) .. "%")
    for _, b in ipairs(panes.widgety.counts) do
      if b.n == ns.U().kt_ile then b:LockHighlight() else b:UnlockHighlight() end
    end
  elseif current == "wyslanie" then
    lists.wyslanie:Refresh()
  elseif current == "odbior" then
    local od = panes.odbior
    wipe(od.rows)
    local O = ns.OdbiorDB and ns.OdbiorDB()
    if not ns.IsReceiver() then
      od.note:SetText("Nie jestes na liscie odbiorcow. Tu widza dane tylko oficerowie i master.")
    elseif not O then
      od.note:SetText("|cffff7366Jestes odbiorca, ale add-on LUDOS-on Odbior jest wylaczony.|r Wlacz go na liscie add-onow.")
    else
      local gr, rows = 0, 0
      for key, g in pairs(O.gracze) do
        gr = gr + 1
        for nr, rec in pairs(g.sesje) do
          od.rows[#od.rows + 1] = { key = key, nr = nr, rec = rec, t = (rec.paczki[#rec.paczki] and rec.paczki[#rec.paczki].t) or 0 }
          rows = rows + (rec.do_n or 0)
        end
      end
      table.sort(od.rows, function(a, b) return a.t > b.t end)
      od.note:SetText(string.format("Odebrane: %d graczy, %d sesji, %d wierszy, %.1f KB w pliku LUDOS-on_Odbior.lua",
        gr, #od.rows, rows, (O.meta.rozmiar or 0) / 1024))
    end
    lists.odbior:Refresh()
  end
end

function ns.ToggleWindow()
  if not W then create() end
  if W:IsShown() then W:Hide() else W:Show() end
end
