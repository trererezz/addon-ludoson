-- LUDOS-on - konfiguracja (0.4.0, premiera WoW Forever).
-- Odbiorcy danych = czlonkowie gildii z ranga o numerze <= RANGA_MAX (0 = mistrz gildii, 1 = oficerowie),
-- wg listy gildii z serwera. Ranga pochodzi z serwera, wiec edycja tego pliku u gracza nic nie zmienia
-- u innych (kazdy nadawca sprawdza range u siebie).
-- ODBIORCY: zapasowa lista imion (dodatkowi odbiorcy poza rangami). MASTERS: kto moze zmieniac te liste w grze.

local ADDON, ns = ...

ns.CONFIG = {
  RANGA_MAX = 1,
  MASTERS = {},
  ODBIORCY = {},
}
