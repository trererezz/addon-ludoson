-- LUDOS-on 0.4.0 - PvP w swiecie: wrogowie spotkani, zabojstwa graczy z wrogiej frakcji i smierci od nich.
--   WROG_SPOTKANY  - gracz z innej frakcji w celu, pod myszka albo z tabliczka nad glowa:
--                    1 wiersz na wroga na 15 min (pole spotkanie = ktore spotkanie w tej sesji),
--                    najwyzej 120 wierszy na godzine, pomijane na battlegroundach i arenach.
--   PVP_ZABOJSTWO  - zabity gracz (kto, kiedy, gdzie, z jakiej gildii, czy moj cios, tekst honoru z czatu).
--   PVP_SMIERC     - smierc od gracza (kto, czym, gdzie, z jakiej gildii).
-- Gildia, poziom, klasa i rasa wroga pochodza z ostatniego razu, gdy byl widoczny (cel / myszka / tabliczka);
-- gdy go nie widzielismy - klasa i rasa z GetPlayerInfoByGUID (bez gildii).

local ADDON, ns = ...
local Log, now = ns.Log, ns.now

local SPOT_GAP, HOUR_CAP, CACHE_MAX = 900, 120, 600
local enemies, nenemies = {}, 0 -- [guid] = { nazwa, realm, lvl, klasa, rasa, frakcja, gildia, ranga_g, ostatni_wiersz, spotkania, widziany }
local hourStart, hourCount = 0, 0
local recentKill = {}           -- [guid] = GetTime() (bez dubli)
local lastHonor                 -- { tekst, gt }

local function inBattle()
  local inInst, t = IsInInstance()
  return inInst and (t == "pvp" or t == "arena") or false
end

local function clean(v) if ns.Hidden(v) then return nil end return v end

local function readEnemy(unit)
  local ok, isPlayer = pcall(UnitIsPlayer, unit)
  if not ok or ns.Hidden(isPlayer) or not isPlayer then return nil end
  local guid = UnitGUID(unit)
  if ns.Hidden(guid) or not guid then return nil end
  local myF = UnitFactionGroup("player")
  local f = UnitFactionGroup(unit)
  if ns.Hidden(f) or not f or f == myF then return nil end
  local name, realm = UnitName(unit)
  local _, klasa = UnitClass(unit)
  local _, rasa = UnitRace(unit)
  local gildia, rangaG = GetGuildInfo(unit)
  return guid, {
    nazwa = clean(name), realm = clean(realm), lvl = clean(UnitLevel(unit)), klasa = clean(klasa), rasa = clean(rasa),
    frakcja = f, gildia = clean(gildia), ranga_g = clean(rangaG),
  }
end

local function spotted(unit)
  local guid, info = readEnemy(unit)
  if not guid then return end
  local e = enemies[guid]
  if not e then
    if nenemies >= CACHE_MAX then wipe(enemies); nenemies = 0 end
    e = { spotkania = 0, ostatni_wiersz = 0 }
    enemies[guid] = e
    nenemies = nenemies + 1
  end
  for k, v in pairs(info) do if v ~= nil then e[k] = v end end
  e.widziany = now()
  if inBattle() then return end
  local t = now()
  if t - e.ostatni_wiersz < SPOT_GAP then return end
  if t - hourStart >= 3600 then hourStart, hourCount = t, 0 end
  if hourCount >= HOUR_CAP then return end
  hourCount = hourCount + 1
  e.ostatni_wiersz = t
  e.spotkania = e.spotkania + 1
  local mapa, x, y = ns.Position()
  Log("WROG_SPOTKANY", {
    guid = guid, nazwa = e.nazwa, realm = e.realm, lvl = e.lvl, klasa = e.klasa, rasa = e.rasa, frakcja = e.frakcja,
    gildia = e.gildia, ranga_g = e.ranga_g, spotkanie = e.spotkania, jak = unit:match("^nameplate") and "tabliczka" or unit,
    strefa = GetZoneText(), pod = GetSubZoneText(), mapa = mapa, x = x, y = y, moj_lvl = UnitLevel("player"),
  })
end

ns.On("PLAYER_TARGET_CHANGED", function() spotted("target") end)
ns.On("UPDATE_MOUSEOVER_UNIT", function() spotted("mouseover") end)
ns.On("NAME_PLATE_UNIT_ADDED", function(unit) if unit then spotted(unit) end end)

-- dane gracza: z pamieci spotkanych, a gdy go nie ma - z GetPlayerInfoByGUID
local function who(guid, fallbackName)
  local d = {}
  local e = guid and enemies[guid]
  if e then
    for _, k in ipairs({ "nazwa", "realm", "lvl", "klasa", "rasa", "frakcja", "gildia", "ranga_g" }) do d[k] = e[k] end
    d.dane_z = "widziany"
  elseif guid and GetPlayerInfoByGUID then
    local ok, _, klasa, _, rasa, _, name, realm = pcall(GetPlayerInfoByGUID, guid)
    if ok then
      d.nazwa, d.klasa, d.rasa = clean(name), clean(klasa), clean(rasa)
      realm = clean(realm)
      if realm and realm ~= "" then d.realm = realm end
      d.dane_z = "guid"
    end
  end
  if not d.nazwa and fallbackName and not ns.Hidden(fallbackName) then d.nazwa = fallbackName end
  return d
end
ns.EnemyInfo = who

ns.On("CHAT_MSG_COMBAT_HONOR_GAIN", function(text)
  if type(text) ~= "string" or ns.Hidden(text) then return end
  lastHonor = { tekst = text, gt = GetTime() }
end)

function ns.PvpKill(targetGUID, attackerGUID, targetName, attackerName)
  if not targetGUID then return end
  local gt = GetTime()
  if recentKill[targetGUID] and gt - recentKill[targetGUID] < 10 then return end
  recentKill[targetGUID] = gt
  local mapa, x, y = ns.Position()
  local strefa, pod, bg = GetZoneText(), GetSubZoneText(), inBattle()
  local mine = attackerGUID ~= nil and (attackerGUID == ns.state.myGUID or attackerGUID == ns.state.petGUID) or false
  local attacker = (not mine and attackerGUID) and (attackerName or (GetPlayerInfoByGUID and select(7, pcall(GetPlayerInfoByGUID, attackerGUID)))) or nil
  C_Timer.After(2, function() -- honor z czatu przychodzi chwile po zabiciu
    local d = who(targetGUID, targetName)
    d.guid = targetGUID
    d.moj_cios = mine
    d.zabil = clean(attacker)
    d.strefa, d.pod, d.mapa, d.x, d.y, d.bg = strefa, pod, mapa, x, y, bg
    d.moj_lvl = UnitLevel("player")
    if lastHonor and GetTime() - lastHonor.gt <= 4 then d.honor_tekst = lastHonor.tekst; lastHonor = nil end
    Log("PVP_ZABOJSTWO", d)
  end)
end

function ns.PvpDeath(info)
  if not info then return end
  local guid = info.guid
  if ns.Hidden(guid) then guid = nil end
  local d = who(guid, info.nazwa)
  d.guid = guid
  d.czar, d.czar_id, d.obrazenia = info.czar, info.czar_id, info.obrazenia
  local mapa, x, y = ns.Position()
  d.strefa, d.pod, d.mapa, d.x, d.y, d.bg = GetZoneText(), GetSubZoneText(), mapa, x, y, inBattle()
  d.moj_lvl = UnitLevel("player")
  Log("PVP_SMIERC", d)
end
