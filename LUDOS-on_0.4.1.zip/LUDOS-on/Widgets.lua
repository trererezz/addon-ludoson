-- LUDOS-on 0.4.0 - widgety. Killtracker: ostatnie zabojstwa ostatnio zabitego moba
-- (czas do zabicia, zloto, wartosc przedmiotow), srednie i porownanie ze starszymi zabojstwami.
-- Ustawienia w oknie /ludos -> Widgety (pokaz, przezroczystosc, blokada, liczba zabojstw).

local ADDON, ns = ...
local KT
local ROW_H, WIDTH = 14, 270
local MAX_ROWS = 20
local GOLD = "|cffffd100"

local function money(c)
  c = math.floor(tonumber(c) or 0)
  if c <= 0 then return "-" end
  local g, s, m = math.floor(c / 10000), math.floor((c % 10000) / 100), c % 100
  if g > 0 then return string.format("%dg %ds", g, s) end
  if s > 0 then return string.format("%ds %dm", s, m) end
  return m .. "m"
end

local function avg(list, field, from, to)
  local sum, n = 0, 0
  for i = from, to do
    local v = list[i] and list[i][field]
    if type(v) == "number" then sum = sum + v; n = n + 1 end
  end
  return n > 0 and (sum / n) or nil
end

local function pct(newv, oldv)
  if not newv or not oldv or oldv == 0 then return nil end
  return math.floor((newv - oldv) / oldv * 100 + 0.5)
end

local function savePos(f)
  local point, _, _, x, y = f:GetPoint(1)
  ns.U().kt_pos = { point or "CENTER", math.floor((x or 0) + 0.5), math.floor((y or 0) + 0.5) }
end

local function build()
  local f = CreateFrame("Frame", "LUDOSonKillTracker", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
  f:SetSize(WIDTH, 60)
  f:SetFrameStrata("MEDIUM")
  f:SetClampedToScreen(true)
  f:SetMovable(true)
  f:EnableMouse(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", function(s) if not ns.U().kt_lock then s:StartMoving() end end)
  f:SetScript("OnDragStop", function(s) s:StopMovingOrSizing(); savePos(s) end)
  if f.SetBackdrop then
    f:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
      edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 12,
      insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    f:SetBackdropColor(0, 0, 0, 0.8)
  end

  f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  f.title:SetPoint("TOPLEFT", 8, -7)
  f.title:SetWidth(WIDTH - 16)
  f.title:SetJustifyH("LEFT")

  local hdr = { { "#", 18 }, { "Czas", 58 }, { "Zloto", 60 }, { "Przedmioty", 70 }, { "", 40 } }
  f.cols = hdr
  local x = 8
  for _, h in ipairs(hdr) do
    local fs = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    fs:SetPoint("TOPLEFT", x, -24)
    fs:SetWidth(h[2]); fs:SetJustifyH("LEFT")
    fs:SetText(h[1])
    x = x + h[2]
  end
  f.rows = {}
  for r = 1, MAX_ROWS do
    local row = {}
    local cx = 8
    for c, h in ipairs(hdr) do
      local fs = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
      fs:SetPoint("TOPLEFT", cx, -24 - r * ROW_H)
      fs:SetWidth(h[2]); fs:SetJustifyH("LEFT")
      if fs.SetWordWrap then fs:SetWordWrap(false) end
      row[c] = fs
      cx = cx + h[2]
    end
    f.rows[r] = row
  end
  f.foot1 = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  f.foot1:SetJustifyH("LEFT"); f.foot1:SetWidth(WIDTH - 16)
  f.foot2 = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  f.foot2:SetJustifyH("LEFT"); f.foot2:SetWidth(WIDTH - 16)
  f:Hide()
  KT = f
  ns.KT = f
end

local function placeFooter(f, nrows)
  local y = -24 - (nrows + 1) * ROW_H - 4
  f.foot1:ClearAllPoints(); f.foot1:SetPoint("TOPLEFT", 8, y)
  f.foot2:ClearAllPoints(); f.foot2:SetPoint("TOPLEFT", 8, y - ROW_H)
  f:SetHeight(-(y - 2 * ROW_H) + 8)
end

function ns.KT_Update()
  if not KT or not KT:IsShown() then return end
  local u = ns.U()
  local ile = u.kt_ile or 8
  local m = ns.KT_History and ns.KT_History() or nil
  for r = 1, MAX_ROWS do
    for c = 1, #KT.cols do KT.rows[r][c]:SetText("") end
  end
  if not m or #m.lista == 0 then
    KT.title:SetText("Killtracker |cff888888(testowy)|r")
    KT.rows[1][2]:SetText("Zabij moba, zeby zobaczyc wyniki.")
    KT.rows[1][2]:SetWidth(WIDTH - 30)
    KT.foot1:SetText("")
    KT.foot2:SetText("")
    placeFooter(KT, 1)
    return
  end
  KT.rows[1][2]:SetWidth(KT.cols[2][2])
  local L = m.lista
  local n = #L
  local from = math.max(1, n - ile + 1)
  KT.title:SetText(string.format("%s  |cff888888(%d z %d, testowy)|r", tostring(m.nazwa), n - from + 1, n))
  local r = 0
  for i = n, from, -1 do -- najnowsze na gorze
    local k = L[i]
    r = r + 1
    local row = KT.rows[r]
    row[1]:SetText(tostring(n - i + 1))
    row[2]:SetText(k.ttk and ns.Sec1(k.ttk) or "|cff888888-|r")
    if k.czeka then
      row[3]:SetText("|cff888888...|r")
      row[4]:SetText("|cff888888...|r")
    elseif k.loot then
      row[3]:SetText(money(k.zloto))
      row[4]:SetText(money(k.wartosc))
    else
      row[3]:SetText("|cff888888-|r")
      row[4]:SetText("|cff888888-|r")
    end
    row[5]:SetText((k.grupa and "|cff4fc3f7*|r" or "") .. ((k.loot or k.czeka) and "" or "|cff888888 brak lootu|r"))
  end
  placeFooter(KT, r)
  -- srednie z pokazanych zabojstw; porownanie z wczesniejszymi z historii (max 20)
  local aT = avg(L, "ttk", from, n)
  local lootL = {}
  for i = from, n do if L[i].loot then lootL[#lootL + 1] = L[i] end end
  local aG = avg(lootL, "zloto", 1, #lootL)
  local aV = avg(lootL, "wartosc", 1, #lootL)
  KT.foot1:SetText(string.format("%sSrednio:|r %s | %s | %s", GOLD, aT and ns.Sec1(aT) or "-", money(aG), money(aV)))
  if from > 1 then
    local oT = avg(L, "ttk", 1, from - 1)
    local p = pct(aT, oT)
    if p then
      local col = p <= 0 and "|cff55dd55" or "|cffff6655"
      KT.foot2:SetText(string.format("Czas %s%+d%%|r wzgledem %d starszych zabojstw", col, p, from - 1))
    else
      KT.foot2:SetText("")
    end
  else
    KT.foot2:SetText("* = w grupie. Porownanie pojawi sie po " .. (ile + 1) .. " zabojstwach.")
  end
end

function ns.KT_Apply()
  if not ns.DB then return end
  if not KT then build() end
  local u = ns.U()
  KT:ClearAllPoints()
  local p = u.kt_pos
  if p then KT:SetPoint(p[1], UIParent, p[1], p[2], p[3]) else KT:SetPoint("RIGHT", UIParent, "RIGHT", -60, 80) end
  KT:SetAlpha(u.kt_alpha or 0.85)
  KT:EnableMouse(not u.kt_lock)
  if u.kt_pokaz then KT:Show() else KT:Hide() end
  ns.KT_Update()
end

function ns.KT_ResetPos()
  ns.U().kt_pos = nil
  ns.KT_Apply()
end

function ns.KT_Alpha(delta)
  local u = ns.U()
  local a = math.floor(((u.kt_alpha or 0.85) + delta) * 100 + 0.5) / 100
  u.kt_alpha = math.max(0.2, math.min(1, a))
  ns.KT_Apply()
end

-------------------------------------------------------------------------------
-- Widget stanu zapisu (kazdy gracz): ile danych czeka w pamieci i czy to dobry moment na /reload.
-- Bez przycisku - tylko tekst "wpisz /reload".
-------------------------------------------------------------------------------
local ZW
local DOT = { [0] = "|cff55dd55", [1] = "|cffffd100", [2] = "|cffff4444" }
local HINT = { [0] = "zapis aktualny", [1] = "dobry moment: wpisz /reload", [2] = "! duzo do stracenia przy crashu - wpisz /reload" }

local function buildZW()
  local f = CreateFrame("Frame", "LUDOSonZapisWidget", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
  f:SetSize(250, 36)
  f:SetFrameStrata("LOW")
  f:SetClampedToScreen(true)
  f:SetMovable(true)
  f:EnableMouse(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", function(s)
    s:StopMovingOrSizing()
    local p, _, _, x, y = s:GetPoint(1)
    ns.U().zw_pos = { p or "RIGHT", math.floor((x or 0) + 0.5), math.floor((y or 0) + 0.5) }
  end)
  if f.SetBackdrop then
    f:SetBackdrop({ bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
      edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 10,
      insets = { left = 3, right = 3, top = 3, bottom = 3 } })
    f:SetBackdropColor(0, 0, 0, 0.6)
  end
  f.l1 = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  f.l1:SetPoint("TOPLEFT", 7, -5); f.l1:SetWidth(238); f.l1:SetJustifyH("LEFT")
  f.l2 = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
  f.l2:SetPoint("TOPLEFT", 7, -19); f.l2:SetWidth(238); f.l2:SetJustifyH("LEFT")
  local acc = 1
  f:SetScript("OnUpdate", function(s, el)
    acc = acc + el
    if acc < 1 then return end
    acc = 0
    if not ns.SaveState then return end
    local level, n, mins = ns.SaveState()
    s.l1:SetText(string.format("%s%s|r LUDOS-on: w pamieci %d zdarzen, od zapisu %d min", DOT[level], level == 2 and "(!)" or "(o)", n, mins))
    s.l2:SetText(HINT[level])
  end)
  ZW = f
end

function ns.ZW_Apply()
  if not ns.DB then return end
  if not ZW then buildZW() end
  local u = ns.U()
  ZW:ClearAllPoints()
  local p = u.zw_pos
  if p then ZW:SetPoint(p[1], UIParent, p[1], p[2], p[3]) else ZW:SetPoint("RIGHT", UIParent, "RIGHT", -20, 220) end
  if u.zw_pokaz then ZW:Show() else ZW:Hide() end
end

ns.AddHook("ready", function() ns.KT_Apply(); ns.ZW_Apply() end)
