-- LUDOS-on 0.4.0 - walka: jeden wiersz WALKA na walke (od wejscia w walke do wyjscia) i wiersz SMIERC.
-- Dwie drogi, zalezne od gry:
--   Classic (Era/Anniversary): combat log jak w 0.3.1 (zrodlo = "combatlog").
--   Forever / retail: combat log jest zablokowany dla add-onow. Po walce czytamy wbudowany licznik
--     obrazen gry (C_DamageMeter, sesja "biezaca") - zadane, otrzymane, leczenie, top czary (zrodlo = "licznik").
--     Smierc z podsumowania smierci gry (C_DeathRecap): zabojca = ostatnie trafienie, do 5 trafien.
-- Wartosci, ktore gra ukryje (secret values), zapisujemy jako "ukryte" (licznik w DIAG).
-- Pojedyncze zabojstwa (czas do zabicia, loot) zapisuje Kills.lua jako wiersz ZABOJSTWO.

local ADDON, ns = ...
local Log, now = ns.Log, ns.now
local band = bit.band
local TYPE_PLAYER = COMBATLOG_OBJECT_TYPE_PLAYER or 0x00000400


local F, closing   -- biezaca walka, walka w trakcie zamykania
local hits = {}    -- ostatnie trafienia w gracza (do ustalenia zabojcy)

local function newFight()
  return { start = now(), gt = GetTime(), cele = {}, ncele = 0, zadane = 0, otrzymane = 0,
    lecz_z = 0, lecz_o = 0, czary = {}, dotkniete = {}, zabici = {}, nzab = 0, smierc = false, pvp = false,
    chybienia = 0, uniki = 0, celeId = {}, celeGracze = {} }
end

-- cele: nazwy (jak w 0.3.0, ncele = liczba roznych nazw) + osobno NPC ID mobow i GUID graczy
local function addTarget(fight, name, guid)
  if name and not fight.cele[name] then fight.cele[name] = true; fight.ncele = fight.ncele + 1 end
  local npc = ns.NpcID(guid)
  if npc then fight.celeId[npc] = true
  elseif ns.PlayerGUID(guid) then fight.celeGracze[guid] = true end
end

local function addKill(fight, guid, name)
  if not fight or not guid or fight.zabici[guid] then return end
  fight.zabici[guid] = name or "?"
  fight.nzab = fight.nzab + 1
  ns.state.lastKillGT = GetTime()
end

local function finalize(fight)
  if not fight then return end
  local gtEnd = fight.gtEnd or GetTime()
  local cele = {}
  for name in pairs(fight.cele) do cele[#cele + 1] = name end
  table.sort(cele)
  local celeTxt = table.concat(cele, ", ", 1, math.min(#cele, 5)) .. (#cele > 5 and (" +" .. (#cele - 5)) or "")
  local czary = {}
  for name, n in pairs(fight.czary) do czary[#czary + 1] = { name, n } end
  table.sort(czary, function(a, b) return a[2] > b[2] end)
  local top = {}
  for i = 1, math.min(#czary, 5) do top[i] = czary[i][1] .. " x" .. czary[i][2] end
  local zabici, zl, zabiciId = {}, 0, {}
  for guid, name in pairs(fight.zabici) do
    zl = zl + 1
    if zl <= 10 then
      zabici[zl] = name
      zabiciId[#zabiciId + 1] = ns.NpcID(guid)
    end
  end
  table.sort(zabici)
  table.sort(zabiciId)
  local function keys(t, limit)
    local out = {}
    for k in pairs(t) do out[#out + 1] = k end
    table.sort(out, function(a, b) return tostring(a) < tostring(b) end)
    while #out > limit do table.remove(out) end
    return (#out > 0) and out or nil
  end
  local row = {
    start = fight.start, koniec = fight.koniec or now(), sek = ns.Round1(gtEnd - fight.gt),
    cele = (#cele > 0) and celeTxt or nil, ncele = fight.ncele,
    zabici = (#zabici > 0) and zabici or nil, zabici_ile = fight.nzab, smierc = fight.smierc, pvp = fight.pvp,
    cele_id = keys(fight.celeId, 20), cele_gracze = keys(fight.celeGracze, 10),
    zabici_id = (#zabiciId > 0) and zabiciId or nil,
  }
  if ns.isClassic then
    row.zrodlo = "combatlog"
    row.zadane, row.otrzymane, row.lecz_z, row.lecz_o = fight.zadane, fight.otrzymane, fight.lecz_z, fight.lecz_o
    row.chybienia, row.uniki, row.czary = fight.chybienia, fight.uniki, top
  else
    row.zrodlo = "licznik"
    ns.ReadMeter(row)
  end
  Log("WALKA", row)
end

-------------------------------------------------------------------------------
-- Forever / retail: wbudowany licznik obrazen gry (C_DamageMeter), sesja "biezaca"
-------------------------------------------------------------------------------
local DM = C_DamageMeter
local DMT = (Enum and Enum.DamageMeterType) or {}
local SESS_CURRENT = (Enum and Enum.DamageMeterSessionType and Enum.DamageMeterSessionType.Current) or 1

local function val(v, kind)
  if ns.Hidden(v) then return ns.Safe(v, kind) end
  if v == nil then return nil end
  if type(v) == "number" then return math.floor(v + 0.5) end
  return v
end

-- moj wpis w sesji danego typu; zwraca (zrodlo, sesja) albo (nil, powod)
local function mySource(mtype)
  if not (DM and DM.GetCombatSessionFromType) or mtype == nil then return nil, "brak" end
  local ok, s = pcall(DM.GetCombatSessionFromType, SESS_CURRENT, mtype)
  if not ok then return nil, "blad" end
  if type(s) ~= "table" then return nil, "brak_sesji" end
  if ns.Hidden(s.combatSources) then return nil, "ukryte" end
  for _, src in ipairs(s.combatSources or {}) do
    if src.isLocalPlayer then
      if ns.DiagShape then ns.DiagShape("licznik_zrodlo", src) end
      return src, s
    end
  end
  return nil, "brak_gracza"
end

function ns.ReadMeter(row)
  local stan = {}
  local dmg, sess = mySource(DMT.DamageDone)
  if dmg then
    row.zadane = val(dmg.totalAmount, "licznik")
    row.dps = val(dmg.amountPerSecond, "licznik")
    if sess then row.sek_dm = val(sess.durationSeconds, "licznik") end
  end
  stan[#stan + 1] = "obr:" .. (dmg and "ok" or sess)
  local taken, r2 = mySource(DMT.DamageTaken)
  if taken then row.otrzymane = val(taken.totalAmount, "licznik") end
  stan[#stan + 1] = "otrz:" .. (taken and "ok" or r2)
  local heal, r3 = mySource(DMT.HealingDone)
  if heal then row.lecz_z = val(heal.totalAmount, "licznik") end
  stan[#stan + 1] = "lecz:" .. (heal and "ok" or r3)
  -- top 5 czarow (ID czaru:obrazenia) z rozbicia mojego wpisu
  if dmg and DM.GetCombatSessionSourceFromType and ns.state.myGUID then
    local ok, ss = pcall(DM.GetCombatSessionSourceFromType, SESS_CURRENT, DMT.DamageDone, ns.state.myGUID, nil)
    if ok and type(ss) == "table" and not ns.Hidden(ss.combatSpells) then
      if ns.DiagShape then ns.DiagShape("licznik_czary", ss) end
      local list = {}
      for _, sp in ipairs(ss.combatSpells or {}) do
        if not ns.Hidden(sp.totalAmount) and not ns.Hidden(sp.spellID) then
          list[#list + 1] = { sp.spellID, tonumber(sp.totalAmount) or 0 }
        else
          list[#list + 1] = { "ukryte", 0 }
        end
      end
      table.sort(list, function(a, b) return a[2] > b[2] end)
      local out = {}
      for i = 1, math.min(#list, 5) do out[i] = tostring(list[i][1]) .. ":" .. math.floor(list[i][2] + 0.5) end
      if #out > 0 then row.czary_dm = out end
    elseif ok and type(ss) == "table" then
      stan[#stan + 1] = "czary:ukryte"
    end
  end
  row.licznik = table.concat(stan, ",")
end

ns.On("PLAYER_REGEN_DISABLED", function()
  ns.state.combatGT = GetTime() -- dla czasu do zabicia w Kills.lua (Forever)
  if F then return end
  F = newFight()
end)

-- Kills.lua (Forever) zglasza zabitych tutaj
function ns.FightKill(guid, name)
  local target = F or closing
  if not target then return end
  addKill(target, guid or ("n:" .. tostring(name) .. ":" .. GetTime()), name)
end
function ns.FightTarget(name, guid)
  if F then addTarget(F, name, guid) end
end

ns.On("PLAYER_REGEN_ENABLED", function()
  if not F then return end
  local done = F
  F = nil
  done.gtEnd, done.koniec = GetTime(), now() -- koniec walki liczymy od tej chwili, nie od zapisu
  closing = done
  -- zabici moga przyjsc chwile po koncu walki; licznik gry (Forever) potrzebuje chwili na ostatnie dane
  C_Timer.After(ns.isClassic and 0.5 or 1.5, function()
    finalize(done)
    if closing == done then closing = nil end
  end)
end)

ns.On("UNIT_PET", function(unit) if unit == "player" then ns.state.petGUID = UnitGUID("pet") end end)

local DAMAGE = { SWING_DAMAGE = 1, RANGE_DAMAGE = 2, SPELL_DAMAGE = 2, SPELL_PERIODIC_DAMAGE = 2, ENVIRONMENTAL_DAMAGE = 3 }
local HEAL = { SPELL_HEAL = true, SPELL_PERIODIC_HEAL = true }
local MISS = { SWING_MISSED = 1, RANGE_MISSED = 2, SPELL_MISSED = 2, SPELL_PERIODIC_MISSED = 2 }
local MELEE = "Atak wrecz"

if ns.isClassic then
ns.On("COMBAT_LOG_EVENT_UNFILTERED", function()
  local _, sub, _, srcGUID, srcName, srcFlags, _, dstGUID, dstName, dstFlags = CombatLogGetCurrentEventInfo()
  local me, pet = ns.state.myGUID, ns.state.petGUID
  local mine = (srcGUID == me) or (pet and srcGUID == pet)
  local toMe = (dstGUID == me)
  local target = F or closing

  if sub == "UNIT_DIED" then
    if target and target.dotkniete[dstGUID] then addKill(target, dstGUID, dstName) end
    if toMe and target then target.smierc = true end
    return
  elseif sub == "PARTY_KILL" then
    addKill(target, dstGUID, dstName)
    if ns.PlayerGUID(dstGUID) and ns.PvpKill then ns.PvpKill(dstGUID, srcGUID, dstName, srcName) end
    return
  end

  if sub == "SPELL_CAST_SUCCESS" and srcGUID == me and ns.SondaCzar then
    local spellId, spellName = select(12, CombatLogGetCurrentEventInfo())
    ns.SondaCzar(spellId, spellName)
  end
  if not mine and not toMe then return end
  local kind = DAMAGE[sub]

  local miss = MISS[sub]

  -- atak wrecz gracza (trafiony albo nie) liczymy jak czar "Atak wrecz"
  if (sub == "SWING_DAMAGE" or sub == "SWING_MISSED") and srcGUID == me and target then
    target.czary[MELEE] = (target.czary[MELEE] or 0) + 1
  end

  if miss then
    if toMe and target then
      target.uniki = target.uniki + 1
      addTarget(target, srcName, srcGUID)
    elseif mine and target and dstGUID ~= me and dstGUID ~= pet then
      target.chybienia = target.chybienia + 1
      target.dotkniete[dstGUID] = dstName or "?"
      addTarget(target, dstName, dstGUID)
    end
  elseif kind then
    local amount, overkill, spellName, spellId, envType
    if kind == 1 then
      amount, overkill = select(12, CombatLogGetCurrentEventInfo())
      spellName, spellId = "Atak wrecz", 0
    elseif kind == 2 then
      spellId, spellName, _, amount, overkill = select(12, CombatLogGetCurrentEventInfo())
    else
      envType, amount, overkill = select(12, CombatLogGetCurrentEventInfo())
      spellName, spellId = envType, 0
    end
    amount = tonumber(amount) or 0
    if toMe then
      local h = { gt = GetTime(), zrodlo = srcName or (envType and "Otoczenie") or "?", czar = spellName, czar_id = spellId,
        guid = srcGUID,
        ile = amount, overkill = tonumber(overkill) or 0, pvp = (srcFlags and band(srcFlags, TYPE_PLAYER) > 0) or false }
      table.insert(hits, h)
      if #hits > 8 then table.remove(hits, 1) end
      if kind == 3 then
        Log("OTOCZENIE", { typ = envType, ile = amount })
      elseif target then
        target.otrzymane = target.otrzymane + amount
        addTarget(target, srcName, srcGUID)
        if h.pvp then target.pvp = true end
      end
    elseif mine and target and dstGUID ~= me and dstGUID ~= pet then
      target.zadane = target.zadane + amount
      target.dotkniete[dstGUID] = dstName or "?"
      addTarget(target, dstName, dstGUID) -- celem jest kazdy, komu zadalismy obrazenia (nie tylko wrogi)
      if dstFlags and band(dstFlags, TYPE_PLAYER) > 0 then target.pvp = true end
    end
  elseif HEAL[sub] and target then
    local _, _, _, amount, over = select(12, CombatLogGetCurrentEventInfo())
    local eff = math.max(0, (tonumber(amount) or 0) - (tonumber(over) or 0))
    if mine then target.lecz_z = target.lecz_z + eff end
    if toMe then target.lecz_o = target.lecz_o + eff end
  elseif sub == "SPELL_CAST_SUCCESS" and mine and srcGUID == me and target then
    local _, spellName = select(12, CombatLogGetCurrentEventInfo())
    if spellName then target.czary[spellName] = (target.czary[spellName] or 0) + 1 end
  end
end)
end -- ns.isClassic

-------------------------------------------------------------------------------
-- Smierc
-------------------------------------------------------------------------------
local function position()
  local mapID = C_Map and C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
  local x, y
  if mapID then
    local ok, pos = pcall(C_Map.GetPlayerMapPosition, mapID, "player")
    if ok and pos then
      local px, py = pos:GetXY()
      if px and py and not ns.Hidden(px) then x, y = math.floor(px * 1000 + 0.5) / 10, math.floor(py * 1000 + 0.5) / 10 end
    end
  end
  return mapID, x, y
end
ns.Position = position

local function baseDeath()
  local mapID, x, y = position()
  local inInst, instType = IsInInstance()
  return {
    lvl = UnitLevel("player"), strefa = GetZoneText(), pod = GetSubZoneText(), mapa = mapID, x = x, y = y,
    instancja = (inInst and instType) or "none", grupa = IsInGroup() and GetNumGroupMembers() or 1, raid = IsInRaid() or false,
    wytrzymalosc = ns.Durability(),
  }
end

-- Classic: zabojca z ostatnich 10 s combat logu
local function deathClassic()
  local gt = GetTime()
  local killer, recent = nil, {}
  for i = #hits, 1, -1 do
    local h = hits[i]
    if gt - h.gt <= 10 then
      recent[#recent + 1] = string.format("%s|%s|%d", tostring(h.zrodlo), tostring(h.czar), h.ile or 0)
      if not killer and h.overkill > 0 then killer = h end
    end
  end
  if not killer then
    for i = #hits, 1, -1 do if gt - hits[i].gt <= 10 then killer = hits[i] break end end
  end
  local d = baseDeath()
  d.zrodlo = "combatlog"
  d.zabojca = killer and killer.zrodlo or "nieznany"
  d.czar = killer and killer.czar or nil
  d.zabojca_npc = killer and ns.NpcID(killer.guid) or nil
  d.zabojca_guid = killer and ns.PlayerGUID(killer.guid) or nil
  d.obrazenia = killer and killer.ile or nil
  d.overkill = killer and killer.overkill or nil
  d.pvp = (killer and killer.pvp) or false
  d.trafienia = recent
  hits = {}
  Log("SMIERC", d)
  if killer and killer.pvp and ns.PvpDeath then
    ns.PvpDeath({ guid = killer.guid, nazwa = killer.zrodlo, czar = killer.czar, czar_id = killer.czar_id, obrazenia = killer.ile })
  end
  return d
end

-- Forever / retail: podsumowanie smierci gry (to samo, co okno "Death Recap")
local function s(v, kind)
  if ns.Hidden(v) then return ns.Safe(v, kind or "smierc") end
  return v
end
local function deathRecap()
  local d = baseDeath()
  d.zrodlo = "recap"
  local events
  if C_DeathRecap and C_DeathRecap.GetRecapEvents then
    local ok, ev = pcall(C_DeathRecap.GetRecapEvents)
    if ok and type(ev) == "table" and not ns.Hidden(ev) then events = ev
    elseif ok and ns.Hidden(ev) then d.recap = "ukryte" end
  else
    d.recap = "brak"
  end
  if C_DeathRecap and C_DeathRecap.GetRecapMaxHealth then
    local ok, mh = pcall(C_DeathRecap.GetRecapMaxHealth)
    if ok then d.max_hp = s(mh) end
  end
  local killer = events and events[1]
  if killer then
    if ns.DiagShape then ns.DiagShape("smierc_recap", killer) end
    local guid = killer.sourceGUID
    d.otoczenie = s(killer.environmentalType)
    d.zabojca = s(killer.sourceName) or (d.otoczenie and "Otoczenie") or "nieznany"
    d.czar = s(killer.spellName)
    d.czar_id = s(killer.spellId)
    d.obrazenia = s(killer.amount)
    d.overkill = s(killer.overkill)
    d.zdarzenie = s(killer.event)
    d.zabojca_npc = ns.NpcID(guid)
    d.zabojca_guid = ns.PlayerGUID(guid) or (ns.Hidden(guid) and "ukryte") or nil
    d.pvp = ns.PlayerGUID(guid) and true or false
    local tr = {}
    for i = 1, math.min(#events, 5) do
      local e = events[i]
      tr[i] = string.format("%s|%s|%s|%s|%s", tostring(s(e.sourceName) or s(e.environmentalType) or "?"), tostring(s(e.spellName) or "-"),
        tostring(s(e.amount) or 0), tostring(s(e.currentHP) or "?"), tostring(s(e.timestamp) or "?"))
    end
    d.trafienia = tr
    d.trafien = #events
    d.recap = d.recap or "ok"
  else
    d.zabojca = "nieznany"
    d.recap = d.recap or "puste"
    d.pvp = false
  end
  Log("SMIERC", d)
  if d.pvp and ns.PvpDeath then
    ns.PvpDeath({ guid = killer.sourceGUID, nazwa = d.zabojca, czar = d.czar, czar_id = d.czar_id, obrazenia = d.obrazenia })
  end
  return d
end

ns.On("PLAYER_DEAD", function()
  if UnitIsFeignDeath and UnitIsFeignDeath("player") then return end
  if F then F.smierc = true elseif closing then closing.smierc = true end
  ns.state.dead, ns.state.ghost = now(), nil -- dla DUCH / WSKRZESZONY / POWROT (Monitor.lua)
  local function done(d)
    ns.msg(string.format("Smierc zapisana: %s (%s).", tostring(d.zabojca or "nieznany"), tostring(d.czar or "-")))
  end
  if ns.isClassic then
    done(deathClassic())
  else
    C_Timer.After(1, function() done(deathRecap()) end) -- podsumowanie smierci gra uzupelnia chwile po smierci
  end
end)

-- przy wylogowaniu w trakcie walki zapisujemy to, co jest
ns.AddHook("logout", function()
  if closing then finalize(closing); closing = nil end
  if F then finalize(F); F = nil end
end)
