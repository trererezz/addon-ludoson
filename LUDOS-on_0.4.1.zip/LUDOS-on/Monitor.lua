-- LUDOS-on 0.4.0 - monitorowanie: sesja i miejsce, exp, questy, reputacja, smierc (bez walki),
-- zloto i loot, profesje i talenty, grupa i instancje, PvP.

local ADDON, ns = ...
local Log, now = ns.Log, ns.now

-------------------------------------------------------------------------------
-- /played bez wypisywania na czat
-------------------------------------------------------------------------------
local playedQueue = {}
local function restoreChat()
  for i = 1, (NUM_CHAT_WINDOWS or 10) do
    local cf = _G["ChatFrame" .. i]
    if cf and cf.ludosPlayed then cf:RegisterEvent("TIME_PLAYED_MSG"); cf.ludosPlayed = nil end
  end
end
function ns.RequestPlayed(powod)
  table.insert(playedQueue, powod)
  if #playedQueue > 1 then return end
  for i = 1, (NUM_CHAT_WINDOWS or 10) do
    local cf = _G["ChatFrame" .. i]
    if cf and cf:IsEventRegistered("TIME_PLAYED_MSG") then cf:UnregisterEvent("TIME_PLAYED_MSG"); cf.ludosPlayed = true end
  end
  RequestTimePlayed()
  C_Timer.After(10, restoreChat)
end
ns.On("TIME_PLAYED_MSG", function(total, levelTime)
  restoreChat()
  local powod = playedQueue[1] or "gracz"
  playedQueue = {}
  Log("PLAYED", { lacznie = total, poziom = levelTime, powod = powod })
end)

-------------------------------------------------------------------------------
-- Strefy i loty
-------------------------------------------------------------------------------
-- PODSTREFA: zapis dopiero, gdy gracz zostanie w podstrefie 5 s (bez migotania na granicach),
-- puste nazwy (teren bez podstrefy) pomijamy
local lastSub, subToken = nil, 0
ns.On("ZONE_CHANGED_NEW_AREA", function()
  local _, instType = IsInInstance()
  lastSub = GetSubZoneText()
  subToken = subToken + 1
  ns.state.zone = GetZoneText()
  Log("STREFA", { strefa = ns.state.zone, pod = lastSub, instancja = instType or "none", mapa = ns.MapID() })
end)
ns.On("ZONE_CHANGED", function()
  local sub = GetSubZoneText()
  if not sub or sub == "" or sub == lastSub then return end
  subToken = subToken + 1
  local my = subToken
  C_Timer.After(5, function()
    if my ~= subToken then return end
    local cur = GetSubZoneText()
    if cur ~= sub or cur == lastSub then return end
    lastSub = cur
    Log("PODSTREFA", { strefa = GetZoneText(), pod = cur, mapa = ns.MapID() })
  end)
end)

local flying = false
ns.On("PLAYER_CONTROL_LOST", function()
  C_Timer.After(0.5, function()
    if UnitOnTaxi and UnitOnTaxi("player") and not flying then
      flying = true
      Log("LOT_START", { skad = GetZoneText(), pod = GetSubZoneText(), mapa = ns.MapID() })
      C_Timer.After(3, function() ns.Fire("podroz", "lot") end) -- dobry moment na /reload
    end
  end)
end)
ns.On("PLAYER_CONTROL_GAINED", function()
  if flying then
    flying = false
    Log("LOT_KONIEC", { dokad = GetZoneText(), pod = GetSubZoneText(), mapa = ns.MapID() })
  end
end)

-------------------------------------------------------------------------------
-- AFK
-------------------------------------------------------------------------------
local afkSince
ns.On("PLAYER_FLAGS_CHANGED", function(unit)
  if unit and unit ~= "player" then return end
  local afk = UnitIsAFK("player")
  if afk and not afkSince then
    afkSince = now()
    Log("AFK_START", {})
  elseif not afk and afkSince then
    Log("AFK_KONIEC", { sek = now() - afkSince })
    afkSince = nil
  end
end)

-------------------------------------------------------------------------------
-- Exp, awanse, questy
-------------------------------------------------------------------------------
local last = {}
local lastQuest = { gt = -100, xp = 0 }
local lastExpRow
function ns.SnapXP()
  last.lvl, last.xp, last.max = UnitLevel("player"), UnitXP("player"), UnitXPMax("player")
end

ns.On("PLAYER_XP_UPDATE", function(unit)
  if unit and unit ~= "player" then return end
  if not last.lvl then ns.SnapXP() return end
  local lvl, xp, max = UnitLevel("player"), UnitXP("player"), UnitXPMax("player")
  local gain = 0
  if lvl == last.lvl then
    if xp >= last.xp then
      gain = xp - last.xp
    else -- awans, ktorego poziom jeszcze nie dotarl
      gain = ((last.max or last.xp) - last.xp) + xp
      lvl, max = lvl + 1, nil
    end
  elseif lvl > last.lvl then
    gain = ((last.max or last.xp) - last.xp) + xp
  else
    if xp >= last.xp then gain = xp - last.xp end
    lvl, max = last.lvl, nil
  end
  last.lvl, last.xp = lvl, xp
  if max then last.max = max end
  if gain <= 0 then return end
  local zrodlo = "inne"
  if GetTime() - lastQuest.gt < 1.5 and gain == lastQuest.xp then
    zrodlo = "quest"
  elseif (ns.state.lastKillGT and GetTime() - ns.state.lastKillGT < 2) or UnitAffectingCombat("player") then
    zrodlo = "mob"
  end
  -- komunikat o expie za moba ("X dies, you gain N experience. (+M exp Rested bonus)")
  local xc = ns.state.lastXpChat
  local mob, rested
  if xc and GetTime() - xc.gt < 2 and (xc.xp == gain or xc.xp + (xc.rested or 0) == gain) then
    mob, rested = xc.mob, xc.rested
    zrodlo = "mob"
  end
  lastExpRow = Log("EXP", { ile = gain, zrodlo = zrodlo, lvl = UnitLevel("player"), mob = mob, rested = rested })
  if lastExpRow then lastExpRow.gt = nil end
  ns.state.lastExpGT = GetTime()
end)

ns.On("PLAYER_LEVEL_UP", function(newLevel)
  local lvl = tonumber(newLevel) or (UnitLevel("player") + 1)
  ns.state.lvl = lvl
  Log("AWANS", { lvl = lvl })
  ns.RequestPlayed("awans")
end)

local function questTitle(qid, index)
  local title
  if C_QuestLog and C_QuestLog.GetTitleForQuestID then -- Forever / retail
    local ok, t = pcall(C_QuestLog.GetTitleForQuestID, qid)
    if ok and type(t) == "string" and not ns.Hidden(t) then title = t end
  end
  if not title and C_QuestLog and C_QuestLog.GetQuestInfo then
    local ok, t = pcall(C_QuestLog.GetQuestInfo, qid)
    if ok and type(t) == "string" then title = t end
  end
  if not title and index and GetQuestLogTitle then
    local ok, t = pcall(GetQuestLogTitle, index)
    if ok and type(t) == "string" then title = t end
  end
  return title
end

ns.On("QUEST_ACCEPTED", function(a, b)
  local qid = tonumber(b) or tonumber(a)
  local index = b and tonumber(a) or nil
  local title = questTitle(qid, index)
  if qid and title and ns.CH then ns.CH.questy[qid] = title end
  Log("QUEST_PRZYJETY", { id = qid, nazwa = title })
end)

ns.On("QUEST_TURNED_IN", function(questID, xpReward, moneyReward)
  local qid = tonumber(questID)
  local xp = tonumber(xpReward) or 0
  local title = (ns.CH and qid and ns.CH.questy[qid]) or questTitle(qid)
  Log("QUEST_ODDANY", { id = qid, nazwa = title, exp = xp, zloto = tonumber(moneyReward) or 0 })
  lastQuest.gt, lastQuest.xp = GetTime(), xp
  -- exp z questa mogl przyjsc tuz przed tym zdarzeniem
  if lastExpRow and ns.state.lastExpGT and GetTime() - ns.state.lastExpGT < 1.5 and lastExpRow.d.ile == xp then
    lastExpRow.d.zrodlo = "quest"
  end
end)

-------------------------------------------------------------------------------
-- Reputacja (zdarzenie nie mowi, co sie zmienilo: porownujemy stan)
-------------------------------------------------------------------------------
local rep, repPending
local function readRep()
  local t = {}
  if GetFactionInfo and GetNumFactions then
    for i = 1, (GetNumFactions() or 0) do
      local name, _, standingID, _, _, barValue, _, _, isHeader, _, hasRep, _, _, factionID = GetFactionInfo(i)
      if name and (not isHeader or hasRep) then
        t[factionID or name] = { name = name, v = barValue or 0, s = standingID, id = factionID }
      end
    end
  elseif C_Reputation and C_Reputation.GetNumFactions and C_Reputation.GetFactionDataByIndex then
    for i = 1, (C_Reputation.GetNumFactions() or 0) do
      local f = C_Reputation.GetFactionDataByIndex(i)
      if f and f.name and (not f.isHeader or f.isHeaderWithRep) then
        t[f.factionID or f.name] = { name = f.name, v = f.currentStanding or 0, s = f.reaction, id = f.factionID }
      end
    end
  end
  return t
end
local function diffRep()
  repPending = false
  local cur = readRep()
  if rep then
    for k, f in pairs(cur) do
      local old = rep[k]
      if old and f.v ~= old.v then
        Log("REPUTACJA", { frakcja = f.name, frakcja_id = f.id, zmiana = f.v - old.v, wartosc = f.v,
          poziom = _G["FACTION_STANDING_LABEL" .. tostring(f.s)] or f.s })
      end
    end
  end
  rep = cur
end
ns.On("UPDATE_FACTION", function()
  if not rep then rep = readRep() return end
  if repPending then return end
  repPending = true
  C_Timer.After(0.5, diffRep)
end)

-------------------------------------------------------------------------------
-- Smierc (bez walki - zabojca w Combat.lua), wskrzeszenie, wytrzymalosc
-------------------------------------------------------------------------------
function ns.Durability()
  local cur, max = 0, 0
  for slot = 1, 18 do
    local c, m = GetInventoryItemDurability(slot)
    if c and m and m > 0 then cur, max = cur + c, max + m end
  end
  if max == 0 then return nil end
  return math.floor(cur / max * 100 + 0.5)
end

local function lastDeath()
  local S = ns.S
  if not S then return nil end
  for i = #S.dziennik, math.max(1, #S.dziennik - 200), -1 do
    local r = S.dziennik[i]
    if r.e == "SMIERC" then return r end
  end
end

-- ns.state.dead = czas (GetServerTime) ostatniej smierci; ustawia Combat.lua (PLAYER_DEAD)
local function sinceDeath()
  return ns.state.dead and (now() - ns.state.dead) or nil
end
ns.On("PLAYER_ALIVE", function()
  -- PLAYER_ALIVE przychodzi tez przy logowaniu i ekranach ladowania: liczymy tylko po smierci
  if not ns.state.dead then return end
  if UnitIsDeadOrGhost("player") then
    if not ns.state.ghost then
      ns.state.ghost = true
      Log("DUCH", { po_s = sinceDeath() })
    end
  else
    Log("WSKRZESZONY", { po_s = sinceDeath() })
    ns.state.dead, ns.state.ghost = nil, nil
  end
end)
ns.On("PLAYER_UNGHOST", function()
  if not ns.state.dead then return end
  Log("POWROT", { po_s = sinceDeath() })
  ns.state.dead, ns.state.ghost = nil, nil
end)
ns.On("RESURRECT_REQUEST", function(who) Log("OFERTA_WSKRZESZENIA", { od = ns.Short(who) }) end)

local dur, durPending
ns.On("UPDATE_INVENTORY_DURABILITY", function()
  if durPending then return end
  durPending = true
  C_Timer.After(1, function()
    durPending = false
    local d = ns.Durability()
    if d and dur and d >= dur + 5 then Log("NAPRAWA", { przed = dur, po = d }) end
    dur = d
  end)
end)

-------------------------------------------------------------------------------
-- Zloto i loot
-------------------------------------------------------------------------------
local moneyPats
local function parseMoney(msg)
  if not moneyPats then
    moneyPats = {
      { (GOLD_AMOUNT or "%d Gold"):gsub("%%d", "(%%d+)"), 10000 },
      { (SILVER_AMOUNT or "%d Silver"):gsub("%%d", "(%%d+)"), 100 },
      { (COPPER_AMOUNT or "%d Copper"):gsub("%%d", "(%%d+)"), 1 },
    }
  end
  local total = 0
  for _, p in ipairs(moneyPats) do
    local v = msg:match(p[1])
    if v then total = total + tonumber(v) * p[2] end
  end
  return total
end
-- ostatnie znane wartosci (przy wylogowaniu API moze zwracac juz zera)
ns.On("PLAYER_MONEY", function() ns.state.lastMoney = GetMoney() end)
ns.On("UPDATE_EXHAUSTION", function() ns.state.lastRested = GetXPExhaustion() or 0 end)

ns.ParseMoney = parseMoney
ns.On("CHAT_MSG_MONEY", function(msg)
  if ns.Hidden(msg) then return end
  Log("ZLOTO", { miedz = parseMoney(msg or ""), tekst = msg })
end)

local QUAL = { ["9d9d9d"] = 0, ["ffffff"] = 1, ["1eff00"] = 2, ["0070dd"] = 3, ["a335ee"] = 4, ["ff8000"] = 5, ["e6cc80"] = 6 }
local selfPats
ns.On("CHAT_MSG_LOOT", function(msg, who)
  if ns.Hidden(msg) then return end
  msg = msg or ""
  if not selfPats then
    selfPats = {}
    for _, k in ipairs({ "LOOT_ITEM_SELF", "LOOT_ITEM_SELF_MULTIPLE", "LOOT_ITEM_PUSHED_SELF",
      "LOOT_ITEM_PUSHED_SELF_MULTIPLE", "LOOT_ITEM_CREATED_SELF", "LOOT_ITEM_CREATED_SELF_MULTIPLE" }) do
      local p = ns.FmtToPattern(_G[k])
      if p then table.insert(selfPats, p) end
    end
  end
  local link = msg:match("(|c%x+|Hitem:.-|h%[.-%]|h|r)")
  if not link then return end
  local id = tonumber(link:match("item:(%d+)"))
  local name = link:match("%[(.-)%]")
  local qty = tonumber(msg:match("|rx(%d+)")) or 1
  local hex = link:match("|cff(%x%x%x%x%x%x)")
  local ja = false
  for _, p in ipairs(selfPats) do if msg:match(p) then ja = true break end end
  local kto = ns.Short(who)
  if kto and kto == UnitName("player") then ja = true end
  Log("LOOT", { id = id, nazwa = name, ile = qty, jakosc = hex and QUAL[hex:lower()] or nil, ja = ja, kto = (not ja) and kto or nil })
end)

-------------------------------------------------------------------------------
-- Profesje, talenty, czary
-------------------------------------------------------------------------------
local skills, skillPending
-- umiejetnosci: Forever / retail przez C_SkillInfo (tabela, z ID linii), Classic przez stare funkcje
local function readSkills()
  local t = {}
  if C_SkillInfo and C_SkillInfo.GetNumSkillLines and C_SkillInfo.GetSkillLineInfo then
    for i = 1, (C_SkillInfo.GetNumSkillLines() or 0) do
      local a = C_SkillInfo.GetSkillLineInfo(i)
      if type(a) == "table" and a.name and not a.isHeader then t[a.name] = { r = a.rank or 0, m = a.maxRank or 0, id = a.skillID } end
    end
  elseif GetNumSkillLines then
    for i = 1, (GetNumSkillLines() or 0) do
      local name, isHeader, _, rank, _, _, maxRank = GetSkillLineInfo(i)
      if name and not isHeader then t[name] = { r = rank or 0, m = maxRank or 0 } end
    end
  end
  return t
end
ns.On("SKILL_LINES_CHANGED", function()
  if not skills then skills = readSkills() return end
  if skillPending then return end
  skillPending = true
  C_Timer.After(0.5, function()
    skillPending = false
    local cur = readSkills()
    for name, s in pairs(cur) do
      local old = skills[name]
      if not old then
        Log("UMIEJETNOSC", { nazwa = name, id = s.id, z = 0, na = s.r, max = s.m, nowa = true })
      elseif s.r ~= old.r then
        Log("UMIEJETNOSC", { nazwa = name, id = s.id, z = old.r, na = s.r, max = s.m })
      end
    end
    skills = cur
  end)
end)

ns.On("CHARACTER_POINTS_CHANGED", function(change)
  Log("TALENT", { zmiana = tonumber(change), wolne = UnitCharacterPoints and UnitCharacterPoints("player") or nil })
end)

local function newSpell(spellID)
  local name
  if C_Spell and C_Spell.GetSpellName then name = C_Spell.GetSpellName(spellID)
  elseif GetSpellInfo then name = GetSpellInfo(spellID) end
  Log("NOWY_CZAR", { id = tonumber(spellID), nazwa = ns.Safe(name) })
end
ns.On("LEARNED_SPELL_IN_TAB", newSpell)          -- Classic
ns.On("LEARNED_SPELL_IN_SKILL_LINE", newSpell)   -- Forever / retail

-------------------------------------------------------------------------------
-- Grupa i instancje
-------------------------------------------------------------------------------
local members, groupPending
-- t[imie] = GUID (albo true, gdy gra nie podala GUID)
local function readGroup()
  local t, n = {}, 0
  if IsInRaid() then
    for i = 1, 40 do local u = "raid" .. i; local name = UnitName(u); if name then t[name] = UnitGUID(u) or true; n = n + 1 end end
  elseif IsInGroup() then
    for i = 1, 4 do local u = "party" .. i; local name = UnitName(u); if name then t[name] = UnitGUID(u) or true; n = n + 1 end end
    n = n + 1
  end
  return t, n
end
local function gid(v) return type(v) == "string" and v or nil end
ns.On("GROUP_ROSTER_UPDATE", function()
  if groupPending then return end
  groupPending = true
  C_Timer.After(0.5, function()
    groupPending = false
    local cur, size = readGroup()
    local old = members or {}
    local me = UnitName("player")
    local wasIn = next(old) ~= nil
    local isIn = size > 0
    if isIn and not wasIn then Log("GRUPA", { typ = "start", rozmiar = size, raid = IsInRaid() or false }) end
    for name, g in pairs(cur) do if not old[name] and name ~= me then Log("GRUPA", { typ = "dolaczyl", kto = name, kto_guid = gid(g), rozmiar = size }) end end
    for name, g in pairs(old) do if not cur[name] and name ~= me then Log("GRUPA", { typ = "odszedl", kto = name, kto_guid = gid(g), rozmiar = size }) end end
    if wasIn and not isIn then Log("GRUPA", { typ = "koniec", rozmiar = 0 }) end
    members = cur
  end)
end)

ns.On("PARTY_LEADER_CHANGED", function()
  local leader, lguid
  if UnitIsGroupLeader("player") then leader, lguid = UnitName("player"), UnitGUID("player")
  else
    local prefix, max = IsInRaid() and "raid" or "party", IsInRaid() and 40 or 4
    for i = 1, max do
      local u = prefix .. i
      if UnitIsGroupLeader(u) then leader, lguid = UnitName(u), UnitGUID(u) break end
    end
  end
  if leader then Log("LIDER", { kto = leader, kto_guid = lguid }) end
end)

local lastSaved
ns.On("UPDATE_INSTANCE_INFO", function()
  local list = {}
  for i = 1, (GetNumSavedInstances() or 0) do
    local name, id, reset = GetSavedInstanceInfo(i)
    if name then table.insert(list, string.format("%s|%s|%d", name, tostring(id), tonumber(reset) or 0)) end
  end
  table.sort(list)
  local key = table.concat(list, ";")
  if key == lastSaved then return end
  lastSaved = key
  Log("ZAPISY", { lista = list })
end)

ns.On("ENCOUNTER_START", function(id, name, difficulty, size)
  ns.state.inEncounter = true
  Log("BOSS_START", { id = id, nazwa = name, trudnosc = difficulty, osob = size })
end)
ns.On("ENCOUNTER_END", function(id, name, difficulty, size, success)
  ns.state.inEncounter = false
  Log("BOSS_KONIEC", { id = id, nazwa = name, trudnosc = difficulty, osob = size, wynik = success })
end)
ns.On("BOSS_KILL", function(id, name) Log("BOSS_ZABITY", { id = id, nazwa = name }) end)

ns.On("CHAT_MSG_MONSTER_YELL", function(text, monster)
  if not IsInInstance() then return end -- tylko w instancjach
  if ns.Hidden(text) or ns.Hidden(monster) then return end -- Forever: ukryte w blokadzie czatu
  text = tostring(text or "")
  if #text > 160 then text = text:sub(1, 160) end
  Log("KRZYK", { kto = monster, tekst = text })
end)

-------------------------------------------------------------------------------
-- PvP
-------------------------------------------------------------------------------
ns.On("PLAYER_PVP_KILLS_CHANGED", function()
  local hk, dk
  if GetPVPSessionStats then local ok, a, b = pcall(GetPVPSessionStats); if ok then hk, dk = a, b end end
  Log("PVP_HK", { hk = hk, dk = dk })
end)
ns.On("PLAYER_PVP_RANK_CHANGED", function()
  local rank = UnitPVPRank and UnitPVPRank("player") or nil
  local name = (rank and GetPVPRankInfo) and GetPVPRankInfo(rank) or nil
  Log("PVP_RANGA", { ranga = rank, nazwa = name })
end)
local pvpFlag
ns.On("UNIT_FACTION", function(unit)
  if unit ~= "player" then return end
  local f = UnitIsPVP("player") and true or false
  if pvpFlag ~= nil and f ~= pvpFlag then Log("PVP_FLAGA", { wl = f }) end
  pvpFlag = f
end)

-------------------------------------------------------------------------------
-- Migawki na start, po reloadzie, przy ekranie ladowania i przy wylogowaniu
-------------------------------------------------------------------------------
local function baseline()
  ns.SnapXP()
  ns.state.lvl = UnitLevel("player")
  ns.state.zone = GetZoneText()
  ns.state.kontynent = ns.ContinentOf and ns.ContinentOf(ns.MapID())
  ns.state.lastMoney = GetMoney()
  ns.state.lastRested = GetXPExhaustion() or 0
  if UnitIsDeadOrGhost("player") then
    ns.state.dead = ns.state.dead or now()
    ns.state.ghost = UnitIsGhost and UnitIsGhost("player") or nil
  end
  rep = readRep()
  skills = readSkills()
  dur = ns.Durability()
  members = readGroup()
  pvpFlag = UnitIsPVP("player") and true or false
  lastSub = GetSubZoneText()
  if UnitIsAFK("player") then afkSince = afkSince or now() end
end

ns.AddHook("start", function()
  baseline()
  Log("RESTED", { kiedy = "start", ile = GetXPExhaustion() or 0, stan = GetRestState() })
  Log("ZLOTO_STAN", { kiedy = "start", miedz = GetMoney() })
  ns.RequestPlayed("logowanie")
  if RequestRaidInfo then RequestRaidInfo() end
end)
ns.AddHook("resume", baseline)
-- kontynent mapy (do rozpoznania podrozy zeppelinem / statkiem / portalem)
local function continentOf(mapID)
  if not (mapID and C_Map and C_Map.GetMapInfo) then return nil end
  local guard = 0
  while mapID and guard < 10 do
    local ok, info = pcall(C_Map.GetMapInfo, mapID)
    if not ok or not info then return nil end
    if info.mapType == 2 then return mapID end -- Enum.UIMapType.Continent
    mapID = info.parentMapID
    guard = guard + 1
  end
  return nil
end
ns.ContinentOf = continentOf

ns.AddHook("loading", function()
  ns.SnapXP(); ns.state.zone = GetZoneText()
  local before = ns.state.kontynent
  local now_c = continentOf(ns.MapID())
  ns.state.kontynent = now_c
  if before and now_c and before ~= now_c then
    C_Timer.After(5, function() ns.Fire("podroz", "kontynent") end) -- gracz jeszcze plynie/leci do przystanku
  end
end)

-- exp za moba z czatu (w lochu jedyne zrodlo informacji, ktory mob padl)
local xpPats
ns.On("CHAT_MSG_COMBAT_XP_GAIN", function(msg)
  if type(msg) ~= "string" or ns.Hidden(msg) then return end
  if not xpPats then
    xpPats = {}
    for _, k in ipairs({ "COMBATLOG_XPGAIN_FIRSTPERSON", "COMBATLOG_XPGAIN_FIRSTPERSON_GROUP", "COMBATLOG_XPGAIN_FIRSTPERSON_RAID" }) do
      local f = _G[k]
      if type(f) == "string" then
        local p = ns.FmtToPattern((f:gsub("%s*%(.*$", ""))) -- bez dopiskow w nawiasach
        if p then xpPats[#xpPats + 1] = (p:gsub("%$$", "")) end
      end
    end
    if #xpPats == 0 then xpPats[1] = "^(.+) dies, you gain (%d+) experience" end
  end
  for _, p in ipairs(xpPats) do
    local mob, xp = msg:match(p)
    if mob and tonumber(xp) then
      local rested = tonumber(msg:match("%+(%d+)[^%d]*[Rr]ested")) or nil
      ns.state.lastXpChat = { mob = mob, xp = tonumber(xp), rested = rested, gt = GetTime() }
      ns.Fire("xp_mob", mob, tonumber(xp), rested)
      return
    end
  end
end)
ns.AddHook("logout_real", function()
  if afkSince then Log("AFK_KONIEC", { sek = now() - afkSince }); afkSince = nil end
  local rested = GetXPExhaustion()
  if not rested or rested == 0 then rested = ns.state.lastRested or 0 end
  local money = GetMoney()
  if (not money or money == 0) and ns.state.lastMoney then money = ns.state.lastMoney end
  Log("RESTED", { kiedy = "koniec", ile = rested, stan = GetRestState() })
  Log("ZLOTO_STAN", { kiedy = "koniec", miedz = money or 0 })
end)

ns.LastDeath = lastDeath
