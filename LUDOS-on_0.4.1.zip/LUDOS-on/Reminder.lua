-- LUDOS-on 0.4.0 - przypominanie o zapisie (/reload) wg jednego "stanu zapisu" i wskazowka o /ludos.
-- Gra nie pozwala add-onowi zrobic reloadu samemu, ale pozwala po kliknieciu gracza (przycisk w okienku).
--
-- Stan zapisu (dane czekajace w pamieci od ostatniego zapisu pliku):
--   0 zielony:  < 150 zdarzen i < 20 min
--   1 zolty:    od 150 zdarzen albo od 20 min   - dobry moment na /reload
--   2 czerwony: od 400 zdarzen albo od 45 min   - duzo do stracenia przy crashu
-- Wiadomosc na czacie: stan >= zolty + dobry moment (lot, zmiana kontynentu); >= 10 min od zapisu i od poprzedniej.
-- Okienko (z boku): stan >= zolty + dobry moment, albo stan czerwony poza walka; >= 30 min od poprzedniego okienka.

local ADDON, ns = ...
local Log, now = ns.Log, ns.now

local Y_ROWS, Y_MIN, R_ROWS, R_MIN = 150, 20, 400, 45
local CHAT_GAP, POPUP_GAP = 600, 1800
local lastChat, lastPopup, lastTip = 0, 0, 0
local popup

function ns.SaveState()
  local n = ns.Unsaved and ns.Unsaved() or 0
  local mins = math.floor((now() - (ns.state.loadTime or now())) / 60)
  local level = 0
  if n >= R_ROWS or mins >= R_MIN then level = 2
  elseif n >= Y_ROWS or mins >= Y_MIN then level = 1 end
  if n == 0 then level = 0 end -- nic nie czeka
  return level, n, mins
end

local function canShow()
  if InCombatLockdown() or UnitAffectingCombat("player") then return false end
  if ns.state.inEncounter then return false end
  if UnitIsDeadOrGhost("player") then return false end
  return true
end

local function build()
  local f = CreateFrame("Frame", "LUDOSonReminder", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
  f:SetSize(300, 120)
  f:SetPoint("RIGHT", UIParent, "RIGHT", -40, 60) -- z boku, nie na srodku
  f:SetFrameStrata("DIALOG")
  f:SetClampedToScreen(true)
  f:SetMovable(true)
  f:EnableMouse(true)
  f:RegisterForDrag("LeftButton")
  f:SetScript("OnDragStart", f.StartMoving)
  f:SetScript("OnDragStop", f.StopMovingOrSizing)
  if f.SetBackdrop then
    f:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
      edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 24,
      insets = { left = 8, right = 8, top = 8, bottom = 8 } })
  end
  local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
  title:SetPoint("TOP", 0, -14)
  title:SetText("LUDOS-on - zapis danych")
  local text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
  text:SetPoint("TOP", 0, -34)
  text:SetWidth(270)
  f.text = text

  local save = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
  save:SetSize(150, 22)
  save:SetPoint("BOTTOMLEFT", 14, 14)
  save:SetText("Zapisz teraz (/reload)")
  save:SetScript("OnClick", function()
    Log("PRZYP_ZAPIS", { czekalo = ns.Unsaved() })
    ReloadUI()
  end)
  local later = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
  later:SetSize(110, 22)
  later:SetPoint("LEFT", save, "RIGHT", 6, 0)
  later:SetText("Pozniej")
  later:SetScript("OnClick", function()
    Log("PRZYP_ODLOZONE", { czekalo = ns.Unsaved() })
    f:Hide()
  end)
  f:Hide()
  popup = f
end

function ns.ShowReminder(force, powod)
  if not popup then build() end
  if popup:IsShown() then return end
  if not force and not canShow() then return end
  local level, n, mins = ns.SaveState()
  local lead = (powod == "lot" and "Lecisz - dobry moment na zapis.")
    or (powod == "kontynent" and "Podrozujesz - dobry moment na zapis.")
    or (level == 2 and "Duzo danych do stracenia przy crashu gry.")
    or "Dobry moment na zapis."
  popup.text:SetText(string.format("%s\n%d zdarzen czeka na zapis (od zapisu %d min).\nReload trwa kilka sekund. Mozesz tez wpisac /reload.", lead, n, mins))
  popup:Show()
  lastPopup = now()
  Log("PRZYP_POKAZANE", { czekalo = n, min = mins, stan = level, powod = powod or (force and "reczne" or "stan") })
end

-- dobry moment (lot taksowka, zmiana kontynentu): czat i/lub okienko
ns.AddHook("podroz", function(kind)
  if not ns.DB or not ns.S or not canShow() then return end
  local u = ns.U()
  local level = ns.SaveState()
  if level < 1 then return end
  local t = now()
  if u.przyp_czat and t - (ns.state.loadTime or t) >= CHAT_GAP and t - lastChat >= CHAT_GAP then
    lastChat = t
    ns.msg(kind == "lot" and "Lecisz - dobry moment na zapis danych: wpisz /reload (lot trwa dalej)."
      or "Podrozujesz - dobry moment na zapis danych: wpisz /reload.")
  end
  if u.przyp_okno and t - lastPopup >= POPUP_GAP then ns.ShowReminder(false, kind) end
end)

local function tick()
  if not ns.DB or not ns.S then return end
  local u = ns.U()
  local t = now()
  -- stan czerwony: okienko w kazdej chwili poza walka (najwyzej co 30 min)
  if u.przyp_okno and t - lastPopup >= POPUP_GAP and canShow() then
    local level = ns.SaveState()
    if level == 2 then ns.ShowReminder(false, "stan") end
  end
  -- wskazowka o /ludos co 60 minut
  if u.wskazowka then
    if lastTip == 0 then lastTip = t end
    if t - lastTip >= 3600 then
      lastTip = t
      ns.msg("/ludos - okno i pomoc. Przypomnienia wylaczysz w Ustawieniach.")
    end
  end
end

C_Timer.NewTicker(15, tick)
