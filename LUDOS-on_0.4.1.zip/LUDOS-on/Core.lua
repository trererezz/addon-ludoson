-- LUDOS-on 0.4.1 - rdzen: baza, role, sesje, dziennik zdarzen, zdarzenia gry, komendy.
-- 0.4.1: limit danych gracza 10 MB (szacunek wielkosci pliku). Ponad limit przy wczytaniu usuwane sa
-- najstarsze sesje odebrane w calosci przez co najmniej jednego oficera. Sesji niewyslanej nie usuwamy nigdy.
-- Teksty w grze bez polskich znakow (czcionki WoW moga ich nie miec).

local ADDON, ns = ...
ns.VERSION = "0.4.1"

-- rozpoznanie gry: Classic (Era/Anniversary, combat log dostepny) albo nowoczesny klient (Forever, retail)
do
  local ok, _, _, _, iface = pcall(GetBuildInfo)
  iface = (ok and tonumber(iface)) or 0
  ns.IFACE = iface
  ns.isForever = iface > 16000 and iface < 20000
  ns.isModern = ns.isForever or iface >= 100000 or (CombatLogGetCurrentEventInfo == nil)
  ns.isClassic = not ns.isModern
  ns.GRA = ns.isForever and "forever" or (ns.isModern and "retail" or "classic")
end

-- wartosc ukryta przez gre (secret value): nie wolno jej porownac ani zapisac
local _isSecret = issecretvalue or function() return false end
local _isSecretTable = issecrettable
-- uwaga: ukrytej wartosci nie wolno nawet porownac (== nil), dlatego sprawdzamy ja zawsze najpierw
function ns.Hidden(v)
  if _isSecret(v) then return true end
  if _isSecretTable and type(v) == "table" then
    local ok, r = pcall(_isSecretTable, v)
    return ok and r or false
  end
  return false
end
-- wartosc do zapisu: ukryta -> "ukryte" (+ licznik w DIAG)
function ns.Safe(v, kind)
  if ns.Hidden(v) then
    if ns.DiagHidden then ns.DiagHidden(kind or "?") end
    return "ukryte"
  end
  return v
end
ns.PREFIX = "LUDOSon"

local TAG = "|cff4fc3f7LUDOS-on|r "
function ns.msg(text) DEFAULT_CHAT_FRAME:AddMessage(TAG .. text) end
ns.now = GetServerTime

local DB, CH, S
ns.state = { loadTime = 0, reloadPending = false, inEncounter = false }

-------------------------------------------------------------------------------
-- Nazwy zdarzen w dzienniku (kod -> nazwa wyswietlana)
-------------------------------------------------------------------------------
ns.NAZWY = {
  ZALOGOWANIE = "Zalogowanie", WYLOGOWANIE = "Wylogowanie", RELOAD = "Reload",
  PLAYED = "Played", STREFA = "Zmiana strefy", PODSTREFA = "Zmiana podstrefy",
  LOT_START = "Lot - start", LOT_KONIEC = "Lot - koniec",
  AFK_START = "AFK - start", AFK_KONIEC = "AFK - koniec",
  EXP = "Exp", AWANS = "Awans", QUEST_PRZYJETY = "Quest przyjety", QUEST_ODDANY = "Quest oddany",
  REPUTACJA = "Reputacja", RESTED = "Rested",
  SMIERC = "Smierc", DUCH = "Duch", WSKRZESZONY = "Wskrzeszony", POWROT = "Powrot do ciala",
  OFERTA_WSKRZESZENIA = "Oferta wskrzeszenia", NAPRAWA = "Naprawa",
  WALKA = "Walka", OTOCZENIE = "Obrazenia od otoczenia", ZABOJSTWO = "Zabojstwo",
  GILDIA = "Gildia postaci", GILDIA_KOMUNIKAT = "Komunikat gildii", ONLINE = "Online", OFFLINE = "Offline",
  STAN_GILDII = "Stan gildii",
  GRUPA = "Grupa", LIDER = "Lider grupy", ZAPISY = "Zapisy do instancji",
  BOSS_START = "Boss - start", BOSS_KONIEC = "Boss - koniec", BOSS_ZABITY = "Boss zabity", KRZYK = "Krzyk",
  ZLOTO = "Zloto podniesione", ZLOTO_STAN = "Stan zlota", LOOT = "Loot",
  UMIEJETNOSC = "Umiejetnosc", TALENT = "Talenty", NOWY_CZAR = "Nowy czar",
  PVP_HK = "Zabojstwa honorowe", PVP_RANGA = "Ranga PvP", PVP_FLAGA = "Flaga PvP",
  PRZYP_POKAZANE = "Przypomnienie pokazane", PRZYP_ZAPIS = "Zapis z przypomnienia",
  PRZYP_ODLOZONE = "Przypomnienie odlozone", PRZYP_WYLACZONE = "Przypomnienia wylaczone",
  WROG_SPOTKANY = "Wrog spotkany", PVP_ZABOJSTWO = "PvP - zabojstwo", PVP_SMIERC = "PvP - smierc",
  DIAG = "Diagnostyka",
}

-------------------------------------------------------------------------------
-- Pomocnicze
-------------------------------------------------------------------------------
function ns.Money(c)
  c = math.floor(tonumber(c) or 0)
  local neg = c < 0
  if neg then c = -c end
  local g, s, m = math.floor(c / 10000), math.floor((c % 10000) / 100), c % 100
  local out = {}
  if g > 0 then out[#out + 1] = g .. " g" end
  if s > 0 then out[#out + 1] = s .. " s" end
  if m > 0 or #out == 0 then out[#out + 1] = m .. " m" end
  return (neg and "-" or "") .. table.concat(out, " ")
end

function ns.Dur(sec)
  sec = math.max(0, math.floor(tonumber(sec) or 0))
  local h, m = math.floor(sec / 3600), math.floor((sec % 3600) / 60)
  if h > 0 then return string.format("%d h %02d min", h, m) end
  if m > 0 then return string.format("%d min %02d s", m, sec % 60) end
  return sec .. " s"
end

-- sekundy z jednym miejscem po przecinku (np. "8,4 s"); dluzsze czasy w minutach
function ns.Sec1(sec)
  sec = tonumber(sec) or 0
  if sec >= 600 then return ns.Dur(sec) end
  return (string.format("%.1f", sec):gsub("%.", ",")) .. " s"
end

function ns.Round1(x) return math.floor((tonumber(x) or 0) * 10 + 0.5) / 10 end

-- zamiana formatu z GlobalStrings (np. "%s has joined the guild.") na wzorzec Lua
function ns.FmtToPattern(fmt)
  if type(fmt) ~= "string" then return nil end
  local p = fmt:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1")
  p = p:gsub("%%%%%d%%%$s", "(.+)"):gsub("%%%%%d%%%$d", "(%%d+)")
  p = p:gsub("%%%%s", "(.+)"):gsub("%%%%d", "(%%d+)")
  return "^" .. p .. "$"
end

function ns.Short(name)
  if not name then return nil end
  if Ambiguate then return Ambiguate(name, "none") end
  return (name:gsub("%-.*$", ""))
end

-- ID mapy (uiMapID) miejsca gracza; nil na ekranie ladowania
function ns.MapID()
  if not (C_Map and C_Map.GetBestMapForUnit) then return nil end
  local ok, id = pcall(C_Map.GetBestMapForUnit, "player")
  if ok and id then ns.state.mapa = id; return id end
  return nil
end

-- GUID gracza tylko z GUID-ow typu Player-...
function ns.PlayerGUID(guid)
  if ns.Hidden(guid) then return nil end
  if type(guid) == "string" and guid:sub(1, 7) == "Player-" then return guid end
  return nil
end

-- ID moba (NPC ID) z GUID, np. "Creature-0-4372-0-11-1234-0000ABCD" -> 1234
function ns.NpcID(guid)
  if ns.Hidden(guid) or type(guid) ~= "string" then return nil end
  local kind, id = guid:match("^(%a+)%-%d+%-%d+%-%d+%-%d+%-(%d+)")
  if kind == "Creature" or kind == "Vehicle" or kind == "Pet" then return tonumber(id) end
  return nil
end

-------------------------------------------------------------------------------
-- Krotki opis wiersza (okno i tryb debug)
-------------------------------------------------------------------------------
local OPIS = {
  ZALOGOWANIE = function(d) return string.format("lvl %s, %s", tostring(d.lvl), tostring(d.strefa)) end,
  WYLOGOWANIE = function(d) return string.format("lvl %s, %s", tostring(d.lvl), tostring(d.strefa)) end,
  RELOAD = function(d) return "" end,
  PLAYED = function(d) return "lacznie " .. ns.Dur(d.lacznie) .. ", na poziomie " .. ns.Dur(d.poziom) end,
  STREFA = function(d) return tostring(d.strefa) .. ((d.instancja and d.instancja ~= "none") and (" (" .. d.instancja .. ")") or "") end,
  PODSTREFA = function(d) return tostring(d.pod) end,
  LOT_START = function(d) return "z " .. tostring(d.skad) end,
  LOT_KONIEC = function(d) return "do " .. tostring(d.dokad) end,
  AFK_KONIEC = function(d) return ns.Dur(d.sek) end,
  EXP = function(d) return string.format("+%d (%s)", d.ile or 0, d.zrodlo or "?") end,
  AWANS = function(d) return "lvl " .. tostring(d.lvl) end,
  QUEST_PRZYJETY = function(d) return tostring(d.nazwa or d.id) end,
  QUEST_ODDANY = function(d) return string.format("%s, exp %d, zloto %s", tostring(d.nazwa or d.id), d.exp or 0, ns.Money(d.zloto)) end,
  REPUTACJA = function(d) return string.format("%s %+d (%s)", tostring(d.frakcja), d.zmiana or 0, tostring(d.poziom or "")) end,
  RESTED = function(d) return string.format("%s: %d", tostring(d.kiedy), d.ile or 0) end,
  SMIERC = function(d) return string.format("%s, %s, %s", tostring(d.zabojca), tostring(d.czar or "-"), tostring(d.strefa)) end,
  DUCH = function(d) return d.po_s and ("po " .. ns.Dur(d.po_s)) or "" end,
  POWROT = function(d) return d.po_s and ("po " .. ns.Dur(d.po_s) .. " od smierci") or "" end,
  WSKRZESZONY = function(d) return d.po_s and ("po " .. ns.Dur(d.po_s) .. " od smierci") or "" end,
  OFERTA_WSKRZESZENIA = function(d) return "od " .. tostring(d.od) end,
  NAPRAWA = function(d) return string.format("%d%% -> %d%%", d.przed or 0, d.po or 0) end,
  WALKA = function(d)
    return string.format("%s, %s, zadane %s, otrzymane %s, zabici %d%s", ns.Sec1(d.sek), tostring(d.cele or "-"),
      tostring(d.zadane or 0), tostring(d.otrzymane or 0), d.zabici_ile or 0,
      (tonumber(d.chybienia) or 0) > 0 and (", chybienia " .. d.chybienia) or "")
  end,
  ZABOJSTWO = function(d)
    local loot = d.lootowany and (ns.Money(d.zloto or 0) .. ", przedmioty " .. ns.Money(d.wartosc or 0)) or "nie lootowany"
    return string.format("%s, %s, %s%s", d.ttk and ns.Sec1(d.ttk) or "-", tostring(d.nazwa), loot, d.grupa and " (grupa)" or "")
  end,
  OTOCZENIE = function(d) return string.format("%s %d", tostring(d.typ), d.ile or 0) end,
  GILDIA = function(d) return string.format("%s, %s", tostring(d.gildia or "brak"), tostring(d.ranga or "-")) end,
  GILDIA_KOMUNIKAT = function(d) return string.format("%s: %s", tostring(d.typ), tostring(d.kto)) end,
  ONLINE = function(d) return tostring(d.kto) end,
  OFFLINE = function(d) return tostring(d.kto) end,
  STAN_GILDII = function(d) return string.format("%d czlonkow, %d online", d.liczba or 0, d.online or 0) end,
  GRUPA = function(d) return string.format("%s %s (%d os.)", tostring(d.typ), tostring(d.kto or ""), d.rozmiar or 0) end,
  LIDER = function(d) return tostring(d.kto) end,
  ZAPISY = function(d) return (d.lista and #d.lista or 0) .. " zapisow" end,
  BOSS_START = function(d) return tostring(d.nazwa) end,
  BOSS_KONIEC = function(d) return tostring(d.nazwa) .. (d.wynik == 1 and ", zabity" or ", wipe") end,
  BOSS_ZABITY = function(d) return tostring(d.nazwa) end,
  KRZYK = function(d) return tostring(d.kto) .. ": " .. tostring(d.tekst) end,
  ZLOTO = function(d) return ns.Money(d.miedz) end,
  ZLOTO_STAN = function(d) return tostring(d.kiedy) .. ": " .. ns.Money(d.miedz) end,
  LOOT = function(d) return string.format("%s: %s x%d", d.ja and "ja" or tostring(d.kto), tostring(d.nazwa), d.ile or 1) end,
  UMIEJETNOSC = function(d) return string.format("%s %d -> %d", tostring(d.nazwa), d.z or 0, d.na or 0) end,
  TALENT = function(d) return "wolne punkty: " .. tostring(d.wolne) end,
  NOWY_CZAR = function(d) return tostring(d.nazwa or d.id) end,
  PVP_HK = function(d) return "HK w sesji: " .. tostring(d.hk) end,
  PVP_RANGA = function(d) return tostring(d.nazwa or d.ranga) end,
  PVP_FLAGA = function(d) return d.wl and "wlaczona" or "wylaczona" end,
  WROG_SPOTKANY = function(d)
    return string.format("%s (%s %s %s)%s", tostring(d.nazwa), tostring(d.lvl or "?"), tostring(d.rasa or ""), tostring(d.klasa or ""),
      d.gildia and (" <" .. d.gildia .. ">") or "")
  end,
  PVP_ZABOJSTWO = function(d)
    return string.format("%s%s, %s%s", tostring(d.nazwa), d.gildia and (" <" .. d.gildia .. ">") or "", tostring(d.strefa),
      d.moj_cios and ", moj cios" or "")
  end,
  PVP_SMIERC = function(d)
    return string.format("od %s%s, %s, %s", tostring(d.nazwa), d.gildia and (" <" .. d.gildia .. ">") or "", tostring(d.czar or "-"), tostring(d.strefa))
  end,
  DIAG = function(d) return tostring(d.typ) .. (d.co and (": " .. d.co) or "") .. (d.zdarzenie and (": " .. d.zdarzenie) or "") end,
}

function ns.Opis(row)
  local f = OPIS[row.e]
  if not f or not row.d then return "" end
  local ok, s = pcall(f, row.d)
  return ok and s or ""
end

-------------------------------------------------------------------------------
-- Baza, role i postac
-------------------------------------------------------------------------------
local DEFAULTS = {
  przyp_okno = true, przyp_czat = true, wskazowka = true, debug = false,
  odbior = true,          -- oficer (ranga 0-1): odbieram dane od graczy
  zw_pokaz = true,        -- widget stanu zapisu
  kt_pokaz = false, kt_alpha = 0.85, kt_lock = false, kt_ile = 8, -- Killtracker (testowy)
}

function ns.InitDB()
  if type(LUDOSon_DB) ~= "table" then LUDOSon_DB = {} end
  DB = LUDOSon_DB
  DB.meta = DB.meta or {}
  DB.meta.wersja = ns.VERSION
  DB.meta.schemat = 5
  DB.meta.gra = ns.GRA
  DB.meta.tryb = nil -- 0.4.0: rola z rangi w gildii
  local u = DB.meta.ustawienia or {}
  for k, v in pairs(DEFAULTS) do if u[k] == nil then u[k] = v end end
  u.zbieranie, u.przyp_min, u.przyp_reload = nil, nil, nil -- 0.4.0: zbieranie obowiazkowe, przypominajka wg stanu zapisu
  DB.meta.ustawienia = u
  DB.postacie = DB.postacie or {}
  DB.wymiana = DB.wymiana or {} -- dziennik wymiany danych (osobno od dziennika gry)
  DB.odebrane = nil              -- 0.2.0: zarezerwowane, teraz odebrane dane sa w LUDOS-on_Odbior
  ns.DB = DB
end

function ns.U() return DB.meta.ustawienia end
-- oficer w LUDOS-on = odbiorca (ranga 0-1 w gildii albo lista z Config.lua)
function ns.IsOficer() return ns.IsReceiver() end

local function inList(list, name)
  if not name then return false end
  for _, n in ipairs(list or {}) do if n == name then return true end end
  return false
end

-- podpis listy wpisanej na sztywno: inna lista w nowej wersji add-onu kasuje przyslana przez mastera
function ns.ConfigSig()
  return table.concat(ns.CONFIG.ODBIORCY, ",") .. "|" .. table.concat(ns.CONFIG.MASTERS, ",")
end

-- aktualna lista odbiorcow: przyslana przez mastera albo wpisana na sztywno
function ns.Receivers()
  local o = DB and DB.meta.odbiorcy
  if o and o.lista and (o.wersja or 0) > 0 and o.baza == ns.ConfigSig() then return o.lista, o.wersja end
  return ns.CONFIG.ODBIORCY, 0
end
function ns.Me() return UnitName("player") end
function ns.IsMaster(name) return inList(ns.CONFIG.MASTERS, name or ns.Me()) end
-- odbiorca: ranga w gildii <= RANGA_MAX (wg listy gildii z serwera) albo imie na liscie z Config.lua
function ns.IsReceiver(name)
  name = name or ns.Me()
  if inList((ns.Receivers()), name) then return true end
  local r = ns.GuildRank and ns.GuildRank(name)
  return r ~= nil and r <= (ns.CONFIG.RANGA_MAX or 1)
end
-- czy ja odbieram dane (odbiorca i nie wylaczyl odbioru w ustawieniach)
function ns.AmReceiving() return ns.IsReceiver() and ns.U().odbior ~= false end
function ns.InList(list, name) return inList(list, name) end

local function charKey()
  return (UnitName("player") or "?") .. "-" .. (GetRealmName() or "?")
end
ns.CharKey = charKey

function ns.InitChar()
  local k = charKey()
  DB.postacie[k] = DB.postacie[k] or { licznik_sesji = 0, sesje = {} }
  CH = DB.postacie[k]
  CH.imie = UnitName("player")
  -- ID postaci = GUID z gry (stale przy zmianie imienia), ID konta = GUID pierwszej postaci z add-onem na koncie
  CH.guid = UnitGUID("player") or CH.guid
  if not DB.meta.konto_id and CH.guid then DB.meta.konto_id = CH.guid end
  CH.realm = GetRealmName()
  local _, c = UnitClass("player"); CH.klasa = c
  local _, r = UnitRace("player"); CH.rasa = r
  CH.frakcja = UnitFactionGroup("player")
  CH.gildia = GetGuildInfo("player") or CH.gildia
  CH.questy = CH.questy or {}
  CH.kt = CH.kt or { kolejnosc = {}, moby = {} } -- historia Killtrackera
  ns.CH = CH
end

-------------------------------------------------------------------------------
-- Wielkosc danych (szacunek pliku SavedVariables, sprawdzony na plikach testerow: +-2%)
-------------------------------------------------------------------------------
ns.LIMIT_BAJTOW = 10 * 1024 * 1024
-- format pliku gry: ["klucz"] = wartosc,<CR><LF>; elementy listy bez klucza; bez wciec
local function est(v, depth)
  local t = type(v)
  if t == "string" then return #v + 2 end
  if t == "number" then return #tostring(v) end
  if t == "boolean" then return v and 4 or 5 end
  if t ~= "table" then return 3 end
  local n, arr = 4, #v
  for k, x in pairs(v) do
    n = n + 3 + est(x, depth + 1)
    if not (type(k) == "number" and k >= 1 and k <= arr and k % 1 == 0) then
      n = n + (type(k) == "string" and #k + 7 or #tostring(k) + 5)
    end
  end
  return n
end
ns.Est = est
local ROW_DEPTH = 6 -- LUDOSon_DB.postacie[k].sesje[i].dziennik[n]

-- wielkosc sesji (zapisana w sesji, liczona od nowa, gdy jej nie ma - dane sprzed 0.4.1)
local function sessionBytes(s)
  if not s.bajty then
    local b = 0
    for _, row in ipairs(s.dziennik or {}) do b = b + est(row, ROW_DEPTH) end
    s.bajty = b
  end
  return s.bajty + 250 -- naglowek sesji
end

local baseBytes = 0
local function measureBase()
  baseBytes = est(DB.meta, 2) + est(DB.wymiana or {}, 2)
  for _, ch in pairs(DB.postacie) do baseBytes = baseBytes + est(ch.kt or {}, 3) + est(ch.questy or {}, 3) + 300 end
end

function ns.DataSize()
  if not DB then return 0, ns.LIMIT_BAJTOW end
  local total = baseBytes
  for _, ch in pairs(DB.postacie) do
    for _, s in ipairs(ch.sesje or {}) do total = total + sessionBytes(s) end
  end
  return total, ns.LIMIT_BAJTOW
end

-- sesja odebrana w calosci przez co najmniej jednego oficera
local function confirmedAny(s)
  local n = #(s.dziennik or {})
  for _, o in pairs(s.odebrali or {}) do
    if (o["do"] or 0) >= n then return true end
  end
  return false
end
ns.ConfirmedAny = confirmedAny

-- przy wczytaniu: ponad limit usuwamy najstarsze potwierdzone sesje (bez biezacej i bez trwajacych)
local function cleanup()
  measureBase()
  local total = ns.DataSize()
  if total <= ns.LIMIT_BAJTOW then return end
  local before = total
  local cand = {}
  for key, ch in pairs(DB.postacie) do
    for _, s in ipairs(ch.sesje or {}) do
      if s ~= S and s.stan ~= "trwa" and confirmedAny(s) then cand[#cand + 1] = { ch = ch, s = s } end
    end
  end
  table.sort(cand, function(a, b) return (a.s.start or 0) < (b.s.start or 0) end)
  local nS, nW = 0, 0
  for _, c in ipairs(cand) do
    if total <= ns.LIMIT_BAJTOW then break end
    for i, s in ipairs(c.ch.sesje) do
      if s == c.s then table.remove(c.ch.sesje, i) break end
    end
    total = total - sessionBytes(c.s)
    nS, nW = nS + 1, nW + #(c.s.dziennik or {})
  end
  ns.state.sprzatanie = { sesji = nS, wierszy = nW, mb_przed = math.floor(before / 104857.6) / 10,
    mb_po = math.floor(total / 104857.6) / 10, ponad_limit = total > ns.LIMIT_BAJTOW or nil }
end

-------------------------------------------------------------------------------
-- Dziennik
-------------------------------------------------------------------------------
function ns.Log(e, d)
  if not S or not DB then return nil end
  if not S.bajty then sessionBytes(S) end
  local row = { n = #S.dziennik + 1, t = ns.now(), e = e, d = d or {} }
  S.dziennik[row.n] = row
  S.bajty = S.bajty + est(row, ROW_DEPTH)
  S.koniec = row.t
  if ns.U().debug then
    ns.msg("|cff888888" .. (ns.NAZWY[e] or e) .. "|r " .. ns.Opis(row))
  end
  if ns.OnLogged then ns.OnLogged(row) end
  return row
end

function ns.Unsaved()
  if not S then return 0 end
  return #S.dziennik - (S.zapisane_do or 0)
end

-------------------------------------------------------------------------------
-- Haki modulow: start, resume, loading, logout_real, logout, login (po wszystkim)
-------------------------------------------------------------------------------
local hooks = {}
function ns.AddHook(kind, fn)
  hooks[kind] = hooks[kind] or {}
  table.insert(hooks[kind], fn)
end
function ns.Fire(kind, ...)
  for _, fn in ipairs(hooks[kind] or {}) do
    local ok, err = pcall(fn, ...)
    if not ok and DB and ns.U().debug then ns.msg("blad: " .. tostring(err)) end
  end
end

-------------------------------------------------------------------------------
-- Sesje
-------------------------------------------------------------------------------
local function markInterrupted()
  local last = CH.sesje[#CH.sesje]
  if last and last.stan == "trwa" then
    last.stan = "przerwana"
    local lr = last.dziennik[#last.dziennik]
    last.koniec = (lr and lr.t) or last.start
  end
end

local function startSession()
  markInterrupted()
  CH.licznik_sesji = (CH.licznik_sesji or 0) + 1
  S = {
    nr = CH.licznik_sesji, start = ns.now(), koniec = ns.now(), stan = "trwa",
    reloady = 0, zapisane_do = 0, wersja = ns.VERSION,
    odebrali = {}, -- kto z odbiorcow potwierdzil te sesje: [imie] = { do = n, t = czas }
    dziennik = {},
  }
  table.insert(CH.sesje, S)
  ns.S = S
end

local function resumeSession()
  local last = CH.sesje[#CH.sesje]
  if not last then return false end
  -- wznowienie tylko, gdy ostatni wpis jest swiezy (reload); stara "trwa" = przerwana (crash, zabity proces)
  local lr0 = last.dziennik and last.dziennik[#last.dziennik]
  local lastT = (lr0 and lr0.t) or last.koniec or last.start or 0
  if ns.now() - lastT > 600 then return false end
  if last.stan == "trwa" then
    S = last
  elseif last.stan == "zamknieta" and (ns.now() - (last.koniec or 0)) <= 120 then
    S = last -- reload, ktorego nie wylapal hak: cofamy zamkniecie
    local lr = S.dziennik[#S.dziennik]
    if lr and lr.e == "WYLOGOWANIE" then lr.e = "RELOAD"; lr.d = {} end
    S.stan = "trwa"
  else
    return false
  end
  S.reloady = (S.reloady or 0) + 1
  S.odebrali = S.odebrali or {}
  ns.S = S
  return true
end

function ns.Sessions() return CH and CH.sesje or {} end

-------------------------------------------------------------------------------
-- Zdarzenia
-------------------------------------------------------------------------------
local frame = CreateFrame("Frame")
local handlers = {}
function ns.On(event, fn)
  if not handlers[event] then
    handlers[event] = {}
    pcall(frame.RegisterEvent, frame, event) -- zdarzenie moze nie istniec w danej wersji gry
  end
  table.insert(handlers[event], fn)
end
-- bezpiecznik: obsluga zdarzenia, ktora 5 razy zglosi blad, wylacza sie do konca sesji (wpis w DIAG)
local failures = {}
frame:SetScript("OnEvent", function(_, event, ...)
  local list = handlers[event]
  if not list then return end
  for i, fn in ipairs(list) do
    local key = event .. "#" .. i
    if (failures[key] or 0) < 5 then
      local ok, err = pcall(fn, ...)
      if not ok then
        failures[key] = (failures[key] or 0) + 1
        if ns.DiagError then ns.DiagError(event, err, failures[key] >= 5) end
        if DB and ns.U().debug then ns.msg("blad (" .. event .. "): " .. tostring(err)) end
      end
    end
  end
end)

ns.On("ADDON_LOADED", function(name)
  if name == ADDON then ns.InitDB() end
end)

ns.On("PLAYER_ENTERING_WORLD", function(isInitialLogin, isReloadingUi)
  ns.state.myGUID = UnitGUID("player")
  ns.state.petGUID = UnitGUID("pet")
  if not CH then ns.InitChar() end
  if S then -- ekran ladowania w trakcie sesji
    ns.Fire("loading")
    return
  end
  local resumed = false
  if isReloadingUi then
    resumed = resumeSession()
  end
  if not resumed then startSession() end
  ns.state.reloadPending = false
  ns.state.loadTime = ns.now()
  S.zapisane_do = #S.dziennik -- wszystko, co wczytane z pliku, jest w pliku
  local okc, errc = pcall(cleanup)
  if not okc and ns.DiagError then ns.DiagError("sprzatanie", errc, false) end
  if resumed then
    ns.Fire("resume")
  else
    ns.Log("ZALOGOWANIE", { lvl = UnitLevel("player"), strefa = GetZoneText(), pod = GetSubZoneText(), mapa = ns.MapID() })
    ns.Fire("start")
  end
  ns.Fire("ready")
  local sp = ns.state.sprzatanie
  if sp then
    ns.Log("DIAG", { typ = "sprzatanie", sesji = sp.sesji, wierszy = sp.wierszy, mb_przed = sp.mb_przed, mb_po = sp.mb_po,
      ponad_limit = sp.ponad_limit })
    if sp.ponad_limit then
      ns.msg(string.format("Dane add-onu: %.1f MB (limit 10 MB). Reszta to dane jeszcze niewyslane do oficerow - pojda, gdy oficer bedzie w grze.", sp.mb_po))
    end
  end
  local rola = ns.IsMaster() and "master" or (ns.IsReceiver() and (ns.AmReceiving() and "odbiorca" or "oficer (odbior wylaczony)") or "gracz")
  ns.msg(string.format("v%s zaladowany. Sesja %d%s, rola: %s. Wpisz /ludos, aby otworzyc okno, pomoc i liste komend.",
    ns.VERSION, S.nr, resumed and " (po reloadzie)" or "", rola))
end)

-- /reload, przycisk zapisu i przypominajka wolaja ReloadUI: zapamietujemy, ze to reload, a nie wylogowanie
hooksecurefunc("ReloadUI", function() ns.state.reloadPending = true end)

ns.On("PLAYER_LOGOUT", function()
  if not S then return end
  ns.Fire("logout")
  if ns.state.reloadPending then
    ns.Log("RELOAD", {})
  else
    ns.Fire("logout_real")
    ns.Log("WYLOGOWANIE", { lvl = ns.state.lvl or UnitLevel("player"), strefa = ns.state.zone or GetZoneText(),
      mapa = ns.state.mapa or ns.MapID() })
    S.stan = "zamknieta"
  end
  S.koniec = ns.now()
  S.zapisane_do = #S.dziennik
  DB.meta.ostatni_zapis = ns.now()
  ns.Fire("saved")
end)

-------------------------------------------------------------------------------
-- Komendy
-------------------------------------------------------------------------------
function ns.PrintStatus()
  if not S then ns.msg("Brak aktywnej sesji.") return end
  ns.msg(string.format("Sesja %d od %s (%s). Zdarzen: %d, czeka na zapis: %d. Reloadow: %d.",
    S.nr, date("%H:%M", S.start), ns.Dur(ns.now() - S.start), #S.dziennik, ns.Unsaved(), S.reloady or 0))
end

function ns.PrintHelp()
  ns.msg("/ludos - okno (informacje, ustawienia, widgety, magazyn, odbior, pomoc)")
  ns.msg("/ludos status - podsumowanie sesji na czacie")
  ns.msg("/ludos zapisz - zapis danych (/reload)")
  ns.msg("/ludos przypomnij - pokaz przypominajke teraz (do testu)")
  ns.msg("/ludos kt - pokaz / ukryj Killtracker (widget testowy)")
  ns.msg("/ludos zw - pokaz / ukryj widget stanu zapisu")
  ns.msg("/ludos wymiana - stan wymiany danych z odbiorcami")
  ns.msg("/ludos wyslij - oglos stan danych odbiorcom teraz")
  ns.msg("/ludos odbiorca lista | dodaj Imie | usun Imie - lista odbiorcow (zmiany tylko master)")
  ns.msg("/ludos zrzut - reczny zrzut listy gildii (tylko oficer)")
  ns.msg("/ludos debug - na czacie, co zapisuje add-on (dla dewelopera)")
  ns.msg("/ludos sonda - na czacie, co podaje gra (do testu; nic nie zapisuje)")
  ns.msg("/ludos pomoc - ta lista")
end

SLASH_LUDOSON1 = "/ludos"
SlashCmdList.LUDOSON = function(arg)
  arg = ((arg or ""):match("^%s*(.-)%s*$")) or ""
  local cmd, rest = arg:match("^(%S*)%s*(.-)$")
  cmd = (cmd or ""):lower()
  if not DB then return end
  if cmd == "" then
    if ns.ToggleWindow then ns.ToggleWindow() end
  elseif cmd == "status" then
    ns.PrintStatus()
  elseif cmd == "zapisz" then
    ReloadUI()
  elseif cmd == "przypomnij" then
    if ns.ShowReminder then ns.ShowReminder(true) end
  elseif cmd == "kt" then
    ns.U().kt_pokaz = not ns.U().kt_pokaz
    if ns.KT_Apply then ns.KT_Apply() end
    ns.msg("Killtracker (testowy): " .. (ns.U().kt_pokaz and "pokazany" or "ukryty"))
  elseif cmd == "zw" then
    ns.U().zw_pokaz = not ns.U().zw_pokaz
    if ns.ZW_Apply then ns.ZW_Apply() end
    ns.msg("Widget stanu zapisu: " .. (ns.U().zw_pokaz and "pokazany" or "ukryty"))
  elseif cmd == "wymiana" then
    if ns.CommsStatus then ns.CommsStatus() end
  elseif cmd == "wyslij" then
    if ns.Announce then ns.Announce(true) end
  elseif cmd == "odbiorca" then
    if ns.ReceiverCommand then ns.ReceiverCommand(rest) end
  elseif cmd == "zrzut" then
    if ns.ManualSnapshot then ns.ManualSnapshot() end
  elseif cmd == "sonda" then
    if ns.Sonda then ns.Sonda() end
  elseif cmd == "debug" then
    ns.U().debug = not ns.U().debug
    ns.msg("Tryb debug: " .. (ns.U().debug and "wlaczony" or "wylaczony"))
  elseif cmd == "pomoc" or cmd == "help" then
    ns.PrintHelp()
  else
    ns.msg("Nieznana komenda. Wpisz /ludos pomoc")
  end
end

-------------------------------------------------------------------------------
-- Sonda: co naprawde podaje gra (0.4.0: serwer, blokady, licznik obrazen, C_Club). Tylko czat, nic nie trafia do dziennika.
-------------------------------------------------------------------------------
local sondaCzary = {}
function ns.SondaCzar(id, name)
  table.insert(sondaCzary, string.format("%s=%s", tostring(name), tostring(id)))
  if #sondaCzary > 5 then table.remove(sondaCzary, 1) end
end
ns.sondaLoot = {}

function ns.Sonda()
  local function p(k, v) ns.msg("|cffffd100sonda|r " .. k .. ": " .. tostring(v)) end
  local ver, build, iface
  if GetBuildInfo then
    local v, b, _, i = GetBuildInfo()
    ver, build, iface = v, b, i
  end
  p("gra", string.format("%s (%s), interface %s", tostring(ver), tostring(build), tostring(iface)))
  p("postac GUID", UnitGUID("player"))
  p("ID konta (LUDOS-on)", DB and DB.meta.konto_id)
  p("ID mapy", ns.MapID())
  p("ostatnie czary (nazwa=ID)", #sondaCzary > 0 and table.concat(sondaCzary, ", ") or "brak - rzuc kilka czarow w walce")
  p("GetLootSourceInfo", GetLootSourceInfo and "jest" or "BRAK")
  p("ostatni loot", #ns.sondaLoot > 0 and table.concat(ns.sondaLoot, " | ") or "brak - zlootuj moba")
  if IsInGuild() and GetGuildRosterInfo then
    local r = { pcall(GetGuildRosterInfo, 1) }
    if r[1] then
      p("gildia: pozycja 1", string.format("%s, GUID (17. wartosc): %s", tostring(r[2]), tostring(r[18])))
    else
      p("gildia", "blad odczytu listy")
    end
  else
    p("gildia", "nie jestes w gildii")
  end
  if IsInGroup() then p("grupa party1 GUID", UnitGUID("party1")) end
  -- 0.4.0: serwer, blokady, licznik obrazen, gildia (C_Club)
  p("rodzaj gry (LUDOS-on)", string.format("%s, interface %s", tostring(ns.GRA), tostring(ns.IFACE)))
  local n, r = UnitFullName("player")
  p("serwer", string.format("GetRealmName: %s, UnitFullName: %s-%s", tostring(GetRealmName and GetRealmName()), tostring(n), tostring(r)))
  p("combat log dla add-onow", CombatLogGetCurrentEventInfo and "jest (Classic)" or "brak (Forever/retail - licznik gry)")
  if C_RestrictedActions and C_RestrictedActions.GetAddOnRestrictionState and Enum and Enum.AddOnRestrictionType then
    local st = {}
    for k, v in pairs(Enum.AddOnRestrictionType) do
      local ok, s = pcall(C_RestrictedActions.GetAddOnRestrictionState, v)
      st[#st + 1] = k .. "=" .. tostring(ok and s or "?")
    end
    table.sort(st)
    p("blokady (0 brak, 1 wlacza sie, 2 aktywna)", table.concat(st, ", "))
  else
    p("blokady", "brak w tej grze")
  end
  if C_DamageMeter and C_DamageMeter.IsDamageMeterAvailable then
    local ok, a, why = pcall(C_DamageMeter.IsDamageMeterAvailable)
    p("licznik obrazen gry", ok and (tostring(a) .. (why and (" (" .. tostring(why) .. ")") or "")) or "blad")
  else
    p("licznik obrazen gry", "brak")
  end
  p("podsumowanie smierci (C_DeathRecap)", C_DeathRecap and "jest" or "brak")
  if C_Club and C_Club.GetGuildClubId then
    local ok, id = pcall(C_Club.GetGuildClubId)
    p("gildia C_Club id", ok and tostring(id) or "blad")
  end
  if ns.DiagSummary then
    local e, h = ns.DiagSummary()
    p("od wczytania: bledy / ukryte wartosci", e .. " / " .. h)
  end
  if ns.AmReceiving then
    p("ranga w gildii / odbior", tostring(ns.GuildRank and ns.GuildRank(ns.Me())) .. " / " .. (ns.AmReceiving() and "tak" or "nie"))
  end
end
