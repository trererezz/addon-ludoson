-- LUDOS-on 0.4.1 - wymiana danych z odbiorcami (oficerowie i master) przez ukryty czat add-onow.
-- 0.4.1: kazda sesja idzie do najwyzej 2 oficerow (pierwszych, ktorzy odpowiedza). Gdy obaj maja ja
-- w calosci, sesja jest gotowa i nie idzie do kolejnych. Przydzielony oficer, ktory nie odpowiada od 30 min,
-- zwalnia miejsce dla nastepnego. Przydzial: sesja.przydzial[imie] = czas przydzialu.
--
-- Protokol (prefiks LUDOSon, pola rozdzielone ";", tresc zawsze w ostatnim polu):
-- 0.4.0: odbiorcy wg rangi w gildii (0-1), dwie etykiety (prefiksy): dane B/D pod "LUDOSon",
-- sterowanie H/R/A/L pod "LUDOSonC" (gra liczy limit wiadomosci osobno dla kazdej etykiety),
-- potwierdzenia zbiorcze (jedno A na sesje co kilka sekund), paczki po 100 wierszy,
-- pauza, gdy gra blokuje czat add-onow (ograniczenia Chat / Encounter).
-- Sesje rozpoznajemy po STARCIE (czas serwera), nie po numerze: numer moze sie powtorzyc
-- po crashu, na drugim komputerze albo po skasowaniu WTF (0.3.0 gubil wtedy dane).
--   H;2;wersjaListy;postac;start:ostatni,...  GUILD   "mam takie sesje" (gracz -> wszyscy)
--   R;postac;start:mam,...                  WHISPER odbiorca -> gracz: ile wierszy kazdej sesji juz ma
--   L;wersja;Imie,Imie,...                  GUILD/WHISPER  nowa lista odbiorcow (tylko master)
--   B;id;postac;start;od;do;nr;stan;koniec;n;guid;konto  WHISPER naglowek paczki (wiersze od-do);
--                                           guid = GUID postaci, konto = ID konta (GUID pierwszej postaci)
--   D;id;i;kawalek                          WHISPER kolejne kawalki paczki (JSON -> deflate -> kodowanie kanalu)
--   A;postac;start;mam;status               WHISPER odbiorca -> gracz: potwierdzenie (ok / dup / luka)
--
-- Odbiorca zapisuje paczki w pliku LUDOS-on_Odbior (osobny add-on), dane skompresowane
-- i zakodowane znakami drukowalnymi (LibDeflate EncodeForPrint). Dziennik wymiany jest w
-- LUDOSon_DB.wymiana, NIE w dzienniku gry.

local ADDON, ns = ...
local now = ns.now
local LD = LibStub and LibStub("LibDeflate", true)

local PROTO = 3
local PREFIX_DATA, PREFIX_CTRL = ns.PREFIX, ns.PREFIX .. "C"
local MIN_START = 1000000000 -- start sesji to czas serwera; mniejsza liczba = wiadomosc z 0.3.0 (numer sesji)
local BATCH_ROWS = 100       -- wierszy w paczce
local ACK_DELAY = 4          -- s: potwierdzenia zbierane w jedno
local ACTIVE_TTL = 7200      -- s: odbiorca "aktywny", jesli odpowiedzial w ciagu 2 h
local CHUNK = 240            -- znakow w jednej wiadomosci D
local MAX_BATCHES = 20       -- paczek na sesje na runde (reszta w kolejnej)
local MAX_SESSIONS_H = 12    -- sesji w ogloszeniu H
local ANNOUNCE_EVERY = 600
local SEND_EVERY = 1.0       -- s miedzy wiadomosciami (limit gry: ok. 1/s na prefiks)
local PENDING_TTL = 300
local LOG_MAX = 300
local TARGET = 2             -- ilu oficerow dostaje kazda sesje
local STALE = 1800           -- s: przydzielony oficer bez odpowiedzi tak dlugo zwalnia miejsce

if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
  C_ChatInfo.RegisterAddonMessagePrefix(PREFIX_DATA)
  C_ChatInfo.RegisterAddonMessagePrefix(PREFIX_CTRL)
end

-------------------------------------------------------------------------------
-- JSON (wiersze dziennika -> tekst; Python czyta to bez dodatkow)
-------------------------------------------------------------------------------
local function isArray(t)
  local n = 0
  for k in pairs(t) do
    if type(k) ~= "number" or k < 1 or k % 1 ~= 0 then return false end
    n = n + 1
  end
  for i = 1, n do if t[i] == nil then return false end end
  return true, n
end

local ESC = { ['"'] = '\\"', ['\\'] = '\\\\', ['\b'] = '\\b', ['\f'] = '\\f', ['\n'] = '\\n', ['\r'] = '\\r', ['\t'] = '\\t' }
local function jstr(s)
  return '"' .. s:gsub('[%c"\\]', function(c) return ESC[c] or string.format("\\u%04x", c:byte()) end) .. '"'
end

local function jenc(v, out)
  local tv = type(v)
  if tv == "string" then out[#out + 1] = jstr(v)
  elseif tv == "number" then
    if v ~= v or v == math.huge or v == -math.huge then out[#out + 1] = "null"
    elseif v % 1 == 0 and v > -1e15 and v < 1e15 then out[#out + 1] = string.format("%d", v)
    else out[#out + 1] = string.format("%.14g", v) end
  elseif tv == "boolean" then out[#out + 1] = v and "true" or "false"
  elseif tv == "table" then
    local arr, n = isArray(v)
    if arr and n > 0 then
      out[#out + 1] = "["
      for i = 1, n do
        if i > 1 then out[#out + 1] = "," end
        jenc(v[i], out)
      end
      out[#out + 1] = "]"
    else
      out[#out + 1] = "{"
      local first = true
      local keys = {}
      for k in pairs(v) do keys[#keys + 1] = k end
      table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)
      for _, k in ipairs(keys) do
        if not first then out[#out + 1] = "," end
        first = false
        out[#out + 1] = jstr(tostring(k))
        out[#out + 1] = ":"
        jenc(v[k], out)
      end
      out[#out + 1] = "}"
    end
  else out[#out + 1] = "null" end
end

function ns.JSON(v)
  local out = {}
  jenc(v, out)
  return table.concat(out)
end

-------------------------------------------------------------------------------
-- Pomocnicze
-------------------------------------------------------------------------------
local function DB() return ns.DB end
local function me() return UnitName("player") end

local function WLog(typ, kto, opis)
  local w = DB() and DB().wymiana
  if not w then return end
  w[#w + 1] = { t = now(), typ = typ, kto = kto, opis = opis }
  while #w > LOG_MAX do table.remove(w, 1) end
  if ns.U().debug then ns.msg("|cff888888wymiana " .. typ .. "|r " .. tostring(kto or "") .. " " .. tostring(opis or "")) end
end
ns.WLog = WLog

local function split(msg, n)
  -- n pierwszych pol, ostatnie pole = reszta wiadomosci (moze zawierac ";")
  local out, pos = {}, 1
  for i = 1, n - 1 do
    local s, e = msg:find(";", pos, true)
    if not s then out[i] = msg:sub(pos); return out end
    out[i] = msg:sub(pos, s - 1)
    pos = e + 1
  end
  out[n] = msg:sub(pos)
  return out
end

local function pairsList(txt)
  local t = {}
  for a, b in (txt or ""):gmatch("(%d+):(%d+)") do t[#t + 1] = { tonumber(a), tonumber(b) } end
  return t
end

local function odbiorDB()
  if type(LUDOSon_Odbior_DB) == "table" and LUDOSon_Odbior_DB.gracze then return LUDOSon_Odbior_DB end
  return nil
end
ns.OdbiorDB = odbiorDB

local function restricted(name)
  local t = Enum and Enum.AddOnRestrictionType and Enum.AddOnRestrictionType[name]
  if t == nil or not (C_RestrictedActions and C_RestrictedActions.IsAddOnRestrictionActive) then return false end
  local ok, active = pcall(C_RestrictedActions.IsAddOnRestrictionActive, t)
  return ok and active == true
end
-- pauza wysylki: walka, walka z bossem, gra blokuje czat add-onow
local function inCombat()
  return InCombatLockdown() or UnitAffectingCombat("player") or ns.state.inEncounter
    or restricted("Chat") or restricted("Encounter")
end
ns.CommsPaused = inCombat

local function sessionByStart(start)
  if not start or start < MIN_START then return nil end
  for _, s in ipairs(ns.Sessions()) do if s.start == start then return s end end
end

-------------------------------------------------------------------------------
-- Kolejka wysylki (1 wiadomosc / s, pauza w walce)
-------------------------------------------------------------------------------
local queue = {}        -- dane (B, D)
local queueC = {}       -- sterowanie (H, R, A, L)
local recentWhisper = {} -- [krotkie imie] = czas ostatniego szeptu (do ukrycia "nie ma takiego gracza")
local stats = { wyslane = 0, odrzucone = 0 }

local function enqueue(channel, target, text, tag, front)
  local item = { ch = channel, to = target, text = text, tag = tag, proby = 0 }
  local typ = tag and tag.typ
  local q, pfx = queue, PREFIX_DATA
  if typ ~= "B" then q, pfx = queueC, PREFIX_CTRL end -- D ma tag typu "B" (ta sama paczka)
  item.pfx = pfx
  if front then table.insert(q, 1, item) else q[#q + 1] = item end
end

local function sendNow(item)
  local ok, res
  if C_ChatInfo and C_ChatInfo.SendAddonMessage then
    ok, res = pcall(C_ChatInfo.SendAddonMessage, item.pfx, item.text, item.ch, item.to)
  else
    ok, res = pcall(SendAddonMessage, item.pfx, item.text, item.ch, item.to)
  end
  if not ok then return "blad" end
  if res == nil or res == true or res == 0 then return "ok" end
  if res == 3 or res == 8 or res == false then return "limit" end -- AddonMessageThrottle / ChannelThrottle
  return "blad"
end

local function pumpQueue(q)
  if #q == 0 or inCombat() then return end
  local item = q[1]
  local r = sendNow(item)
  if r == "ok" then
    table.remove(q, 1)
    stats.wyslane = stats.wyslane + 1
    if item.ch == "WHISPER" then recentWhisper[ns.Short(item.to)] = GetTime() end
  else
    item.proby = item.proby + 1
    if item.proby >= 5 or r == "blad" then
      table.remove(q, 1)
      stats.odrzucone = stats.odrzucone + 1
    end
  end
end
local function pump() pumpQueue(queueC); pumpQueue(queue) end
C_Timer.NewTicker(SEND_EVERY, pump)

local function purgeQueue(fn)
  for _, q in ipairs({ queue, queueC }) do
    for i = #q, 1, -1 do
      if fn(q[i]) then table.remove(q, i) end
    end
  end
end

-------------------------------------------------------------------------------
-- Strona gracza: ogloszenia i wysylka paczek
-------------------------------------------------------------------------------
local pending = {}   -- [odbiorca][start] = { do = n, t = GetTime() }
local batchSeq = 0
local lastAnnounce = 0

-- odbiorcy aktywni: ci, ktorzy odpowiedzieli w ciagu ostatnich 2 h (oficer z wylaczonym odbiorem nie odpowiada)
local function activeReceivers()
  local a = DB().meta.aktywni_odbiorcy or {}
  DB().meta.aktywni_odbiorcy = a
  local out = {}
  for name, t in pairs(a) do
    if now() - t <= ACTIVE_TTL and name ~= me() then out[#out + 1] = name else a[name] = nil end
  end
  return out
end
ns.ActiveReceivers = activeReceivers

local function complete(s, r)
  local o = s.odebrali and s.odebrali[r]
  return o ~= nil and (o["do"] or 0) >= #s.dziennik
end

-- ilu oficerow ma sesje w calosci
local function completeCount(s)
  local n = 0
  for r in pairs(s.odebrali or {}) do if complete(s, r) then n = n + 1 end end
  return n
end

-- gotowa: TARGET oficerow ma sesje w calosci (nie ogloszamy jej wiecej)
local function fullyAcked(s)
  return completeCount(s) >= TARGET
end
ns.FullyAcked = fullyAcked

-- czy wysylac te sesje temu oficerowi: miejsce zajmuje kazdy, kto ma ja w calosci,
-- i kazdy przydzielony, ktory odpowiadal w ciagu ostatnich 30 min
local function mayServe(s, r)
  if complete(s, r) then return false end
  s.przydzial = s.przydzial or {}
  local act = DB().meta.aktywni_odbiorcy or {}
  local others = 0
  for name in pairs(s.odebrali or {}) do
    if name ~= r and complete(s, name) then others = others + 1 end
  end
  for name in pairs(s.przydzial) do
    if name ~= r and not complete(s, name) then
      if now() - (act[name] or 0) <= STALE then others = others + 1 else s.przydzial[name] = nil end
    end
  end
  if others >= TARGET then
    s.przydzial[r] = nil
    return false
  end
  s.przydzial[r] = s.przydzial[r] or now()
  return true
end

local function announceList()
  local out = {}
  local list = ns.Sessions()
  for i = #list, 1, -1 do
    local s = list[i]
    if #s.dziennik > 0 and not fullyAcked(s) then
      table.insert(out, 1, string.format("%d:%d", s.start, #s.dziennik))
      if #out >= MAX_SESSIONS_H then break end
    end
  end
  return out
end

function ns.Announce(manual)
  if not ns.S or not IsInGuild() then
    if manual then ns.msg("Wymiana dziala tylko w gildii.") end
    return
  end
  if not LD then if manual then ns.msg("Brak biblioteki LibDeflate - wymiana wylaczona.") end return end
  local list = announceList()
  local _, ver = ns.Receivers()
  local tail = table.concat(list, ",")
  -- ogloszenie miesci sie w 255 znakach (15 sesji); w razie czego ucinamy najstarsze
  local text = string.format("H;%d;%d;%s;%s", PROTO, ver, ns.CharKey(), tail)
  while #text > 250 and #list > 1 do
    table.remove(list, 1)
    text = string.format("H;%d;%d;%s;%s", PROTO, ver, ns.CharKey(), table.concat(list, ","))
  end
  enqueue("GUILD", nil, text, { typ = "H" })
  lastAnnounce = GetTime()
  WLog("H", "gildia", (#list > 0) and (#list .. " sesji do potwierdzenia") or "wszystko potwierdzone")
  if manual then
    ns.msg(#list > 0 and string.format("Ogloszono %d sesji odbiorcom. Wysylka ruszy, gdy ktorys odbiorca odpowie.", #list)
      or "Wszystkie sesje sa juz u odbiorcow. Ogloszenie wyslane.")
  end
end

local function queueSession(receiver, target, s, have)
  local n = #s.dziennik
  if have >= n then return 0 end
  pending[receiver] = pending[receiver] or {}
  local p = pending[receiver][s.start]
  if p and GetTime() - p.t < PENDING_TTL then return 0 end
  local key, batches = ns.CharKey(), 0
  local from = have + 1
  local last = have
  while from <= n and batches < MAX_BATCHES do
    local to = math.min(n, from + BATCH_ROWS - 1)
    local rows = {}
    for i = from, to do rows[#rows + 1] = s.dziennik[i] end
    local json = ns.JSON(rows)
    local comp = LD:CompressDeflate(json)
    local enc = LD:EncodeForWoWAddonChannel(comp)
    local nchunks = math.max(1, math.ceil(#enc / CHUNK))
    batchSeq = (batchSeq % 9999) + 1
    local tag = { typ = "B", odb = receiver, st = s.start }
    enqueue("WHISPER", target, string.format("B;%d;%s;%d;%d;%d;%d;%s;%d;%d;%s;%s", batchSeq, key, s.start, from, to,
      s.nr or 0, s.stan or "?", s.koniec or 0, nchunks, tostring(ns.CH and ns.CH.guid or ""), tostring(ns.DB.meta.konto_id or "")), tag)
    for i = 1, nchunks do
      enqueue("WHISPER", target, string.format("D;%d;%d;%s", batchSeq, i, enc:sub((i - 1) * CHUNK + 1, i * CHUNK)), tag)
    end
    batches = batches + 1
    last = to
    from = to + 1
  end
  pending[receiver][s.start] = { ["do"] = last, t = GetTime() }
  WLog("WYSYLKA", receiver, string.format("sesja %d, wiersze %d-%d (%d paczek)", s.nr, have + 1, last, batches))
  return batches
end

local function setAcked(s, receiver, have)
  s.odebrali = s.odebrali or {}
  local o = s.odebrali[receiver]
  if not o or (o["do"] or 0) <= have then
    s.odebrali[receiver] = { ["do"] = have, t = now() }
  end
end

-- odpowiedz R od odbiorcy: co juz ma
local reannounce = false
local function onReply(sender, short, f)
  if not ns.IsReceiver(short) then
    -- lista gildii jeszcze nie wczytana (rangi nieznane): popros o nia i oglos sie ponownie
    if ns.RosterLoaded and not ns.RosterLoaded() and not reannounce then
      reannounce = true
      if ns.RequestRoster then ns.RequestRoster() end
      C_Timer.After(20, function() reannounce = false; ns.Announce(false) end)
    end
    return
  end
  DB().meta.aktywni_odbiorcy = DB().meta.aktywni_odbiorcy or {}
  DB().meta.aktywni_odbiorcy[short] = now()
  local key = f[2]
  if key ~= ns.CharKey() then return end
  for _, p in ipairs(pairsList(f[3])) do
    local s = sessionByStart(p[1])
    if s then
      setAcked(s, short, p[2])
      if mayServe(s, short) then queueSession(short, sender, s, p[2]) end
    end
  end
end

-- potwierdzenie A
local function onAck(sender, short, f)
  if not ns.IsReceiver(short) then return end
  if f[2] ~= ns.CharKey() then return end
  local st, have, status = tonumber(f[3]), tonumber(f[4]), f[5]
  local s = sessionByStart(st)
  if not s or not have then return end
  local nr = s.nr
  setAcked(s, short, have)
  local p = pending[short] and pending[short][st]
  if status == "luka" then
    -- odbiorca nie ma wczesniejszych wierszy: kasujemy kolejke tej sesji i wysylamy od miejsca, ktore ma
    purgeQueue(function(it) return it.tag and it.tag.odb == short and it.tag.st == st end)
    if pending[short] then pending[short][st] = nil end
    WLog("LUKA", short, string.format("sesja %d, odbiorca ma %d - wysylam od nowa", nr, have))
    queueSession(short, sender, s, have)
    return
  end
  if p and have >= (p["do"] or 0) then
    pending[short][st] = nil
    WLog("POTWIERDZONE", short, string.format("sesja %d: %d/%d", nr, have, #s.dziennik))
    -- duza zaleglosc: od razu kolejna runda; biezaca sesja dosyla sie przy kolejnym ogloszeniu
    local left = #s.dziennik - have
    if (left >= BATCH_ROWS or (left > 0 and s ~= ns.S)) and mayServe(s, short) then queueSession(short, sender, s, have) end
  end
end

-------------------------------------------------------------------------------
-- Strona odbiorcy: odpowiedzi i skladanie paczek
-------------------------------------------------------------------------------
ns._ackPend = {}
local inbound = {} -- [nadawca .. "#" .. id] = { meta, kawalki, ile, t }
local warnedNoOdbior = false

local function canReceive()
  if not ns.AmReceiving() then return false end
  if not odbiorDB() then
    if not warnedNoOdbior then
      warnedNoOdbior = true
      ns.msg("Jestes odbiorca, ale add-on |cffffd100LUDOS-on Odbior|r jest wylaczony - wlacz go na liscie add-onow.")
    end
    return false
  end
  return LD ~= nil
end

local function nameOfKey(key) return key and key:match("^(.-)%-") end

local function recFor(key)
  local O = odbiorDB()
  local g = O.gracze[key]
  if not g then g = { sesje = {} }; O.gracze[key] = g end
  return g
end

local function onHello(sender, short, f)
  -- f: H, proto, wersjaListy, postac, lista
  if tonumber(f[2]) ~= PROTO then return end -- inna wersja protokolu (np. 0.3.0) - pomijamy
  local ver, key = tonumber(f[3]) or 0, f[4]
  -- master pilnuje, zeby wszyscy mieli aktualna liste odbiorcow
  if ns.IsMaster(me()) then
    local list, myVer = ns.Receivers()
    if myVer > ver then
      enqueue("WHISPER", sender, string.format("L;%d;%s", myVer, table.concat(list, ",")), { typ = "L" }, true)
      WLog("LISTA", short, "wyslana wersja " .. myVer)
    end
  end
  if not canReceive() then return end
  if nameOfKey(key) ~= short then return end -- dane tylko o wlasnej postaci nadawcy
  local items = pairsList(f[5])
  if #items == 0 then return end
  local g = recFor(key)
  local out = {}
  for _, p in ipairs(items) do
    if p[1] >= MIN_START then
      local rec = g.sesje[p[1]]
      out[#out + 1] = string.format("%d:%d", p[1], rec and rec.do_n or 0)
    end
  end
  if #out == 0 then return end
  enqueue("WHISPER", sender, "R;" .. key .. ";" .. table.concat(out, ","), { typ = "R" }, true)
end

local function onHeader(sender, short, f)
  -- B, id, postac, start, od, do, nr, stan, koniec, n, guid, konto
  if not canReceive() then return end
  local key = f[3]
  if nameOfKey(key) ~= short then WLog("ODRZUCONE", short, "cudza postac " .. tostring(key)); return end
  local id = f[2]
  local st = tonumber(f[4])
  if not st or st < MIN_START then return end -- paczka z 0.3.0 (numer zamiast startu) - pomijamy
  local open = 0
  for k in pairs(inbound) do if k:sub(1, #short + 1) == short .. "#" then open = open + 1 end end
  if open > 40 then return end
  inbound[short .. "#" .. id] = {
    key = key, start = st, od = tonumber(f[5]), ["do"] = tonumber(f[6]),
    nr = tonumber(f[7]), stan = f[8], koniec = tonumber(f[9]), n = tonumber(f[10]) or 1,
    guid = (f[11] ~= "" and f[11]) or nil, konto = (f[12] ~= "" and f[12]) or nil,
    parts = {}, got = 0, t = GetTime(),
  }
end

local function finishBatch(sender, short, b)
  local enc = table.concat(b.parts)
  local comp = LD:DecodeForWoWAddonChannel(enc)
  local json = comp and LD:DecompressDeflate(comp)
  if not json or json:sub(1, 1) ~= "[" then
    WLog("BLAD", short, string.format("sesja %d: uszkodzona paczka %d-%d", b.nr or 0, b.od or 0, b["do"] or 0))
    return
  end
  local O = odbiorDB()
  local g = recFor(b.key)
  if b.guid then g.guid = b.guid end
  if b.konto then g.konto = b.konto end
  local rec = g.sesje[b.start]
  if not rec then rec = { do_n = 0, paczki = {} }; g.sesje[b.start] = rec end
  rec.start, rec.nr, rec.stan, rec.koniec = b.start, b.nr, b.stan, b.koniec
  local status
  if b["do"] <= rec.do_n then
    status = "dup"
  elseif b.od ~= rec.do_n + 1 then
    status = "luka"
  else
    local dane = LD:EncodeForPrint(comp)
    table.insert(rec.paczki, { od = b.od, ["do"] = b["do"], t = now(), nadawca = short, dane = dane })
    rec.do_n = b["do"]
    O.meta.rozmiar = (O.meta.rozmiar or 0) + math.floor((#dane + 90) * 1.08) -- jak liczy Odbior.lua
    O.meta.ostatni = now()
    g.ostatni = now()
    status = "ok"
    WLog("ODEBRANE", short, string.format("sesja %d, wiersze %d-%d", b.nr or 0, b.od, b["do"]))
    if ns.RefreshWindow then ns.RefreshWindow() end
  end
  if status ~= "ok" then WLog(status == "dup" and "DUPLIKAT" or "LUKA", short, string.format("sesja %d, paczka %d-%d, mam %d", b.nr or 0, b.od, b["do"], rec.do_n)) end
  if status == "luka" then
    enqueue("WHISPER", sender, string.format("A;%s;%d;%d;%s", b.key, b.start, rec.do_n, status), { typ = "A" }, true)
  else
    -- potwierdzenie zbiorcze: kilka paczek tej sesji = jedno A z ostatnim stanem
    local k = short .. "|" .. b.key .. "|" .. b.start
    local pend = ns._ackPend
    if not pend[k] then
      pend[k] = { sender = sender, key = b.key, start = b.start }
      C_Timer.After(ACK_DELAY, function()
        local a = pend[k]; pend[k] = nil
        local O2 = odbiorDB()
        local g2 = O2 and O2.gracze[a.key]
        local r2 = g2 and g2.sesje[a.start]
        if r2 then enqueue("WHISPER", a.sender, string.format("A;%s;%d;%d;ok", a.key, a.start, r2.do_n), { typ = "A" }, true) end
      end)
    end
  end
end

local function onData(sender, short, f)
  -- D, id, i, kawalek
  local k = short .. "#" .. tostring(f[2])
  local b = inbound[k]
  if not b then return end
  local i = tonumber(f[3])
  if not i or i < 1 or i > b.n or b.parts[i] then return end
  b.parts[i] = f[4] or ""
  b.got = b.got + 1
  b.t = GetTime()
  if b.got == b.n then
    inbound[k] = nil
    local ok, err = pcall(finishBatch, sender, short, b)
    if not ok then WLog("BLAD", short, tostring(err)) end
  end
end

-- porzucone paczki (nadawca wyszedl w trakcie)
C_Timer.NewTicker(60, function()
  local t = GetTime()
  for k, b in pairs(inbound) do if t - b.t > 120 then inbound[k] = nil end end
end)

-------------------------------------------------------------------------------
-- Lista odbiorcow (wpisana na sztywno, zmienia ja tylko master)
-------------------------------------------------------------------------------
local function applyList(ver, names, from)
  local list = {}
  for n in (names or ""):gmatch("[^,]+") do list[#list + 1] = n end
  DB().meta.odbiorcy = { wersja = ver, lista = list, od = from, t = now(), baza = ns.ConfigSig() }
  WLog("LISTA", from, "nowa lista v" .. ver .. ": " .. table.concat(list, ", "))
  ns.msg(string.format("Lista odbiorcow zaktualizowana (wersja %d, od %s): %s", ver, tostring(from), table.concat(list, ", ")))
end

local function onList(sender, short, f)
  if not ns.IsMaster(short) then return end -- liste moze zmienic tylko master
  local ver = tonumber(f[2])
  local _, myVer = ns.Receivers()
  if ver and ver > myVer then applyList(ver, f[3], short) end
end

local function cap(name)
  if not name or name == "" then return nil end
  return name:sub(1, 1):upper() .. name:sub(2):lower()
end

function ns.ReceiverCommand(rest)
  local sub, arg = (rest or ""):match("^(%S*)%s*(.-)$")
  sub = (sub or ""):lower()
  local list, ver = ns.Receivers()
  if sub == "" or sub == "lista" then
    ns.msg(string.format("Odbiorcy (wersja %d): %s", ver, table.concat(list, ", ")))
    ns.msg("Master: " .. table.concat(ns.CONFIG.MASTERS, ", ") .. (ns.IsReceiver() and " | Ty jestes odbiorca." or ""))
    return
  end
  if sub ~= "dodaj" and sub ~= "usun" then ns.msg("Uzycie: /ludos odbiorca lista | dodaj Imie | usun Imie") return end
  if not ns.IsMaster(me()) then ns.msg("Liste odbiorcow moze zmienic tylko master.") return end
  local name = cap(arg)
  if not name then ns.msg("Podaj imie postaci.") return end
  local new = {}
  for _, n in ipairs(list) do if n ~= name then new[#new + 1] = n end end
  if sub == "dodaj" then
    if ns.InList(list, name) then ns.msg(name .. " juz jest na liscie.") return end
    new[#new + 1] = name
  elseif #new == #list then
    ns.msg(name .. " nie ma na liscie.") return
  end
  local nv = ver + 1
  applyList(nv, table.concat(new, ","), me())
  enqueue("GUILD", nil, string.format("L;%d;%s", nv, table.concat(new, ",")), { typ = "L" }, true)
end

-------------------------------------------------------------------------------
-- Odbior wiadomosci
-------------------------------------------------------------------------------
local FIELDS = { H = 5, R = 3, L = 3, B = 12, D = 4, A = 5 }

ns.On("CHAT_MSG_ADDON", function(prefix, msg, channel, sender)
  if (prefix ~= PREFIX_DATA and prefix ~= PREFIX_CTRL) or type(msg) ~= "string" or not DB() then return end
  if ns.Hidden(msg) or ns.Hidden(sender) then return end
  local short = ns.Short(sender)
  if not short or short == me() then return end -- wlasne wiadomosci pomijamy
  local typ = msg:sub(1, 1)
  local n = FIELDS[typ]
  if not n or msg:sub(2, 2) ~= ";" then return end
  local f = split(msg, n)
  if typ == "H" then
    if channel == "GUILD" then onHello(sender, short, f) end
  elseif typ == "R" then onReply(sender, short, f)
  elseif typ == "A" then onAck(sender, short, f)
  elseif typ == "B" then onHeader(sender, short, f)
  elseif typ == "D" then onData(sender, short, f)
  elseif typ == "L" then onList(sender, short, f)
  end
end)

-------------------------------------------------------------------------------
-- Odbiorca wyszedl z gry: czyscimy kolejke i ukrywamy komunikat "nie ma takiego gracza"
-------------------------------------------------------------------------------
local notFoundPat
local function notFoundName(msg)
  if not notFoundPat then notFoundPat = ns.FmtToPattern(ERR_CHAT_PLAYER_NOT_FOUND_S or "No player named '%s' is currently playing.") end
  return notFoundPat and msg:match(notFoundPat)
end

ns.On("CHAT_MSG_SYSTEM", function(msg)
  if type(msg) ~= "string" then return end
  local who = notFoundName(msg)
  if not who then return end
  local short = ns.Short(who)
  if not recentWhisper[short] and not pending[short] then return end
  purgeQueue(function(it) return it.ch == "WHISPER" and ns.Short(it.to) == short end)
  pending[short] = nil
  WLog("OFFLINE", short, "odbiorca wyszedl - kolejka wyczyszczona")
end)

if ChatFrame_AddMessageEventFilter then
  ChatFrame_AddMessageEventFilter("CHAT_MSG_SYSTEM", function(_, _, msg)
    local who = type(msg) == "string" and notFoundName(msg)
    if who then
      local t = recentWhisper[ns.Short(who)]
      if t and GetTime() - t < 15 then return true end
    end
    return false
  end)
end

-------------------------------------------------------------------------------
-- Harmonogram ogloszen
-------------------------------------------------------------------------------
ns.AddHook("ready", function()
  C_Timer.After(30, function() ns.Announce(false) end)
end)
C_Timer.NewTicker(ANNOUNCE_EVERY, function()
  if GetTime() - lastAnnounce >= ANNOUNCE_EVERY - 5 then ns.Announce(false) end
end)
ns.On("PLAYER_REGEN_ENABLED", function()
  -- po walce: ogloszenie najwyzej co 5 minut (kolejka i tak rusza sama po walce)
  C_Timer.After(10, function()
    if not inCombat() and GetTime() - lastAnnounce >= 300 then ns.Announce(false) end
  end)
end)

-------------------------------------------------------------------------------
-- Stan wymiany (czat i okno)
-------------------------------------------------------------------------------
function ns.CommsInfo()
  return { kolejka = #queue + #queueC, wyslane = stats.wyslane, odrzucone = stats.odrzucone, pauza = inCombat(),
    ostatnie_ogloszenie = lastAnnounce }
end

-- odbiorcy do pokazania: aktywni + wszyscy, ktorym cos juz potwierdzili
function ns.ShownReceivers()
  local set, out = {}, {}
  for _, r in ipairs(activeReceivers()) do set[r] = true end
  for _, s in ipairs(ns.Sessions()) do for r in pairs(s.odebrali or {}) do set[r] = true end end
  for r in pairs(set) do if r ~= me() then out[#out + 1] = r end end
  table.sort(out)
  return out
end

function ns.CommsStatus()
  local act = activeReceivers()
  ns.msg(string.format("Odbiorcy: rangi 0-%d w gildii%s. Aktywni: %s. Kolejka: %d wiad.%s Wyslane: %d.",
    ns.CONFIG.RANGA_MAX or 1, (#ns.CONFIG.ODBIORCY > 0) and (" + " .. table.concat(ns.CONFIG.ODBIORCY, ", ")) or "",
    (#act > 0) and table.concat(act, ", ") or "brak", #queue + #queueC, inCombat() and " (pauza)" or "", stats.wyslane))
  if not IsInGuild() then ns.msg("Nie jestes w gildii - dane czekaja u Ciebie i pojda po dolaczeniu.") end
  local list = ns.ShownReceivers()
  local sess = ns.Sessions()
  for i = math.max(1, #sess - 4), #sess do
    local s = sess[i]
    local parts = {}
    for _, r in ipairs(list) do
      local o = s.odebrali and s.odebrali[r]
      parts[#parts + 1] = string.format("%s %d/%d", r, o and o["do"] or 0, #s.dziennik)
    end
    if #parts == 0 then parts[1] = string.format("%d zdarzen, jeszcze nic nie wyslano", #s.dziennik) end
    ns.msg(string.format("  sesja_%d: %s", s.nr, table.concat(parts, ", ")))
  end
  local O = odbiorDB()
  if ns.IsReceiver() then
    if not ns.AmReceiving() then
      ns.msg("Odbior danych wylaczony w ustawieniach.")
    elseif O then
      local n = 0
      for _ in pairs(O.gracze) do n = n + 1 end
      ns.msg(string.format("Odbior: %d graczy, %.1f KB danych.", n, (O.meta.rozmiar or 0) / 1024))
    else
      ns.msg("Odbior: wlacz add-on LUDOS-on Odbior.")
    end
  end
end

-- do testow
ns._comms = { queue = queue, queueC = queueC, pending = pending, inbound = inbound, pump = pump }
