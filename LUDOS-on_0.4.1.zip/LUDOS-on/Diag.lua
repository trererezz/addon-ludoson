-- LUDOS-on 0.4.0 - diagnostyka (wiersze DIAG): co gra naprawde udostepnia add-onom.
--   start   - nowa sesja: wersja add-onu i gry, dostepnosc funkcji (combat log, licznik obrazen,
--             podsumowanie smierci, zrodlo lootu, blokady), serwer.
--   ksztalt - pierwsze 3 probki odpowiedzi gry na sesje (licznik obrazen, podsumowanie smierci):
--             pola i typy wartosci, bez obrobki - do zbudowania modelu obrobki na prawdziwych danych.
--   wylaczone - obsluga zdarzenia wylaczona po 5 bledach (bezpiecznik w Core.lua).
--   koniec  - przy reloadzie / wylogowaniu: liczniki bledow, ukrytych wartosci i blokad od wczytania.

local ADDON, ns = ...
local Log = ns.Log

local errors, errorText, hidden, restr, shapes = {}, {}, {}, {}, {}
local SHAPE_MAX = 3

function ns.DiagError(event, err, disabled)
  errors[event] = (errors[event] or 0) + 1
  if not errorText[event] then errorText[event] = tostring(err):sub(1, 200) end
  if disabled then
    Log("DIAG", { typ = "wylaczone", zdarzenie = event, blad = errorText[event] })
  end
end

function ns.DiagHidden(kind)
  kind = kind or "?"
  hidden[kind] = (hidden[kind] or 0) + 1
end

-- probka odpowiedzi gry: nazwy pol, typy i krotkie wartosci (ukryte jako "ukryte")
function ns.DiagShape(tag, t)
  if (shapes[tag] or 0) >= SHAPE_MAX or type(t) ~= "table" then return end
  shapes[tag] = (shapes[tag] or 0) + 1
  local keys = {}
  for k in pairs(t) do if not ns.Hidden(k) then keys[#keys + 1] = tostring(k) end end
  table.sort(keys)
  local pola = {}
  for _, k in ipairs(keys) do
    local v = t[k]
    local txt
    if ns.Hidden(v) then txt = "ukryte"
    elseif type(v) == "table" then
      local n = 0
      for _ in pairs(v) do n = n + 1 end
      txt = "tabela[" .. n .. "]"
    else
      txt = type(v) .. ":" .. tostring(v):sub(1, 40)
    end
    pola[#pola + 1] = k .. "=" .. txt
    if #pola >= 30 then break end
  end
  Log("DIAG", { typ = "ksztalt", co = tag, probka = shapes[tag], pola = pola })
end

-- blokady add-onow (walka, boss, mityczne+, PvP, mapa, czat): ile razy wlaczone
local RT = {}
if Enum and Enum.AddOnRestrictionType then
  for k, v in pairs(Enum.AddOnRestrictionType) do RT[v] = k end
end
ns.On("ADDON_RESTRICTION_STATE_CHANGED", function(rtype, state)
  if ns.Hidden(rtype) or ns.Hidden(state) then return end
  local name = RT[rtype] or tostring(rtype)
  local r = restr[name] or { wl = 0, wyl = 0 }
  restr[name] = r
  if state == 2 then r.wl = r.wl + 1 elseif state == 0 then r.wyl = r.wyl + 1 end
end)

local function counters(t)
  local out = {}
  for k, v in pairs(t) do out[#out + 1] = k .. ":" .. tostring(v) end
  table.sort(out)
  return (#out > 0) and out or nil
end

local function has(f) return f ~= nil end

ns.AddHook("start", function()
  C_Timer.After(60, function()
    local ver, build, _, iface = GetBuildInfo()
    local dm, dmPowod
    if C_DamageMeter and C_DamageMeter.IsDamageMeterAvailable then
      local ok, a, why = pcall(C_DamageMeter.IsDamageMeterAvailable)
      if ok then dm, dmPowod = a, why end
    end
    local _, realmUnit = UnitFullName("player")
    Log("DIAG", {
      typ = "start", addon = ns.VERSION, gra = ns.GRA, wersja = ver, build = build, iface = iface,
      jezyk = GetLocale and GetLocale() or nil, serwer = GetRealmName and GetRealmName() or nil, serwer_postac = realmUnit,
      region = GetCurrentRegion and GetCurrentRegion() or nil,
      combatlog = has(CombatLogGetCurrentEventInfo), licznik = has(C_DamageMeter), licznik_dostepny = dm,
      licznik_powod = dmPowod, recap = has(C_DeathRecap), loot_zrodlo = has(GetLootSourceInfo),
      blokady = has(C_RestrictedActions), ukryte_wartosci = has(issecretvalue), club = has(C_Club),
      party_kill = not ns.isClassic,
    })
  end)
end)

ns.AddHook("logout", function()
  local n = 0
  for _, v in pairs(errors) do n = n + v end
  local rl = {}
  for k, r in pairs(restr) do rl[#rl + 1] = string.format("%s:%d/%d", k, r.wl, r.wyl) end
  table.sort(rl)
  local et = {}
  for k, v in pairs(errorText) do et[#et + 1] = k .. ": " .. v end
  Log("DIAG", {
    typ = "koniec", bledy = n, bledy_wg = counters(errors), bledy_tekst = (#et > 0) and et or nil,
    ukryte = counters(hidden), blokady = (#rl > 0) and rl or nil,
  })
end)

-- do sondy
function ns.DiagSummary()
  local n = 0
  for _, v in pairs(errors) do n = n + v end
  local h = 0
  for _, v in pairs(hidden) do h = h + v end
  return n, h, restr
end
