-- LUDOS-on 0.4.0 - zabojstwa: jeden wiersz ZABOJSTWO na kazdego zabitego moba.
-- Skad wiemy o zabiciu (pole zrodlo):
--   "combatlog"  - Classic: combat log; ttk od pierwszej akcji ofensywnej gracza/peta na moba.
--   "party_kill" - Forever/retail w swiecie: zdarzenie PARTY_KILL (gra podaje GUID moba);
--                  ttk od wejscia w walke albo od wziecia moba w cel, jesli pozniej (ttk_z = "walka" / "cel").
--   "exp"        - Forever/retail w instancji (GUID ukryte): komunikat o expie za moba ("X dies, you gain...");
--                  NPC ID uzupelniany z lootu (GUID ciala) albo z pamieci mobow widzianych w celu.
-- Exp za moba (pole exp, rested) dopisywany do zabojstwa w kazdej grze.
-- Czas do zabicia z dokladnoscia 0,1 s. Loot z okna lootu (zloto + wartosc przedmiotow u kupca).
-- Killtracker pokazuje zabojstwo od razu przy smierci moba, loot uzupelnia pozniej.
-- Loot czytany juz przy LOOT_READY (zanim zabierze go szybki autoloot); gdy okno jest puste
-- albo gra nie poda, z ktorego ciala jest loot - zapasowo z czatu ("You loot...", "You receive loot...")
-- do ostatnio zabitego moba, ktory czeka na loot. Zrodlo lootu w polu loot_z: okno / okno_bez_zrodla / czat.
-- Wiersz zapisujemy 2 s po lootcie (6 s przy czacie) albo 90 s po smierci, jesli mob nie byl lootowany.
-- Historia dla Killtrackera: 20 ostatnich zabojstw na moba, 100 ostatnich mobow.

local ADDON, ns = ...
local Log, now = ns.Log, ns.now
local band = bit.band
local HOSTILE = COMBATLOG_OBJECT_REACTION_HOSTILE or 0x00000040

local engaged = {}  -- [guid] = { gt0, nazwa, npc }
local pending = {}  -- [guid] = zabity, czeka na loot / zapis
local KT_PER_MOB, KT_MOBS = 20, 100
local LOOT_DELAY, CHAT_DELAY, NOLOOT_DELAY = 2, 6, 90
local CHAT_WINDOW = 5

local OFFENSIVE = {
  SWING_DAMAGE = true, RANGE_DAMAGE = true, SPELL_DAMAGE = true, SPELL_PERIODIC_DAMAGE = true,
  SWING_MISSED = true, RANGE_MISSED = true, SPELL_MISSED = true, SPELL_PERIODIC_MISSED = true,
}

local function isCreature(guid)
  return type(guid) == "string" and (guid:sub(1, 9) == "Creature-" or guid:sub(1, 8) == "Vehicle-")
end

local lastPrune = 0
local function prune()
  local gt = GetTime()
  if gt - lastPrune < 30 then return end
  lastPrune = gt
  for guid, e in pairs(engaged) do
    if gt - e.gt0 > 600 then engaged[guid] = nil end -- mob uciekl / zresetowal sie
  end
end

-------------------------------------------------------------------------------
-- Historia (Killtracker): wpis od razu przy smierci, loot dopisywany pozniej
-------------------------------------------------------------------------------
local function addHistory(k)
  local CH = ns.CH
  local key = k.npc or (k.nazwa and ("n:" .. k.nazwa))
  if not CH or not key then return nil end
  local kt = CH.kt
  local m = kt.moby[key]
  if not m then
    m = { nazwa = k.nazwa, lista = {} }
    kt.moby[key] = m
  end
  m.nazwa = k.nazwa or m.nazwa
  local h = { t = k.zgon, ttk = k.ttk, grupa = k.grupa or nil, czeka = true }
  table.insert(m.lista, h)
  while #m.lista > KT_PER_MOB do table.remove(m.lista, 1) end
  for i = #kt.kolejnosc, 1, -1 do
    if kt.kolejnosc[i] == key then table.remove(kt.kolejnosc, i) end
  end
  table.insert(kt.kolejnosc, key)
  while #kt.kolejnosc > KT_MOBS do
    local old = table.remove(kt.kolejnosc, 1)
    kt.moby[old] = nil
  end
  kt.ostatni = key
  return h
end

-------------------------------------------------------------------------------
-- Zapis wiersza
-------------------------------------------------------------------------------
local GII = (C_Item and C_Item.GetItemInfo) or GetItemInfo
local function itemValue(it)
  local price
  if GII then
    local ok, v = pcall(function() return select(11, GII(it.link or it.id)) end)
    if ok and not ns.Hidden(v) then price = tonumber(v) end
  end
  return price
end
local function cacheItem(link) if GII then pcall(GII, link) end end

local function write(guid)
  local k = pending[guid]
  if not k then return end
  pending[guid] = nil
  local wartosc, przedmioty, brak_ceny = 0, {}, false
  for _, it in ipairs(k.items) do
    local p = itemValue(it)
    if p then wartosc = wartosc + p * (it.ile or 1) else brak_ceny = true end
    przedmioty[#przedmioty + 1] = tostring(it.id or "?") .. ":" .. tostring(it.ile or 1)
  end
  k.wartosc = wartosc
  Log("ZABOJSTWO", {
    npc = k.npc, nazwa = k.nazwa, ttk = k.ttk, zgon = k.zgon,
    zloto = k.zloto, wartosc = wartosc, przedmioty = (#przedmioty > 0) and przedmioty or nil,
    lootowany = k.lootowany, grupa = k.grupa, npc_z = k.npc_z, moj_cios = k.moj_cios, brak_ceny = brak_ceny or nil, loot_z = k.loot_z,
    zrodlo = k.zrodlo, ttk_z = k.ttk_z, exp = k.exp, rested = k.rested, instancja = k.instancja,
  })
  local h = k.hist
  if h then
    h.czeka = nil
    h.loot = k.lootowany or nil
    h.zloto, h.wartosc = k.zloto, wartosc
  end
  if ns.KT_Update then ns.KT_Update() end
end

-------------------------------------------------------------------------------
-- Combat log: poczatek walki z mobem i jego smierc
-------------------------------------------------------------------------------
-- nowe zabojstwo: wpis do historii od razu (widget), wiersz po lootcie albo po 90 s
local xpQ = {}  -- ostatnie komunikaty o expie za moba { mob, xp, rested, gt, used }
local function takeXp(name)
  local gt = GetTime()
  for i = #xpQ, 1, -1 do
    local x = xpQ[i]
    if not x.used and gt - x.gt <= 2 and (name == nil or x.mob == name) then x.used = true return x end
  end
end

local function newKill(key, k)
  k.zgon, k.gt = now(), GetTime()
  k.grupa = (IsInGroup() or IsInRaid()) and true or false
  k.zloto, k.items, k.lootowany = 0, {}, false
  local inInst, instType = IsInInstance()
  k.instancja = inInst and instType or nil
  if not k.exp then
    local x = takeXp(k.nazwa)
    if x then k.exp, k.rested = x.xp, x.rested; k.nazwa = k.nazwa or x.mob end
  end
  pending[key] = k
  k.hist = addHistory(k)
  if ns.FightKill and not ns.isClassic then ns.FightKill(k.guid, k.nazwa) end
  if ns.KT_Update then ns.KT_Update() end -- widget od razu, loot pozniej
  C_Timer.After(NOLOOT_DELAY, function()
    local p = pending[key]
    if p and not p.lootSeen then write(key) end
  end)
  return k
end

if ns.isClassic then
ns.On("COMBAT_LOG_EVENT_UNFILTERED", function()
  local _, sub, _, srcGUID, _, _, _, dstGUID, dstName, dstFlags = CombatLogGetCurrentEventInfo()
  if sub == "UNIT_DIED" then
    local e = engaged[dstGUID]
    if not e then return end
    engaged[dstGUID] = nil
    newKill(dstGUID, { npc = e.npc, guid = dstGUID, nazwa = dstName or e.nazwa, ttk = ns.Round1(GetTime() - e.gt0), zrodlo = "combatlog" })
    return
  end
  local me, pet = ns.state.myGUID, ns.state.petGUID
  if srcGUID ~= me and not (pet and srcGUID == pet) then return end
  if engaged[dstGUID] or pending[dstGUID] or not isCreature(dstGUID) then return end
  local start = OFFENSIVE[sub]
  if not start and (sub == "SPELL_CAST_SUCCESS" or sub == "SPELL_AURA_APPLIED") then
    start = dstFlags and band(dstFlags, HOSTILE) > 0
  end
  if not start then return end
  engaged[dstGUID] = { gt0 = GetTime(), nazwa = dstName, npc = ns.NpcID(dstGUID) }
  prune()
end)
end -- ns.isClassic

-------------------------------------------------------------------------------
-- Forever / retail: combat log zablokowany. Pamiec mobow (cel, myszka, tabliczki nad glowa),
-- zabicie z PARTY_KILL (w swiecie) albo z komunikatu o expie (w instancji, gdzie GUID sa ukryte).
-------------------------------------------------------------------------------
local seen = {}   -- [guid] = { gt, tgt (pierwsze wziecie w cel), nazwa, npc }
local nseen = 0
local function noteUnit(unit, isTarget)
  local guid = UnitGUID(unit)
  if ns.Hidden(guid) or guid == nil or not isCreature(guid) then return end
  local e = seen[guid]
  if not e then
    if nseen > 400 then wipe(seen); nseen = 0 end
    local name = UnitName(unit)
    if ns.Hidden(name) then name = nil end
    e = { gt = GetTime(), nazwa = name, npc = ns.NpcID(guid) }
    seen[guid] = e
    nseen = nseen + 1
  end
  if isTarget then
    e.tgt = e.tgt or GetTime()
    if ns.FightTarget then ns.FightTarget(e.nazwa, guid) end
  end
end

local function ttkFor(e)
  local gt = GetTime()
  local t0, z = ns.state.combatGT, "walka"
  if e and e.tgt and (not t0 or e.tgt > t0) then t0, z = e.tgt, "cel" end
  if not t0 or gt - t0 > 600 then return nil, nil end
  return ns.Round1(gt - t0), z
end

-- mob o tej nazwie widziany ostatnio w celu (do NPC ID przy zabiciu z expa)
local function seenByName(name)
  if not name then return nil end
  local best
  for guid, e in pairs(seen) do
    if e.nazwa == name and not pending[guid] and (not best or (e.tgt or e.gt) > (best.tgt or best.gt)) then best = e; best.guid = guid end
  end
  return best
end

if not ns.isClassic then
  ns.On("PLAYER_TARGET_CHANGED", function() noteUnit("target", true) end)
  ns.On("UPDATE_MOUSEOVER_UNIT", function() noteUnit("mouseover", false) end)
  ns.On("NAME_PLATE_UNIT_ADDED", function(unit) if unit then noteUnit(unit, false) end end)

  ns.On("PARTY_KILL", function(attackerGUID, targetGUID)
    if ns.Hidden(targetGUID) or targetGUID == nil then
      if ns.DiagHidden then ns.DiagHidden("party_kill") end
      return -- w instancji GUID ukryte: zabicie przyjdzie z komunikatu o expie
    end
    if ns.PlayerGUID(targetGUID) then
      if ns.PvpKill then ns.PvpKill(targetGUID, (not ns.Hidden(attackerGUID)) and attackerGUID or nil) end
      return
    end
    if not isCreature(targetGUID) or pending[targetGUID] then return end
    local e = seen[targetGUID]
    local ttk, z = ttkFor(e)
    local mine = (not ns.Hidden(attackerGUID)) and (attackerGUID == ns.state.myGUID or attackerGUID == ns.state.petGUID) or false
    newKill(targetGUID, { npc = ns.NpcID(targetGUID), guid = targetGUID, nazwa = e and e.nazwa or nil,
      ttk = ttk, ttk_z = z, zrodlo = "party_kill", moj_cios = mine })
    seen[targetGUID] = nil
  end)
end

-- komunikat o expie za moba: dopisz exp do zabojstwa albo (gdy PARTY_KILL nie przyszedl) utworz zabojstwo
ns.AddHook("xp_mob", function(mob, xp, rested)
  local x = { mob = mob, xp = xp, rested = rested, gt = GetTime() }
  table.insert(xpQ, x)
  while #xpQ > 10 do table.remove(xpQ, 1) end
  C_Timer.After(0.5, function()
    if x.used then return end
    -- zabojstwo bez expa z ostatnich 2,5 s o tej nazwie (albo bez nazwy)
    local best
    for _, k in pairs(pending) do
      if not k.exp and GetTime() - k.gt <= 2.5 and (k.nazwa == nil or k.nazwa == mob) and (not best or k.gt > best.gt) then best = k end
    end
    if best then
      x.used = true
      best.exp, best.rested = xp, rested
      if not best.nazwa then best.nazwa = mob end
      return
    end
    if ns.isClassic then return end -- w Classic zabojstwa sa z combat logu
    x.used = true
    local e = seenByName(mob)
    local ttk, z = ttkFor(e)
    local key = "x:" .. string.format("%.1f", GetTime())
    newKill(key, { npc = e and e.npc or nil, nazwa = mob, ttk = ttk, ttk_z = z, zrodlo = "exp",
      exp = xp, rested = rested, bez_guid = true, npc_z = e and "cel" or nil })
    if e and e.guid then seen[e.guid] = nil end
  end)
end)

-------------------------------------------------------------------------------
-- Loot
-------------------------------------------------------------------------------
local SLOT_ITEM = (Enum and Enum.LootSlotType and Enum.LootSlotType.Item) or LOOT_SLOT_ITEM or 1
local SLOT_MONEY = (Enum and Enum.LootSlotType and Enum.LootSlotType.Money) or LOOT_SLOT_MONEY or 2

local function sources(slot)
  local out = {}
  if not GetLootSourceInfo then return out end
  local t = { GetLootSourceInfo(slot) }
  for i = 1, #t, 2 do
    local g, q = t[i], t[i + 1]
    if ns.Hidden(g) then
      out.ukryte = true
    elseif g then
      out[#out + 1] = { guid = g, ile = (not ns.Hidden(q) and tonumber(q)) or 0 }
    end
  end
  return out
end

-- ostatnio zabity mob, ktory jeszcze nie ma lootu (do zapasowego przypisania)
local function newestWaiting()
  local best, bestGuid
  for guid, k in pairs(pending) do
    if not k.lootSeen and GetTime() - k.gt <= NOLOOT_DELAY and (not best or k.gt > best.gt) then best, bestGuid = k, guid end
  end
  return best, bestGuid
end

local function addSlot(k, slot, stype, text, qty, srcCount, srcQty)
  if stype == SLOT_MONEY then
    local copper = (srcCount <= 1 and ns.ParseMoney and ns.ParseMoney(text or "")) or 0
    if copper == 0 then copper = srcQty or 0 end
    k.zloto = k.zloto + copper
  elseif stype == SLOT_ITEM or stype == nil then
    local link = GetLootSlotLink and GetLootSlotLink(slot) or nil
    local id = link and tonumber(link:match("item:(%d+)")) or nil
    if id then
      local ile = (srcCount <= 1 and tonumber(qty)) or srcQty
      if not ile or ile < 1 then ile = 1 end
      table.insert(k.items, { id = id, link = link, ile = ile })
      cacheItem(link) -- prosba o dane przedmiotu do pamieci klienta
    end
  end
end

local chatLoot          -- { guid, k, do_gt }: zapasowe zbieranie lootu z czatu
local windowDone = false -- to okno lootu juz obsluzone (LOOT_READY i LOOT_OPENED przychodza oba)

local function sonda(txt)
  table.insert(ns.sondaLoot, txt)
  if #ns.sondaLoot > 3 then table.remove(ns.sondaLoot, 1) end
end

local function dbg(txt) if ns.U().debug then ns.msg("|cff888888loot:|r " .. txt) end end

local function readLoot(event)
  if windowDone then return end
  local n = GetNumLootItems() or 0
  local touched, anySource = {}, false
  for slot = 1, n do
    local src = sources(slot)
    if #src > 0 then anySource = true end
    local stype = GetLootSlotType and GetLootSlotType(slot) or nil
    local _, text, qty = GetLootSlotInfo(slot)
    for _, s in ipairs(src) do
      local k = pending[s.guid]
      if k and not k.lootSeen then
        touched[s.guid] = k
        addSlot(k, slot, stype, text, qty, #src, s.ile)
      end
    end
  end
  local names = {}
  for guid, k in pairs(touched) do
    k.lootSeen, k.lootowany, k.loot_z = true, true, "okno"
    names[#names + 1] = tostring(k.nazwa)
    C_Timer.After(LOOT_DELAY, function() write(guid) end)
  end
  if #names > 0 then
    windowDone = true
    dbg(string.format("%d pozycji, przypisane do %s (okno, %s)", n, table.concat(names, ", "), event))
    sonda(string.format("%s: %d pozycji, przypisane do %s", event, n, table.concat(names, ", ")))
    return
  end
  -- Forever/retail w instancji: zabojstwa z expa nie maja GUID; loot z cial, ktorych GUID nie znamy,
  -- przypisujemy kolejno do czekajacych zabojstw bez GUID (od najstarszego) i z GUID ciala bierzemy NPC ID
  if anySource and not ns.isClassic then
    local waiting = {}
    for key, k in pairs(pending) do
      if k.bez_guid and not k.lootSeen and GetTime() - k.gt <= NOLOOT_DELAY then waiting[#waiting + 1] = { key = key, k = k } end
    end
    table.sort(waiting, function(a, b) return a.k.gt < b.k.gt end)
    if #waiting > 0 then
      local map, order = {}, {}
      for slot = 1, n do
        local src = sources(slot)
        local stype = GetLootSlotType and GetLootSlotType(slot) or nil
        local _, text, qty = GetLootSlotInfo(slot)
        for _, s in ipairs(src) do
          if not pending[s.guid] then
            if not map[s.guid] and #order < #waiting then
              order[#order + 1] = s.guid
              map[s.guid] = waiting[#order]
            end
            local w = map[s.guid]
            if w then addSlot(w.k, slot, stype, text, qty, #src, s.ile) end
          end
        end
      end
      for g, w in pairs(map) do
        local k = w.k
        k.lootSeen, k.lootowany, k.loot_z = true, true, "okno_dopasowane"
        if not k.npc then k.npc, k.npc_z = ns.NpcID(g), "loot" end
        names[#names + 1] = tostring(k.nazwa)
        local key = w.key
        C_Timer.After(LOOT_DELAY, function() write(key) end)
      end
      if #names > 0 then
        windowDone = true
        dbg(string.format("%d pozycji, dopasowane do zabojstw z expa: %s (%s)", n, table.concat(names, ", "), event))
        sonda(string.format("%s: %d pozycji, dopasowane (exp) do %s", event, n, table.concat(names, ", ")))
        return
      end
    end
  end
  -- nic nie dopasowane po GUID ciala
  local k, guid = newestWaiting()
  if n > 0 and not anySource and k then
    -- gra nie podala, z ktorego ciala jest loot: cale okno do ostatnio zabitego moba
    for slot = 1, n do
      local stype = GetLootSlotType and GetLootSlotType(slot) or nil
      local _, text, qty = GetLootSlotInfo(slot)
      addSlot(k, slot, stype, text, qty, 1, nil)
    end
    k.lootSeen, k.lootowany, k.loot_z = true, true, "okno_bez_zrodla"
    windowDone = true
    C_Timer.After(LOOT_DELAY, function() write(guid) end)
    dbg(string.format("%d pozycji bez zrodla, przypisane do %s (%s)", n, tostring(k.nazwa), event))
    sonda(string.format("%s: %d pozycji BEZ ZRODLA -> %s", event, n, tostring(k.nazwa)))
  elseif n == 0 and k then
    -- okno puste (szybki autoloot zdazyl je oproznic): loot z czatu do ostatnio zabitego moba
    k.lootSeen, k.lootowany, k.loot_z = true, true, "czat"
    chatLoot = { guid = guid, k = k, do_gt = GetTime() + CHAT_WINDOW }
    windowDone = true
    C_Timer.After(CHAT_DELAY, function()
      if chatLoot and chatLoot.guid == guid then chatLoot = nil end
      write(guid)
    end)
    dbg(string.format("okno puste, loot z czatu -> %s (%s)", tostring(k.nazwa), event))
    sonda(string.format("%s: okno PUSTE -> czat -> %s", event, tostring(k.nazwa)))
  else
    sonda(string.format("%s: %d pozycji, nie z zabitego moba", event, n))
  end
end

ns.On("LOOT_READY", function() readLoot("LOOT_READY") end)
ns.On("LOOT_OPENED", function() readLoot("LOOT_OPENED") end)
ns.On("LOOT_CLOSED", function() windowDone = false end)

-- zapas: loot z czatu (tylko w krotkim oknie po pustym oknie lootu)
local selfLootPats
local function chatActive()
  return chatLoot and GetTime() <= chatLoot.do_gt and pending[chatLoot.guid] == chatLoot.k
end
ns.On("CHAT_MSG_MONEY", function(msg)
  if not chatActive() or not ns.ParseMoney then return end
  chatLoot.k.zloto = chatLoot.k.zloto + ns.ParseMoney(msg or "")
end)
ns.On("CHAT_MSG_LOOT", function(msg)
  if not chatActive() then return end
  msg = msg or ""
  if not selfLootPats then
    selfLootPats = {}
    for _, key in ipairs({ "LOOT_ITEM_SELF_MULTIPLE", "LOOT_ITEM_SELF" }) do
      local p = ns.FmtToPattern(_G[key])
      if p then table.insert(selfLootPats, p) end
    end
  end
  local mine = false
  for _, p in ipairs(selfLootPats) do if msg:match(p) then mine = true break end end
  if not mine then return end
  local link = msg:match("(|c%x+|Hitem:.-|h%[.-%]|h|r)")
  local id = link and tonumber(link:match("item:(%d+)"))
  if not id then return end
  local qty = tonumber(msg:match("|rx(%d+)")) or 1
  table.insert(chatLoot.k.items, { id = id, link = link, ile = qty })
  cacheItem(link)
end)

-- przy wylogowaniu zapisujemy wszystko, co czeka
ns.AddHook("logout", function()
  for guid in pairs(pending) do write(guid) end
end)

-- do testow / okna
function ns.KT_History(npc)
  local CH = ns.CH
  if not CH then return nil end
  npc = npc or CH.kt.ostatni
  return npc and CH.kt.moby[npc], npc
end
