-- LUDOS-on Odbior 0.4.1 - osobny plik na dane odebrane od innych graczy.
-- Caly mechanizm wymiany jest w LUDOS-on (Comms.lua); ten add-on daje wlasny plik SavedVariables:
-- WTF\Account\<KONTO>\SavedVariables\LUDOS-on_Odbior.lua
--
-- Schemat 2 (0.3.1): gracze["Imie-Realm"] = { guid, konto, ostatni, sesje = { [start] = {...} } }
-- Sesje po STARCIE (czas serwera), nie po numerze. Dane ze schematu 1 (0.3.0, po numerze)
-- przenoszone przy wczytaniu pod klucz start.
--
-- 0.4.1: limit 50 MB. Przy wczytaniu kazda paczka dostaje licznik wczytan. Ponad limit usuwane sa
-- najstarsze paczki, ktore byly w pliku przy co najmniej 2 kolejnych wczytaniach (uploader wysyla
-- kazda wersje pliku, wiec zdazyl je wyslac) i maja ponad 24 h. Sesja zostaje (do_n - ile wierszy
-- juz mamy), zeby gracz nie wysylal jej od nowa. Puste sesje starsze niz 30 dni znikaja calkiem.
-- Paczek nowszych add-on nie rusza; gdy mimo to jest ponad limitem - ostrzezenie na czacie.

local LIMIT = 50 * 1024 * 1024
local MIN_AGE = 24 * 3600
local STUB_AGE = 30 * 24 * 3600
local OVERHEAD = 1.08 -- plik vs suma zakodowanych danych (zmierzone w symulacji)

local note
local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_ENTERING_WORLD")

local function migrate(O)
  if (O.meta.schemat or 1) < 2 then
    for _, g in pairs(O.gracze) do
      local nowe = {}
      for k, rec in pairs(g.sesje or {}) do
        rec.nr = rec.nr or k
        local key = tonumber(rec.start) or k
        if nowe[key] then key = k end -- dwie sesje z tym samym startem: zostaje stary klucz
        nowe[key] = rec
      end
      g.sesje = nowe
    end
  end
  O.meta.schemat = 2
end

local function trim(O)
  local now = GetServerTime()
  local total, list = 0, {}
  for key, g in pairs(O.gracze) do
    for st, rec in pairs(g.sesje or {}) do
      rec.paczki = rec.paczki or {}
      for i, p in ipairs(rec.paczki) do
        p.wczytan = (p.wczytan or 0) + 1
        total = total + #(p.dane or "") + 90
        if p.wczytan >= 2 and now - (p.t or now) > MIN_AGE then list[#list + 1] = { rec = rec, p = p } end
      end
    end
  end
  total = math.floor(total * OVERHEAD)
  local before, removed = total, 0
  if total > LIMIT then
    table.sort(list, function(a, b) return (a.p.t or 0) < (b.p.t or 0) end)
    local drop = {}
    for _, e in ipairs(list) do
      if total <= LIMIT then break end
      drop[e.p] = true
      total = total - math.floor((#(e.p.dane or "") + 90) * OVERHEAD)
      removed = removed + 1
    end
    for _, g in pairs(O.gracze) do
      for _, rec in pairs(g.sesje or {}) do
        local keep = {}
        for _, p in ipairs(rec.paczki) do if not drop[p] then keep[#keep + 1] = p end end
        if #keep ~= #rec.paczki then rec.paczki = keep; rec.przyciete = (rec.przyciete or 0) + 1 end
      end
    end
  end
  -- puste sesje (same liczniki) starsze niz 30 dni
  for _, g in pairs(O.gracze) do
    for st, rec in pairs(g.sesje or {}) do
      if #rec.paczki == 0 and now - (tonumber(rec.koniec) or tonumber(st) or now) > STUB_AGE then g.sesje[st] = nil end
    end
  end
  O.meta.rozmiar = total
  O.meta.limit = LIMIT
  if removed > 0 then
    O.meta.przyciecie = { t = now, paczek = removed, mb_przed = math.floor(before / 104857.6) / 10, mb_po = math.floor(total / 104857.6) / 10 }
  end
  if total > LIMIT then
    note = string.format("|cffff7366Odbior: %.1f MB (limit 50 MB).|r Nowsze dane nie zostaly jeszcze wyslane - sprawdz, czy uploader dziala.", total / 1048576)
  elseif removed > 0 then
    note = string.format("Odbior: usunieto %d starych paczek (juz wyslanych przez uploader), teraz %.1f MB.", removed, total / 1048576)
  end
end

f:SetScript("OnEvent", function(_, event, name)
  if event == "ADDON_LOADED" then
    if name ~= "LUDOS-on_Odbior" then return end
    if type(LUDOSon_Odbior_DB) ~= "table" then LUDOSon_Odbior_DB = {} end
    local O = LUDOSon_Odbior_DB
    O.meta = O.meta or {}
    O.gracze = O.gracze or {}
    migrate(O)
    local ok, err = pcall(trim, O)
    if not ok then note = "Odbior: blad przy liczeniu wielkosci - " .. tostring(err) end
    f:UnregisterEvent("ADDON_LOADED")
  elseif event == "PLAYER_ENTERING_WORLD" then
    if note then DEFAULT_CHAT_FRAME:AddMessage("|cff4fc3f7LUDOS-on|r " .. note) end
    note = nil
    f:UnregisterEvent("PLAYER_ENTERING_WORLD")
  end
end)
